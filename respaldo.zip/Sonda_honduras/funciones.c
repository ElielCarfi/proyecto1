
#include "funciones.h"

void init_alimentador(void){
// <editor-fold defaultstate="collapsed" desc="Inicializacion del Alimentador">
    read_ID_alimentador();//rescata el id del alimentador que etsa en la eeprom
    read_MAC_monitor();
    read_MAC_CRA();
    dia_hoy = getDay_RTC();
    init_struct_rutina();
    flags.rutinaProgramada = check_rutina_programada();
    flags.horario_corrido = check_horario_corrido(RUTINA.numeroRutinas);
    control_dias_alimentacion();
    control_EN1();
    control_luces_torreta();
// </editor-fold>
}

void init_struct_rutina(void){
    RUTINA.numeroRutinas = RUTINA_ACTIVA.numeroRutinas = readEEPROM_NumeroRutinas();
    RUTINA.numeroRutinaActual = RUTINA_ACTIVA.numeroRutinaActual = 1;
    RUTINA.dias_alimentacion = RUTINA_ACTIVA.dias_alimentacion = readEEPROM_DayAlimentacion_Multiples();
    RUTINA.inicio_horario = RUTINA_ACTIVA.inicio_horario = readEEPROM_HoraInicioRutina(RUTINA.numeroRutinaActual);
    RUTINA.final_horario = RUTINA_ACTIVA.final_horario = readEEPROM_HoraFinalRutina(RUTINA.numeroRutinaActual);
    RUTINA.intervalo_minutos = RUTINA_ACTIVA.intervalo_minutos = readEEPROM_IntervaloMinutosRutina(RUTINA.numeroRutinaActual);
    RUTINA.duracion_segundos = RUTINA_ACTIVA.duracion_segundos =  readEEPROM_DuracionSegundosRutina(RUTINA.numeroRutinaActual);
    RUTINA.velocidad_minima = RUTINA_ACTIVA.velocidad_minima = readEEPROM_VelocidadMinimaRutina(RUTINA.numeroRutinaActual);
    RUTINA.velocidad_maxima = RUTINA_ACTIVA.velocidad_maxima =  readEEPROM_VelocidadMaximaRutina(RUTINA.numeroRutinaActual);
    RUTINA.velocidadDosificador = RUTINA_ACTIVA.velocidadDosificador =  readEEPROM_VelocidadDosificadorRutina(RUTINA.numeroRutinaActual);
    RUTINA.distribucion_uniforme = RUTINA_ACTIVA.distribucion_uniforme = readEEPROM_DistribucionUniformeRutina(RUTINA.numeroRutinaActual);
}

void init_struct_rutina_activa(uint8_t numero_rutina){
    RUTINA_ACTIVA.numeroRutinaActual = numero_rutina;
    RUTINA_ACTIVA.inicio_horario = readEEPROM_HoraInicioRutina(numero_rutina);
    RUTINA_ACTIVA.final_horario = readEEPROM_HoraFinalRutina(numero_rutina);
    RUTINA_ACTIVA.intervalo_minutos = readEEPROM_IntervaloMinutosRutina(numero_rutina);
    RUTINA_ACTIVA.duracion_segundos = readEEPROM_DuracionSegundosRutina(numero_rutina);
    RUTINA_ACTIVA.velocidad_minima = readEEPROM_VelocidadMinimaRutina(numero_rutina);
    RUTINA_ACTIVA.velocidad_maxima = readEEPROM_VelocidadMaximaRutina(numero_rutina);
    RUTINA_ACTIVA.velocidadDosificador = readEEPROM_VelocidadDosificadorRutina(numero_rutina);
    RUTINA_ACTIVA.distribucion_uniforme = readEEPROM_DistribucionUniformeRutina(numero_rutina);
}

void actualizar_struct_rutina_con_rutina_activa(void){
    RUTINA.numeroRutinaActual = RUTINA_ACTIVA.numeroRutinaActual;
    RUTINA.inicio_horario = RUTINA_ACTIVA.inicio_horario;
    RUTINA.final_horario = RUTINA_ACTIVA.final_horario;
    RUTINA.intervalo_minutos = RUTINA_ACTIVA.intervalo_minutos;
    RUTINA.duracion_segundos =  RUTINA_ACTIVA.duracion_segundos;
    RUTINA.velocidad_minima = RUTINA_ACTIVA.velocidad_minima;
    RUTINA.velocidad_maxima = RUTINA_ACTIVA.velocidad_maxima;
    RUTINA.velocidadDosificador = RUTINA_ACTIVA.velocidadDosificador;
    RUTINA.distribucion_uniforme = RUTINA_ACTIVA.distribucion_uniforme;
}

//Funcion para reconocer si el ID del modulo corresponde al modulo que se esta recibiendo el mensaje
bool rev_ID_alimetador_GB(uint8_t identificador){
// <editor-fold defaultstate="collapsed" desc="Check ID Global Alimentador">
    if(identificador == ID_ALIMENTADOR_GLOBAL){
        return  true;
    }
    else{
        return  false;
    }
// </editor-fold> 
}

bool rev_ID_alimentador(uint8_t indentificador_1, uint8_t indentificador_2, uint8_t indentificador_3){
// <editor-fold defaultstate="collapsed" desc="Check ID Alimentador">
    if((indentificador_1 == ID_ALIMENTADOR_ASCII1) && (indentificador_2 == ID_ALIMENTADOR_ASCII2) && (indentificador_3 == ID_ALIMENTADOR_ASCII3)){
        return  true;
    }
    else{
        return  false;
    }
// </editor-fold>
}

void get_ADC_all(void){
// <editor-fold defaultstate="collapsed" desc="Mide el ADC de todos los dispositvos *Excepto RSSI y DivBAteria">
    //Desactivacion de Interrupciones
    INTERRUPT_GlobalInterruptHighDisable();
    INTERRUPT_GlobalInterruptLowDisable();
    
    Porcentaje_ADC.MT1 = MT1_ADC_porcentaje();
    Porcentaje_ADC.MT2 = MT2_ADC_porcentaje();
    Porcentaje_ADC.Pbateria = PBateria_ADC_porcentaje();
    Porcentaje_ADC.Divbateria = DivBateria_ADC_porcentaje();
    Porcentaje_ADC.Panel = Panel_ADC_porcentaje();
    Porcentaje_ADC.RSSI = RSSI_ADC_porcentaje();
    
    //Activacion de interrrupciones
    INTERRUPT_GlobalInterruptHighEnable();
    INTERRUPT_GlobalInterruptLowEnable();
// </editor-fold> 
}

void get_ADC_Panel(void){
// <editor-fold defaultstate="collapsed" desc="Recoge las mediciones del Porcentaje Bateria y el Panel">
    //Desactivacion de Interrupciones
    INTERRUPT_GlobalInterruptHighDisable();
    INTERRUPT_GlobalInterruptLowDisable();
    
    Porcentaje_ADC.Panel = Panel_ADC_porcentaje();
    
    //Activacion de interrrupciones
    INTERRUPT_GlobalInterruptHighEnable();
    INTERRUPT_GlobalInterruptLowEnable();
// </editor-fold> 
}

void get_ADC_Bateria(void){
// <editor-fold defaultstate="collapsed" desc="Recoge las mediciones del Porcentaje Bateria">
    
    //Desactivacion de Interrupciones
    INTERRUPT_GlobalInterruptHighDisable();
    INTERRUPT_GlobalInterruptLowDisable();
    
    control_EN1();
    
    //Activacion de interrrupciones
    INTERRUPT_GlobalInterruptHighEnable();
    INTERRUPT_GlobalInterruptLowEnable();
// </editor-fold> 
}

void get_ADC_Motores(void){
// <editor-fold defaultstate="collapsed" desc="Mide el porcentaje de los 2 Motores">
    //Desactivacion de Interrupciones
    INTERRUPT_GlobalInterruptHighDisable();
    INTERRUPT_GlobalInterruptLowDisable();
    
    Porcentaje_ADC.MT1 = MT1_ADC_porcentaje();
    Porcentaje_ADC.MT2 = MT2_ADC_porcentaje();
    
    //Activacion de interrrupciones
    INTERRUPT_GlobalInterruptHighEnable();
    INTERRUPT_GlobalInterruptLowEnable();
// </editor-fold> 
}

uint16_t MT1_ADC_porcentaje(void){
// <editor-fold defaultstate="collapsed" desc="Porcentaje Motor 1">
    uint16_t conversion_ADC = getADC_promediado(A_MT1);
    uint16_t resultado_porcentaje = 0;
    
    resultado_porcentaje = (uint8_t)(conversion_ADC/INTERVALO_PORCENTAJE_MOTOR1);
  
    return resultado_porcentaje;
// </editor-fold>
}

uint16_t MT2_ADC_porcentaje(void){
// <editor-fold defaultstate="collapsed" desc="Porcentaje Motor 2">
    uint16_t conversion_ADC = getADC_promediado(A_MT2);
    uint16_t resultado_porcentaje = 0;
    
    resultado_porcentaje = (uint8_t)(conversion_ADC/INTERVALO_PORCENTAJE_MOTOR2);
  
    return resultado_porcentaje;
// </editor-fold>
}

uint8_t PBateria_ADC_porcentaje(void){
// <editor-fold defaultstate="collapsed" desc="Porcentaje Bateria">
    uint16_t conversion_ADC = getADC_promediado(P_BATERIA);
    uint8_t resultado_porcentaje = 0;
    
    resultado_porcentaje = (uint8_t)(conversion_ADC/INVERVALO_PORCENTAJE_BATERIA);
    if(resultado_porcentaje > 100){
        resultado_porcentaje = 100;
    }
    
    return resultado_porcentaje;
// </editor-fold>
}

uint8_t DivBateria_ADC_porcentaje(void){
// <editor-fold defaultstate="collapsed" desc="Porcentaje Bateria por divisor">
    uint16_t conversion_ADC = getADC_promediado(BATERIA);
    uint8_t resultado_porcentaje = 0;
    
    resultado_porcentaje = (uint8_t)(conversion_ADC/INVERVALO_PORCENTAJE_BATERIA);
    if(resultado_porcentaje > 100){
        resultado_porcentaje = 100;
    }
    
    return resultado_porcentaje;
// </editor-fold>
}

uint8_t Panel_ADC_porcentaje(void){
// <editor-fold defaultstate="collapsed" desc="Porcentaje Panel Solar">
    uint16_t conversion_ADC = getADC_promediado(PANEL);
    uint8_t resultado_porcentaje = 0;
    
    resultado_porcentaje = (uint8_t)(conversion_ADC/ INTERVALO_PORCENTAJE_PANEL);
    if(resultado_porcentaje > 100){
        resultado_porcentaje = 100;
    }
    
    return resultado_porcentaje;
// </editor-fold>
}

uint8_t RSSI_ADC_porcentaje(void){
// <editor-fold defaultstate="collapsed" desc="Potencia Recepcion Xbee">
    uint16_t conversion_ADC = getADC_promediado(RSSI);
    uint8_t resultado_porcentaje = 0;
    
    resultado_porcentaje = (uint8_t)(conversion_ADC/INTERVALO_PORCENTAJE_RSSI);
    if(resultado_porcentaje > 100){
        resultado_porcentaje = 100;
    }
    
    return resultado_porcentaje;
// </editor-fold>
}

uint16_t getADC_promediado(uint8_t canal_analogico){
// <editor-fold defaultstate="collapsed" desc="Toma la medicion del ADC y regresa en porcentaje">
    uint16_t conversion_ADC = 0;
    uint8_t i = 0;
    uint16_t lista_mediciones[20] = {0};
//    uint16_t lista_ordenada_mediciones[20] = {0};
    uint8_t revision_lista_mediciones = 19;
    uint16_t medicion_ADC_ordenando = 0;
    uint16_t siguiente_valor_ADC_comparado = 0;
    uint8_t lugar_lista_mediciones_ordenada = 19;
    uint16_t valor_temporal_ADC = 0;
    
//    for(i = 0; i < 20; i++){
//        ADCC_Initialize();   
//        ADCC_StartConversion(canal_analogico);
//        while(!ADCC_IsConversionDone());
//        conversion_ADC = conversion_ADC + ADCC_GetConversionResult();
//    }
//    conversion_ADC = conversion_ADC / 20;
    
    for(i = 0; i < 20; i++){
        ADCC_Initialize();   
        ADCC_StartConversion(canal_analogico);
        while(!ADCC_IsConversionDone());
        lista_mediciones[i] = ADCC_GetConversionResult();
    }
    NOP();
    //Ordenar lista de mediciones
    for(i = 0; i <20; i++){
        medicion_ADC_ordenando = lista_mediciones[i];
        for(revision_lista_mediciones = i+1; revision_lista_mediciones < 20; revision_lista_mediciones++){
            siguiente_valor_ADC_comparado = lista_mediciones[revision_lista_mediciones];
            if(medicion_ADC_ordenando > siguiente_valor_ADC_comparado){
                medicion_ADC_ordenando = siguiente_valor_ADC_comparado;
                lugar_lista_mediciones_ordenada = revision_lista_mediciones;
            }
        }
        if(lugar_lista_mediciones_ordenada > i){
            valor_temporal_ADC = lista_mediciones[i];
            lista_mediciones[i] = medicion_ADC_ordenando;
            lista_mediciones[lugar_lista_mediciones_ordenada] = valor_temporal_ADC;
        }
        lugar_lista_mediciones_ordenada = i;
    }
    NOP();
    //Promedio 10 Mediciones en la mediana
    for(i = 0; i < 6; i++){
        conversion_ADC = conversion_ADC + lista_mediciones[i + 7];
    }
    conversion_ADC = conversion_ADC / 6;
    
    return conversion_ADC;
// </editor-fold>
}

void reset_all(void){
// <editor-fold defaultstate="collapsed" desc="Realiza la tarea de reset">
    ///****Agregar antes paro de los motores en caso de estar encendidos
    DISABLE_DRIVER_MOTOR
    
    //Banderas reiniciadas
    MAC_Monitor_flag = false;
    MAC_CRA_flag = false;
    rutina_programada = false;
    alimentando_flag = false;
    alimentar_ahora_flag = false;
    //Banderas de mensaje
    mensaje_enviado = false;
    mensaje_en_curso = false;
    mensaje_recibido = false;
    mensaje_completo = false;
    
    reset_xbee();
    
    RESET();
// </editor-fold>
}

void save_rutina(void){
// <editor-fold defaultstate="collapsed" desc="Guarda la rutina que llego en memoria EEPROM">  
    saveEEPROM_NumeroRutinas_RutinaSimple();
    RUTINA.numeroRutinas = readEEPROM_NumeroRutinas();
    saveEEPROM_DayAlimentacion();
    RUTINA.dias_alimentacion = readEEPROM_DayAlimentacion_Multiples();
    saveEEPROM_HoraInicio();
    saveEEPROM_HoraFin();
    saveEEPROM_IntervaloMinutos();
    saveEEPROM_DuracionSegundos();
    saveEEPROM_VelocidadMinima();
    saveEEPROM_VelocidadMaxima();
    saveEEPROM_VelocidadDosificador();
    saveEEPROM_DistribucionUniforme();    
    control_mensaje_respuesta_OK(49);
//    init_struct_rutina();
    flags.rutinaProgramada = check_rutina_programada();
    flags.horario_corrido = check_horario_corrido(RUTINA.numeroRutinas);
    flags.nueva_rutina_programada = true;
    control_dias_alimentacion();
    hora_next_alimentacion_minutos = compesancionTiempoNuevaRutina(hora_next_alimentacion_minutos, convertTime_minutes());
    control_papardeo_LED(0);
// </editor-fold> 
}

void save_rutina_multiple(void){
// <editor-fold defaultstate="collapsed" desc="Guarda la rutina  que llego en memoria EEPROM">  
    saveEEPROM_NumeroRutinas();
    RUTINA.numeroRutinas = readEEPROM_NumeroRutinas();
    saveEEPROM_DayAlimentacion_Multiples();
    RUTINA.dias_alimentacion = readEEPROM_DayAlimentacion_Multiples();
    saveEEPROM_InicioFinIntervaloDuracionTiempoRutina(RUTINA.numeroRutinas);
    saveEEPROM_VelocidadMinMaxDistribucionUniformeGlobal(serial_cadena, RUTINA.numeroRutinas);
    control_mensaje_respuesta_OK(34 + (8 * (RUTINA.numeroRutinas - 1)));
    flags.rutinaProgramada = check_rutina_programada();
    flags.horario_corrido = check_horario_corrido(RUTINA.numeroRutinas);
    control_dias_alimentacion();
    control_papardeo_LED(0);
// </editor-fold> 
}

void info_rutina(void){
// <editor-fold defaultstate="collapsed" desc="Tareas de ejecucion para mensaje ID 80 Info Rutina">
    save_MAC_InfoRutina();
    create_mensaje_RAlimentador();
    enviar_mensaje_TX_InfoRutina();
// </editor-fold> 
}

void infoRutinaDiaria(void){
// <editor-fold defaultstate="collapsed" desc="Tareas de ejecucion para mensaje ID 80 Info Rutina">
    save_MAC_InfoRutina();
    createMensajeRutinasAlimentador();
    enviar_mensaje_TX_InfoRutina();
// </editor-fold> 
}

void send_status(void){
// <editor-fold defaultstate="collapsed" desc="Manda mensaje de Status">
    save_MAC_InfoRutina();
    create_mensaje_StatusAlimentador();
    enviar_mensaje_TX_Status();
// </editor-fold> 
}

void do_rutina(void){
// <editor-fold defaultstate="collapsed" desc="Realizar rutina programa o enviada en alimentar ahora">
    uint8_t velocidad_minima = 0;
    uint8_t velocidad_maxima = 0;
    uint8_t velocidadDosificador = 0;
    uint8_t control_uniforme = 0;
    uint16_t duracion_segundos = 0;
   
    LED_VERDE
    LED_ROJO_APAGADO
            
    if(alimentar_ahora_flag){
        //Tiempo de duracion en  segundos
        duracion_segundos = AlimentarAhora.duracionSegundos;
        AlimentarAhora.duracionSegundos = 0;
        //Velocidad minima
        velocidad_minima = AlimentarAhora.velocidadMinima;
        AlimentarAhora.velocidadMinima = 0;
        //Velocidad Maxima
        velocidad_maxima = AlimentarAhora.velocidadMaxima;
        AlimentarAhora.velocidadMaxima = 0;
        //Velocidad Dosificador
        velocidadDosificador = AlimentarAhora.velocidadDosificador;
        AlimentarAhora.velocidadDosificador = 0;
        //Control uniforme
        control_uniforme = AlimentarAhora.distribucionUniforme;
        AlimentarAhora.distribucionUniforme = 0;
        
        alimentar_ahora_flag = false;
    }
    else if(!alimentar_ahora_flag){
        velocidad_minima = RUTINA.velocidad_minima;
        velocidad_maxima = RUTINA.velocidad_maxima;
        velocidadDosificador = RUTINA.velocidadDosificador;
        control_uniforme = RUTINA.distribucion_uniforme;
        duracion_segundos = RUTINA.duracion_segundos;
        
        hora_next_alimentacion_minutos = control_aumento_tiempo_next_alimentacion(hora_next_alimentacion_minutos, RUTINA.inicio_horario, RUTINA.final_horario, RUTINA.intervalo_minutos);
    }
    
    alimentando_flag = true;
            
    if(control_uniforme == 1){
        control_motores_fase1(velocidad_maxima, duracion_segundos, velocidadDosificador);
        control_motores_fase2(velocidad_minima, velocidad_maxima);
    }
    else if(control_uniforme == 0){
        control_motores_fijo(velocidad_maxima, duracion_segundos, velocidadDosificador);
    }
    
    LED_VERDE_APAGADO
    LED_ROJO_APAGADO
// </editor-fold> 
}

void alimentar_ahora(void){
// <editor-fold defaultstate="collapsed" desc="Alimentar ahora">
    uint8_t *ptrMensajeRX = serial_cadena;
    uint8_t dato32[4] = {0};
    //Tiempo de duracion en  segundos
    dato32[0] = ptrMensajeRX[18];
    dato32[1] = ptrMensajeRX[19];
    dato32[2] = ptrMensajeRX[20];
    dato32[3] = ptrMensajeRX[21];
    AlimentarAhora.duracionSegundos = (uint16_t)(IEEE754_A_Float(dato32));
    //Velocidad minima
    dato32[0] = ptrMensajeRX[22];
    dato32[1] = ptrMensajeRX[23];
    dato32[2] = ptrMensajeRX[24];
    dato32[3] = ptrMensajeRX[25];
    AlimentarAhora.velocidadMinima = (uint8_t)(IEEE754_A_Float(dato32));
    //Velocidad Maxima
    dato32[0] = ptrMensajeRX[26];
    dato32[1] = ptrMensajeRX[27];
    dato32[2] = ptrMensajeRX[28];
    dato32[3] = ptrMensajeRX[29];
    AlimentarAhora.velocidadMaxima = (uint8_t)(IEEE754_A_Float(dato32));
    //Velocidad Dosificador
    dato32[0] = ptrMensajeRX[30];
    dato32[1] = ptrMensajeRX[31];
    dato32[2] = ptrMensajeRX[32];
    dato32[3] = ptrMensajeRX[33];
    AlimentarAhora.velocidadDosificador = (uint8_t)(IEEE754_A_Float(dato32));
    //Control uniforme
    AlimentarAhora.distribucionUniforme = decodificar_numero_ASCII(ptrMensajeRX[34]);
    
    alimentar_ahora_flag = true;
    
    control_mensaje_respuesta_OK(35);
// </editor-fold> 
}

void detener_alimentacion(void){
// <editor-fold defaultstate="collapsed" desc="Detener Alimentacion">
    TMR0_StopTimer();
    alimentando_flag = false;
    control_pwm1(4095);
// </editor-fold>
}

void omitir_alimentacion(void){
// <editor-fold defaultstate="collapsed" desc="Omitir Alimentacion">
    hora_next_alimentacion_minutos = getTimeNextAlimentacion(hora_next_alimentacion_minutos, RUTINA.inicio_horario, RUTINA.final_horario, RUTINA.intervalo_minutos);
    
    if(hora_next_alimentacion_minutos == 3000){
        if(RUTINA.numeroRutinaActual + 1 <= RUTINA.numeroRutinas){
            RUTINA.numeroRutinaActual++;
        }
        else if(RUTINA.numeroRutinaActual + 1 > RUTINA.numeroRutinas){
            RUTINA.numeroRutinaActual = 1;
        }
        init_struct_rutina_activa(RUTINA.numeroRutinaActual);
        actualizar_struct_rutina_con_rutina_activa();
        hora_next_alimentacion_minutos = getTimeNextAlimentacion(convertTime_minutes(), RUTINA.inicio_horario, RUTINA.final_horario, RUTINA.intervalo_minutos);
    }
// </editor-fold> 
}

void borrar_rutinas(uint8_t numero_rutinas){
// <editor-fold defaultstate="collapsed" desc="borrar la rutina que tenga programada">
    uint16_t aumentoLocalidadEEPROMRutinas = 0;
    
    for(; numero_rutinas > 0; numero_rutinas--){
        aumentoLocalidadEEPROMRutinas = 0x0010 * (numero_rutinas - 1);
        //Borrando informacion de dias de alimentacion
        DATAEE_WriteByte(L_CANTIDAD_RUTINAS, 0xFF);
        //Borrando informacion de dias de alimentacion
        DATAEE_WriteByte(L_DIA_ALIMENTACION_M, 0xFF);
        //Borrando informacion de la hora de inicio
        DATAEE_WriteByte((L_HORA_INICIO_M + aumentoLocalidadEEPROMRutinas), 0xFF);
        DATAEE_WriteByte((L_HORA_INICIO_M + 1 + aumentoLocalidadEEPROMRutinas), 0xFF);
        //Borrando informacion de la hora de fin
        DATAEE_WriteByte((L_HORA_FIN_M + aumentoLocalidadEEPROMRutinas), 0xFF);
        DATAEE_WriteByte((L_HORA_FIN_M + 1 + aumentoLocalidadEEPROMRutinas), 0xFF);
        //Borrando informacion del intervalo en minutos
        DATAEE_WriteByte((L_INTERVALO_MIN_M + aumentoLocalidadEEPROMRutinas), 0xFF);
        DATAEE_WriteByte((L_INTERVALO_MIN_M + 1 + aumentoLocalidadEEPROMRutinas), 0xFF);
        //Borrando informacion de la duracion de la alimentacion
        DATAEE_WriteByte((L_DURACION_SEGUNDOS_M + aumentoLocalidadEEPROMRutinas), 0xFF);
        DATAEE_WriteByte((L_DURACION_SEGUNDOS_M + 1 + aumentoLocalidadEEPROMRutinas), 0xFF);
        //Borrando informacion de la velocidad minima
        DATAEE_WriteByte((L_VELOCIDAD_MINIMA_M + aumentoLocalidadEEPROMRutinas), 0xFF);
        //Borrando informacion de la velocidad maxima
        DATAEE_WriteByte((L_VELOCIDAD_MAXIMA_M + aumentoLocalidadEEPROMRutinas), 0xFF);
        //Borrando informacion de la velocidad del dosificador
        DATAEE_WriteByte((L_VELOCIDAD_DOSIFICADOR + aumentoLocalidadEEPROMRutinas), 100);
        //Borrando informacion de la distribucion uniforme
        DATAEE_WriteByte((L_DISTRIBUCION_UNIFORME_M + aumentoLocalidadEEPROMRutinas), 0xFF);
    }
    
    init_struct_rutina();
    flags.rutinaProgramada = check_rutina_programada();
    flags.horario_corrido = check_horario_corrido(RUTINA.numeroRutinas);
    control_dias_alimentacion();
// </editor-fold> 
}

void enviar_mensaje_TX_InfoRutina(void){
// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con la info de la rutina programada">
    crear_mensaje(MAC_InfoRutina, mensaje_TX_data, tamanio_mensaje_data);
    
    //Byte que delimita el principio el mensaje
    UART1_Write(0x7E);
    
    //Cantidad de bytes enviados
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo >> 8));
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo));
    
    //Envio de mensaje
    enviar_cadena_USART1(mensaje_TX_completo, tamanio_mensajeTX_completo);
    
    //Calcula y envia el checksum
    UART1_Write(calculate_checksum(mensaje_TX_completo, tamanio_mensajeTX_completo));
    
    mensaje_enviado = true;
    
// </editor-fold>   
}

void enviar_mensaje_TX_Status(void){
// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con la info de la rutina programada">// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con la info de la rutina programada">
    crear_mensaje(MAC_InfoRutina, mensaje_TX_data, tamanio_mensaje_data);
    
    //Byte que delimita el principio el mensaje
    UART1_Write(0x7E);
    
    //Cantidad de bytes enviados
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo >> 8));
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo));
    
    //Envio de mensaje
    enviar_cadena_USART1(mensaje_TX_completo, tamanio_mensajeTX_completo);
    
    //Calcula y envia el checksum
    UART1_Write(calculate_checksum(mensaje_TX_completo, tamanio_mensajeTX_completo));
    
    mensaje_enviado = true;
    
// </editor-fold>   
}

void enviar_mensaje_TX_Status_CRA(void){
// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con el Status al CRA">// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con la info de la rutina programada">
    crear_mensaje(MAC_CRA, mensaje_TX_data, tamanio_mensaje_data);
    
    //Byte que delimita el principio el mensaje
    UART1_Write(0x7E);
    
    //Cantidad de bytes enviados
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo >> 8));
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo));
    
    //Envio de mensaje
    enviar_cadena_USART1(mensaje_TX_completo, tamanio_mensajeTX_completo);
    
    //Calcula y envia el checksum
    UART1_Write(calculate_checksum(mensaje_TX_completo, tamanio_mensajeTX_completo));
    
    mensaje_enviado = true;
    
// </editor-fold>   
}

void enviar_mensaje_TX_Status_Monitor(void){
// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con el Status al Monitor">// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con la info de la rutina programada">
    crear_mensaje(MAC_Monitor, mensaje_TX_data, tamanio_mensaje_data);
    
    //Byte que delimita el principio el mensaje
    UART1_Write(0x7E);
    
    //Cantidad de bytes enviados
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo >> 8));
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo));
    
    //Envio de mensaje
    enviar_cadena_USART1(mensaje_TX_completo, tamanio_mensajeTX_completo);
    
    //Calcula y envia el checksum
    UART1_Write(calculate_checksum(mensaje_TX_completo, tamanio_mensajeTX_completo));
    
    mensaje_enviado = true;
    
// </editor-fold>   
}

void enviar_mensaje_TX_OK_CRA(void){
// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con la info de la rutina programada al CRA">// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con la info de la rutina programada">
    crear_mensaje(MAC_CRA, mensaje_TX_data, tamanio_mensaje_data);
    
    //Byte que delimita el principio el mensaje
    UART1_Write(0x7E);
    
    //Cantidad de bytes enviados
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo >> 8));
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo));
    
    //Envio de mensaje
    enviar_cadena_USART1(mensaje_TX_completo, tamanio_mensajeTX_completo);
    
    //Calcula y envia el checksum
    UART1_Write(calculate_checksum(mensaje_TX_completo, tamanio_mensajeTX_completo));
    
    mensaje_enviado = true;
    
// </editor-fold>   
}

void enviar_mensaje_TX_OK(void){
// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con la info de la rutina programada del equipo que haya llegado">// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con la info de la rutina programada">
    crear_mensaje(MAC_InfoRutina, mensaje_TX_data, tamanio_mensaje_data);
    
    //Byte que delimita el principio el mensaje
    UART1_Write(0x7E);
    
    //Cantidad de bytes enviados
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo >> 8));
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo));
    
    //Envio de mensaje
    enviar_cadena_USART1(mensaje_TX_completo, tamanio_mensajeTX_completo);
    
    //Calcula y envia el checksum
    UART1_Write(calculate_checksum(mensaje_TX_completo, tamanio_mensajeTX_completo));
    
    mensaje_enviado = true;
    
// </editor-fold>   
}

void control_mediciones_bateria(uint16_t intervalo_tiempo){
// <editor-fold defaultstate="collapsed" desc="controla el timepo entre mediciones para la bateria">
    if(tiempo_transcurrido_medicion_ADC >= intervalo_tiempo){
        control_EN1();
        tiempo_transcurrido_medicion_ADC = 0;
    }
    else if(tiempo_transcurrido_medicion_ADC < intervalo_tiempo){
        tiempo_transcurrido_medicion_ADC++;
    }
// </editor-fold>
}

void control_papardeo_LED(uint16_t intervalo_tiempo){
// <editor-fold defaultstate="collapsed" desc="Controla el tiempo entre cada parpadeo del LED verde de la torreta">
    if((rutina_programada) && (tiempo_transcurrido_parpadeo >= intervalo_tiempo)){
        LED_VERDE
        __delay_ms(1000);
        LED_VERDE_APAGADO
        LED_ROJO_APAGADO
        tiempo_transcurrido_parpadeo = 0;
    }
    else if(tiempo_transcurrido_parpadeo < intervalo_tiempo){
        tiempo_transcurrido_parpadeo++;
    }
// </editor-fold>
}

void control_luces_torreta(void){
// <editor-fold defaultstate="collapsed" desc="Control de los LED's de la torreta">
    if(rutina_programada){
        LED_ROJO_APAGADO
        LED_NARANJA_APAGADO
        control_papardeo_LED(0);
    }
    else if(!rutina_programada){
        LED_ROJO
        LED_VERDE_APAGADO
        LED_NARANJA_APAGADO  
    }
// </editor-fold> 
}

void control_EN1(void){
// <editor-fold defaultstate="collapsed" desc="Control del EN1">            
    Porcentaje_ADC.Pbateria = PBateria_ADC_porcentaje();
    Porcentaje_ADC.Divbateria = DivBateria_ADC_porcentaje();   
            
    if(Porcentaje_ADC.Pbateria >= 5){
        flags.deshabilitar_motores = false;
//        ENABLE_EN1
    }
    else if(Porcentaje_ADC.Pbateria < 5){
        flags.deshabilitar_motores = true;
//        DISABLE_EN1
    }
// </editor-fold> 
}

uint16_t control_aumento_tiempo_next_alimentacion(uint16_t horaNextAlimentacion, uint16_t horaInicial, uint16_t horaFinal, uint16_t intervaloMinutos){
// <editor-fold defaultstate="collapsed" desc="Controlar la hora cuando se realizara la siguiente alimentacion">
    if(checkRutinaHorarioCorrido(horaInicial, horaFinal) && (horaNextAlimentacion > readEEPROM_HoraInicioRutina(1))){
        horaFinal += 1440;
    }
    
    horaNextAlimentacion += intervaloMinutos;
               
    if(horaNextAlimentacion > horaFinal){
        if((RUTINA.numeroRutinaActual + 1) <= RUTINA.numeroRutinas){
            RUTINA.numeroRutinaActual++;
        }
        else if((RUTINA.numeroRutinaActual + 1) > RUTINA.numeroRutinas){
            RUTINA.numeroRutinaActual = 1;
        }
        init_struct_rutina_activa(RUTINA.numeroRutinaActual);
        actualizar_struct_rutina_con_rutina_activa();
        horaNextAlimentacion = getTimeNextAlimentacion(convertTime_minutes(), RUTINA.inicio_horario, RUTINA.final_horario, RUTINA.intervalo_minutos);
    }
    
    return horaNextAlimentacion;
// </editor-fold>
}

void control_dias_alimentacion(void){
// <editor-fold defaultstate="collapsed" desc="Verifica si el dia de la semana en que se hara alimentacion">
    if(rutina_programada){
        dia_hoy_alimentacion_flag = revisar_dia_rutina();
        if(dia_hoy_alimentacion_flag){
            selector_rutina();
        }
        else{
            check_rutina_programada();
            init_struct_rutina_activa(1);
            actualizar_struct_rutina_con_rutina_activa();
            hora_next_alimentacion_minutos = 3000;
        }
    }
    else{
        check_rutina_programada();
        hora_next_alimentacion_minutos = 3000;
    }
// </editor-fold>
}

void control_tiempo_alimentacion_interrupcion(void){
// <editor-fold defaultstate="collapsed" desc="Control del tiempo en la interrupcion del TM0">
    tiempo_segundos_alimentando++;
    
    if(tiempo_segundos_alimentando >= tiempo_limite_alimentado){
        TMR0_StopTimer();
        alimentando_flag = false;
        control_pwm1(4095);
    }
// </editor-fold>
}

void control_tiempo_alimentacion(uint16_t duracion_segundos){
// <editor-fold defaultstate="collapsed" desc="Control del tiempo, activada TM0">
    alimentando_flag = true;
    tiempo_segundos_alimentando = 0;
    tiempo_limite_alimentado = duracion_segundos;
    TMR0_StartTimer();
// </editor-fold>
}

void control_motores_fase2(uint8_t velocidad_minima, uint8_t velocidad_maxima){
// <editor-fold defaultstate="collapsed" desc="Fase 2 Control de Motores">
    uint16_t control_velocidad_minima = 0;
    uint16_t control_velocidad_maxima = 0;
    uint16_t delay_desactivacion_motor2 = 500; //1000 ms 500*2
     
    control_velocidad_minima = 2700 - (velocidad_minima * 27);
    control_velocidad_maxima = 2700 - (velocidad_maxima * 27);
    
    get_ADC_Motores();
    
    while(alimentando_flag){
        for(;((variable_pwm2 < control_velocidad_minima) && (delay_desactivacion_motor2 > 0)); variable_pwm2++){
            control_pwm2(variable_pwm2);
            __delay_ms(2);
            LED_VERDE
            LED_ROJO_APAGADO
            if(!alimentando_flag){
                delay_desactivacion_motor2--;
            }
        }
        for(;((variable_pwm2 > control_velocidad_maxima) && (delay_desactivacion_motor2 > 0)); variable_pwm2--){
            control_pwm2(variable_pwm2);
            __delay_ms(2);
            LED_VERDE
            LED_ROJO_APAGADO
            if(!alimentando_flag){
                delay_desactivacion_motor2--;
            }
        }
    }
    DISABLE_DRIVER_MOTOR
    
    alimentando_flag = false;
    control_pwm1(0);
    control_pwm2(0);
    variable_pwm2 = 4095;
// </editor-fold>
}

void control_motores_fase1(uint8_t velocidad_maxima, uint16_t duracion_segundos, uint8_t velocidadDosificador){
// <editor-fold defaultstate="collapsed" desc="Fase 1 Control de Motores">
    uint16_t velocidadInicialMotor2 = 2700;
    uint16_t tiempoDelay = (1000/velocidad_maxima);
    
    variable_pwm2 = (2700 - (velocidad_maxima * 27));
    control_pwm1(3000);
    ENABLE_DRIVER_MOTOR
    for(; velocidadInicialMotor2 > variable_pwm2; velocidadInicialMotor2--){
        control_pwm2(velocidadInicialMotor2);
        __delay_us(500);
    }
    control_pwm2(variable_pwm2);
    for(; tiempoDelay > 0; tiempoDelay--){
        __delay_ms(1);
    }
    
    control_tiempo_alimentacion(duracion_segundos);
    control_pwm1((2700 - (velocidadDosificador * 27)));
// </editor-fold>
}

void control_motores_fijo(uint8_t velocidad_maxima, uint16_t duracion_segundos, uint8_t velocidadDosificador){
// <editor-fold defaultstate="collapsed" desc="Control de motores sin distribucion uniforme">
    uint16_t velocidadMotor2 = 2700;
    uint16_t velocidadMaximaMotor2 = 2700 - (velocidad_maxima * 27);
    uint16_t tiempoDelay = (1000/velocidad_maxima);
    
    control_pwm2(velocidadMotor2);
    control_pwm1(3000);
    
    ENABLE_DRIVER_MOTOR
    for(; velocidadMotor2 > velocidadMaximaMotor2; velocidadMotor2--){
        control_pwm2(velocidadMotor2);
        __delay_us(500);
    }
    control_pwm2(velocidadMaximaMotor2);
    for(; tiempoDelay > 0; tiempoDelay--){
        __delay_ms(1);
    }
       
    control_tiempo_alimentacion(duracion_segundos); 
    control_pwm1((2700 - (velocidadDosificador * 27)));
    __delay_ms(1000);
    get_ADC_Motores();
    while(alimentando_flag){
        LED_VERDE
        LED_ROJO_APAGADO
    }
    __delay_ms(1000);          //Delay para que termine de rociar el alimento que le quedaba
    
    DISABLE_DRIVER_MOTOR
    alimentando_flag = false;        
    control_pwm1(0);
    control_pwm2(0);
    variable_pwm2 = 2700;
    
// </editor-fold>
}

void control_mensaje_respuesta_OK(uint8_t posicion_IEEE){
// <editor-fold defaultstate="collapsed" desc="Controla si la MAC del mensaje recibido es del CRA y envia el OK">  
    bool MAC_entrante = false;

    MAC_entrante = check_MAC_mensaje_entrante();
    if(MAC_entrante){
        save_IEEE_regresar(posicion_IEEE);
        create_mensaje_RespuestaOK();
        enviar_mensaje_TX_OK_CRA();
    }   
// </editor-fold>
}

void mensaje_respuesta_OK(uint8_t posicion_IEEE){
// <editor-fold defaultstate="collapsed" desc="Envia el OK con el IEEE a cualquier equipo que le haya enviado mensaje"> 
    save_IEEE_regresar(posicion_IEEE);
    save_MAC_InfoRutina();
    create_mensaje_RespuestaOK();
    enviar_mensaje_TX_OK();
// </editor-fold>
}

void control_pwm1(uint16_t duty_cycle){
// <editor-fold defaultstate="collapsed" desc="Control del PWM 1">
    PWM1_16BIT_SetSlice1Output1DutyCycleRegister(duty_cycle);  //duty cycle
    PWM1_16BIT_LoadBufferRegisters();
// </editor-fold>
}

void control_pwm2(uint16_t duty_cycle){
// <editor-fold defaultstate="collapsed" desc="Control del PWM 2">
    PWM1_16BIT_SetSlice1Output2DutyCycleRegister(duty_cycle);  //duty cycle
    PWM1_16BIT_LoadBufferRegisters();
// </editor-fold>
}

void create_mensaje_RAlimentador(void){
// <editor-fold defaultstate="collapsed" desc="Crea mensaje el TX_data que se enviara en el mensaje con la Info de la Rutina">
    float data_F = 0;
    uint32_t data32_IEE = 0;
    //ID_
    mensaje_TX_data[0] = ID_ALIMENTADOR_GLOBAL;
    mensaje_TX_data[1] = RESPUESTA_INFO_RUTINA_ASCII1;  
    mensaje_TX_data[2] = RESPUESTA_INFO_RUTINA_ASCII2;
    mensaje_TX_data[3] = ID_ALIMENTADOR_ASCII1;
    mensaje_TX_data[4] = ID_ALIMENTADOR_ASCII2;
    mensaje_TX_data[5] = ID_ALIMENTADOR_ASCII3;
    mensaje_TX_data[6] = convertHex_ASCII((RUTINA.dias_alimentacion & 0xF0) >> 4);
    mensaje_TX_data[7] = convertHex_ASCII(RUTINA.dias_alimentacion & 0x0F);
    //Hora de Inicio
    data32_IEE = float_a_IEEE754((float) RUTINA.inicio_horario);
    mensaje_TX_data[8] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[9] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[10] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[11] = (uint8_t)(data32_IEE);
    //Hora Fin
    data32_IEE = float_a_IEEE754((float) RUTINA.final_horario);
    mensaje_TX_data[12] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[13] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[14] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[15] = (uint8_t)(data32_IEE);
    //Intervalo Minutos
    data32_IEE = float_a_IEEE754((float) RUTINA.intervalo_minutos);
    mensaje_TX_data[16] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[17] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[18] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[19] = (uint8_t)(data32_IEE);
    //Duracion Segundos
    data32_IEE = float_a_IEEE754((float) RUTINA.duracion_segundos);
    mensaje_TX_data[20] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[21] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[22] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[23] = (uint8_t)(data32_IEE);
    //Velocidad Minima
    data32_IEE = float_a_IEEE754((float) RUTINA.velocidad_minima);
    mensaje_TX_data[24] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[25] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[26] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[27] = (uint8_t)(data32_IEE);
    //Velocidad Maxima
    data32_IEE = float_a_IEEE754((float) RUTINA.velocidad_maxima);
    mensaje_TX_data[28] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[29] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[30] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[31] = (uint8_t)(data32_IEE);
    //Velocidad Dosificador
    data32_IEE = float_a_IEEE754((float) RUTINA.velocidadDosificador);
    mensaje_TX_data[32] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[33] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[34] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[35] = (uint8_t)(data32_IEE);
    //Tiempo Restante siguiente alimentacion
    if((hora_next_alimentacion_minutos > hora_en_minutos) && (hora_next_alimentacion_minutos != 3000)){
        data_F = (float)(hora_next_alimentacion_minutos - hora_en_minutos);
    }
    else{
        data_F = 0.0;
    }
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[36] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[37] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[38] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[39] = (uint8_t)(data32_IEE);
    //Distribucion uniforme
    mensaje_TX_data[40] = RUTINA.distribucion_uniforme + 0x30;      //Se suma 0x30 para hacer el numero ASCII
    
    tamanio_mensaje_data = 41;
// </editor-fold> 
}

void createMensajeRutinasAlimentador(void){
// <editor-fold defaultstate="collapsed" desc="Crea mensaje el TX_data que se enviara en el mensaje con la Info de la Rutina">
    uint16_t localidadEEPROM = 0;
    uint8_t posicionTXData = 0;
    uint8_t numeroRutinas = RUTINA.numeroRutinas;
    //ID_
    mensaje_TX_data[0] = ID_ALIMENTADOR_GLOBAL;
    mensaje_TX_data[1] = SOLICITAR_RUTINA_DIARIA_ASCII1;  
    mensaje_TX_data[2] = SOLICITAR_RUTINA_DIARIA_ASCII2;
    mensaje_TX_data[3] = ID_ALIMENTADOR_ASCII1;
    mensaje_TX_data[4] = ID_ALIMENTADOR_ASCII2;
    mensaje_TX_data[5] = ID_ALIMENTADOR_ASCII3;
    mensaje_TX_data[6] = convertHex_ASCII((RUTINA.dias_alimentacion & 0xF0) >> 4);
    mensaje_TX_data[7] = convertHex_ASCII(RUTINA.dias_alimentacion & 0x0F);
    //Velocidad Minima Global
    mensaje_TX_data[8] = RUTINA.velocidad_minima;
    //Velocidad Maxima Global
    mensaje_TX_data[9] = RUTINA.velocidad_maxima;
    //Velocidad Dosificador
    mensaje_TX_data[10] = RUTINA.velocidadDosificador;
    //Distribucion Uniforme Global
    mensaje_TX_data[11] = RUTINA.distribucion_uniforme + 0x30;
    //Numero de Rutinas
    mensaje_TX_data[12] = convertHex_ASCII((RUTINA.numeroRutinas & 0xF0) >> 4);
    mensaje_TX_data[13] = convertHex_ASCII(RUTINA.numeroRutinas & 0x0F);
    if(numeroRutinas == 0){
        numeroRutinas++;
    }
    for(uint8_t rutinaActual = 0; rutinaActual < numeroRutinas; rutinaActual++){
        localidadEEPROM = L_HORA_INICIO_M + (0x10 * rutinaActual);
        posicionTXData = 14 + (8 * rutinaActual);
        mensaje_TX_data[posicionTXData] = DATAEE_ReadByte(localidadEEPROM);
        localidadEEPROM++;
        posicionTXData++;
        mensaje_TX_data[posicionTXData] = DATAEE_ReadByte(localidadEEPROM);
        localidadEEPROM++;
        posicionTXData++;
        mensaje_TX_data[posicionTXData] = DATAEE_ReadByte(localidadEEPROM);
        localidadEEPROM++;
        posicionTXData++;
        mensaje_TX_data[posicionTXData] = DATAEE_ReadByte(localidadEEPROM);
        localidadEEPROM++;
        posicionTXData++;
        mensaje_TX_data[posicionTXData] = DATAEE_ReadByte(localidadEEPROM);
        localidadEEPROM++;
        posicionTXData++;
        mensaje_TX_data[posicionTXData] = DATAEE_ReadByte(localidadEEPROM);
        localidadEEPROM++;
        posicionTXData++;
        mensaje_TX_data[posicionTXData] = DATAEE_ReadByte(localidadEEPROM);
        localidadEEPROM++;
        posicionTXData++;
        mensaje_TX_data[posicionTXData] = DATAEE_ReadByte(localidadEEPROM);            
    }
    
    tamanio_mensaje_data = posicionTXData + 1;
// </editor-fold> 
}

void create_mensaje_StatusAlimentador(void){
// <editor-fold defaultstate="collapsed" desc="Crea mensaje el TX_data que se enviara en el mensaje con el status del alimentador">
    float data_F = 0;
    uint32_t data32_IEE = 0;
    
    get_ADC_Bateria();
    get_ADC_Panel();
    
    //ID_
    mensaje_TX_data[0] = ID_ALIMENTADOR_GLOBAL;
    mensaje_TX_data[1] = SOLICITUD_STATUS_ASCII1;  
    mensaje_TX_data[2] = SOLICITUD_STATUS_ASCII2;
    mensaje_TX_data[3] = ID_ALIMENTADOR_ASCII1;
    mensaje_TX_data[4] = ID_ALIMENTADOR_ASCII2;
    mensaje_TX_data[5] = ID_ALIMENTADOR_ASCII3;
    //%Motor 1
    data_F = (float)(Porcentaje_ADC.MT1);
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[6] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[7] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[8] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[9] = (uint8_t)(data32_IEE);
    //%Motor 2
    data_F = (float)(Porcentaje_ADC.MT2);
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[10] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[11] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[12] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[13] = (uint8_t)(data32_IEE);
    //%Bateria
    data_F = (float)(Porcentaje_ADC.Pbateria);
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[14] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[15] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[16] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[17] = (uint8_t)(data32_IEE);
    //%Panel Solar
    data_F = (float)(Porcentaje_ADC.Panel);
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[18] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[19] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[20] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[21] = (uint8_t)(data32_IEE);
    //Cantidad de alimento a lanzar en siguiente alimentacion
    if(!flags.deshabilitar_motores){
        data_F = (float)(RUTINA.duracion_segundos * ALIMENTO_GRAMOS);
    }
    else{
        data_F = 0.0;
    }
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[22] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[23] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[24] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[25] = (uint8_t)(data32_IEE);
    //Tiempo restante siguiente alimentacion
    if((hora_next_alimentacion_minutos > hora_en_minutos) && (hora_next_alimentacion_minutos != 3000)){
        data_F = (float)(hora_next_alimentacion_minutos - hora_en_minutos);
    }
    else{
        data_F = 0.0;
    }
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[26] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[27] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[28] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[29] = (uint8_t)(data32_IEE);
    
    tamanio_mensaje_data = 30;
// </editor-fold> 
}

void create_mensaje_StatusAlimentador_1minuto(void){
// <editor-fold defaultstate="collapsed" desc="Crea mensaje el TX_data que se enviara en el mensaje con el status del alimentador">
    float data_F = 0;
    uint32_t data32_IEE = 0;
    
    get_ADC_Bateria();
    get_ADC_Panel();
    
    //ID_
    mensaje_TX_data[0] = ID_ALIMENTADOR_GLOBAL;
    mensaje_TX_data[1] = SOLICITUD_STATUS_ASCII1_1MIN;  
    mensaje_TX_data[2] = SOLICITUD_STATUS_ASCII2_1MIN;
    mensaje_TX_data[3] = ID_ALIMENTADOR_ASCII1;
    mensaje_TX_data[4] = ID_ALIMENTADOR_ASCII2;
    mensaje_TX_data[5] = ID_ALIMENTADOR_ASCII3;
    //%Motor 1
    data_F = (float)(Porcentaje_ADC.MT1);
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[6] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[7] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[8] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[9] = (uint8_t)(data32_IEE);
    //%Motor 2
    data_F = (float)(Porcentaje_ADC.MT2);
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[10] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[11] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[12] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[13] = (uint8_t)(data32_IEE);
    //%Bateria
    data_F = (float)(Porcentaje_ADC.Pbateria);
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[14] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[15] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[16] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[17] = (uint8_t)(data32_IEE);
    //%Panel Solar
    data_F = (float)(Porcentaje_ADC.Panel);
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[18] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[19] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[20] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[21] = (uint8_t)(data32_IEE);
    //Cantidad de alimento a lanzar en siguiente alimentacion
    if(!flags.deshabilitar_motores){
        data_F = (float)(RUTINA.duracion_segundos * ALIMENTO_GRAMOS);
    }
    else{
        data_F = 0.0;
    }
    data32_IEE = float_a_IEEE754(data_F);
    mensaje_TX_data[22] = (uint8_t)(data32_IEE >> 24);
    mensaje_TX_data[23] = (uint8_t)(data32_IEE >> 16);
    mensaje_TX_data[24] = (uint8_t)(data32_IEE >> 8);
    mensaje_TX_data[25] = (uint8_t)(data32_IEE);
    //Tiempo restante siguiente alimentacion
    mensaje_TX_data[26] = 0x3F;
    mensaje_TX_data[27] = 0x80;
    mensaje_TX_data[28] = 0x00;
    mensaje_TX_data[29] = 0x00;
    
    tamanio_mensaje_data = 30;
// </editor-fold> 
}

void create_mensaje_RespuestaOK(void){
// <editor-fold defaultstate="collapsed" desc="Crea mensaje el TX_data que se enviara en el mensaje con el status del alimentador">
    //ID_
    mensaje_TX_data[0] = ID_ALIMENTADOR_GLOBAL;
    mensaje_TX_data[1] = serial_cadena[13];  
    mensaje_TX_data[2] = serial_cadena[14];
    mensaje_TX_data[3] = 'O';
    mensaje_TX_data[4] = 'K';
    mensaje_TX_data[5] = IEEE_retornar[0];
    mensaje_TX_data[6] = IEEE_retornar[1];
    mensaje_TX_data[7] = IEEE_retornar[2];
    mensaje_TX_data[8] = IEEE_retornar[3];
    
    tamanio_mensaje_data = 9;
// </editor-fold> 
}

void config_hora(void){
// <editor-fold defaultstate="collapsed" desc="Configurar hora">
    uint8_t year = convertYear_hex();
    uint8_t month = convertMonth_hex();
    uint8_t date = convertDate_hex();
    uint8_t day_week = convertDayWeek_hex();
    uint8_t hour = convertHour_hex();
    uint8_t minutes = convertMinutes_hex();
    uint8_t seconds = convertSeconds_hex();
    
    config_RTC_all(year, month, date, day_week, hour, minutes, seconds);
    
    check_rutina_programada();
    control_dias_alimentacion();
// </editor-fold>  
}

void save_ID_alimentador(void){
// <editor-fold defaultstate="collapsed" desc="Guarda el ID que se grabara para ser el del Alimentador">
    uint8_t *ptrID= serial_cadena;
    uint16_t direccion_eeprom = L_ID_ALIMENTADOR; 
    uint8_t posicionID = 15;
    uint8_t hex_ID_alimentador = 0;
    uint8_t i = 0;
    
    for(i = 0; i < 3; i++){
        hex_ID_alimentador = ptrID[posicionID];                  //Se guarda el byte de la mac a escribir en eeprom
        DATAEE_WriteByte(direccion_eeprom, hex_ID_alimentador);    //Escribimos en la localidad el valor de la mac
        
        posicionID++;                                  //Aumentamos para seguir con el siguiente valor de la mac
        direccion_eeprom++;                            //Aumentamos a la siguiente localidad eeprom a escribir
    }      
    
    read_ID_alimentador();
// </editor-fold> 
}

void save_MAC_InfoRutina(void){
// <editor-fold defaultstate="collapsed" desc="Guardar MAC del dispositivo a vincularse Info rutina 80">
    uint8_t *ptrMAC= serial_cadena;
    uint8_t posicionMAC = 1;
    uint8_t hex_MAC = 0;
    uint8_t i = 0;
    
    for(i = 0; i < 8; i++){
        hex_MAC = ptrMAC[posicionMAC];                  //Se guarda el byte de la mac a escribir en eeprom
        MAC_InfoRutina[i] = hex_MAC;
        posicionMAC++;                                  //Aumentamos para seguir con el siguiente valor de la mac
    }      
// </editor-fold> 
}

void save_MAC_monitor(void){
// <editor-fold defaultstate="collapsed" desc="Guardar MAC del monitor">
    uint8_t *ptrMAC= serial_cadena;
    uint16_t direccion_eeprom = L_MAC_MONITOR; 
    uint8_t posicionMAC = 1;
    uint8_t hex_MAC = 0;
    uint8_t i = 0;
    
    for(i = 0; i < 8; i++){
        hex_MAC = ptrMAC[posicionMAC];                  //Se guarda el byte de la mac a escribir en eeprom
        DATAEE_WriteByte(direccion_eeprom, hex_MAC);    //Escribimos en la localidad el valor de la mac
        
        posicionMAC++;                                  //Aumentamos para seguir con el siguiente valor de la mac
        direccion_eeprom++;                             //Aumentamos a la siguiente localidad eeprom a escribir
    }      
    
    read_MAC_monitor();
// </editor-fold> 
}

void save_MAC_CRA(void){
// <editor-fold defaultstate="collapsed" desc="Guardar MAC del CRA para el sistema">
    uint8_t *ptrMAC= serial_cadena;
    uint16_t direccion_eeprom = L_MAC_CRA; 
    uint8_t posicionMAC = 1;
    uint8_t hex_MAC = 0;
    uint8_t i = 0;
    
    for(i = 0; i < 8; i++){
        hex_MAC = ptrMAC[posicionMAC];                  //Se guarda el byte de la mac a escribir en eeprom
        DATAEE_WriteByte(direccion_eeprom, hex_MAC);    //Escribimos en la localidad el valor de la mac
        
        posicionMAC++;                                  //Aumentamos para seguir con el siguiente valor de la mac
        direccion_eeprom++;                             //Aumentamos a la siguiente localidad eeprom a escribir
    }      
    
    read_MAC_CRA();
// </editor-fold> 
}

void read_ID_alimentador(void){
// <editor-fold defaultstate="collapsed" desc="Lee el ID del alimentador">
    uint8_t *ptrID= ID_Alimentador;
    uint8_t i = 0;
    uint8_t hex_ID = 0;
    uint16_t direccion_eeprom = L_ID_ALIMENTADOR;
    
    for(i = 0; i < 3; i++){
        hex_ID = DATAEE_ReadByte(direccion_eeprom);
        ptrID[i] = hex_ID;
        
        direccion_eeprom++;
    }
// </editor-fold> 
}

void read_MAC_monitor(void){
// <editor-fold defaultstate="collapsed" desc="Lee la MAC guardada del monitor">
    uint8_t *ptrMAC= MAC_Monitor;
    uint8_t i = 0;
    uint8_t hex_MAC = 0;
    uint16_t direccion_eeprom = L_MAC_MONITOR;
    
    for(i = 0; i < 8; i++){
        hex_MAC = DATAEE_ReadByte(direccion_eeprom);
        //Revisa si la primera direcion de la MAC es 0xFF en ese caso hay una MAC de un monitor, y se sale del for
        if((hex_MAC == 0xFF) && (i == 0)){
            MAC_Monitor_flag = false;
            break;
        }
        ptrMAC[i] = hex_MAC;
        
        direccion_eeprom++;
        MAC_Monitor_flag = true;
    }
// </editor-fold> 
}

void read_MAC_CRA(void){
// <editor-fold defaultstate="collapsed" desc="Lee la la MAC guardada para el CRA del sistema">
    uint8_t *ptrMAC= MAC_CRA;
    uint8_t i = 0;
    uint8_t hex_MAC = 0;
    uint16_t direccion_eeprom = L_MAC_CRA;
    
    for(i = 0; i < 8; i++){
        hex_MAC = DATAEE_ReadByte(direccion_eeprom);
        //Revisa si la primera direcion de la MAC es 0xFF en ese caso hay una MAC de un monitor,y se sale del for
        if((hex_MAC == 0xFF) && (i == 0)){
            MAC_CRA_flag = false;
            break;
        }
        ptrMAC[i] = hex_MAC;
        
        direccion_eeprom++;
        MAC_CRA_flag = true;
    }
// </editor-fold> 
}

bool check_horario_corrido(uint8_t numeroRutinas){
    uint8_t rutinaActual = 1;
    uint16_t horaInicio = 0;
    uint16_t horaFinal = 0;
    
    while(rutinaActual <= numeroRutinas){
        horaInicio = readEEPROM_HoraInicioRutina(rutinaActual);
        horaFinal = readEEPROM_HoraFinalRutina(rutinaActual);
    
        if(horaInicio > horaFinal){
            return true;
        }
        
        rutinaActual++;
    }
    
    return false;
}

bool checkRutinaHorarioCorrido(uint16_t horaInicio, uint16_t horaFin){
    if(horaInicio > horaFin){
        return true;
    }
    else{
        return false;
    }
}

bool check_rutina_programada(void){
// <editor-fold defaultstate="collapsed" desc="Revisa si existe algun rutina programada">    
    if((RUTINA.numeroRutinas != 0xFF) && (RUTINA.numeroRutinas != 0x00)){
        rutina_programada = true;
    }
    else{
        rutina_programada = false;
    }
    
    control_luces_torreta(); 
    
    return rutina_programada;
// </editor-fold>
}

bool check_MAC_mensaje_entrante(void){
// <editor-fold defaultstate="collapsed" desc="Revisa si la MAC entrante del mensaje es del CRA">
    uint8_t *ptrMensajeRX = serial_cadena;
    uint8_t *ptrMAC_CRA = MAC_CRA;
    uint8_t i = 0;
    bool resultado = true;
    
    for(i = 0; i < 8; i++){
        if(ptrMensajeRX[i + 1] != ptrMAC_CRA[i]){
            resultado = false;
            break;
        }
    }
    
    return resultado;
// </editor-fold> 
}

void save_IEEE_regresar(uint8_t posicion_IEEE){
// <editor-fold defaultstate="collapsed" desc="Guarda el IEEE de la configuracion recibida">
    uint8_t *ptrMensajeRX = serial_cadena;
    uint8_t *ptrIEEE = IEEE_retornar;
    uint8_t i = 0;
    
    for(i = 0; i < 4; i++){
        ptrIEEE[i] = ptrMensajeRX[i + posicion_IEEE];
    }
// </editor-fold> 
}
////*****************/////////
void saveEEPROM_DayAlimentacion(void){
// <editor-fold defaultstate="collapsed" desc="Guarda en la eeprom el dia de alimentacion">
    uint8_t *ptrDAlimentacion = serial_cadena;
    uint8_t dias_alimentacion = 0;
    
    dias_alimentacion = convertASCII_hex(18, 19);
    
    DATAEE_WriteByte(L_DIA_ALIMENTACION_M, dias_alimentacion);
// </editor-fold>
}

void saveEEPROM_HoraInicio(void){
// <editor-fold defaultstate="collapsed" desc="Guarda en la eeprom Hora Inicio">
    uint16_t hora_inicio_minutos = 0;
    uint8_t *ptrMensaje = serial_cadena;
    uint8_t hora_inicio_IEEE[4] = {0};
    uint8_t i = 0;
    
    for(i = 0; i < 4; i++){
        hora_inicio_IEEE[i] = ptrMensaje[20 + i];
    }
    
    hora_inicio_minutos = (uint16_t) (IEEE754_A_Float(hora_inicio_IEEE));
    
    DATAEE_WriteByte(L_HORA_INICIO_M,((uint8_t)((hora_inicio_minutos & 0xFF00) >> 8)));
    DATAEE_WriteByte((L_HORA_INICIO_M + 1), ((uint8_t)(hora_inicio_minutos & 0x00FF)));
// </editor-fold>
}

void saveEEPROM_HoraFin(void){
// <editor-fold defaultstate="collapsed" desc="Guarda en la eeprom Hora de Fin">
    uint16_t hora_final_minutos = 0;
    uint8_t *ptrMensaje = serial_cadena;
    uint8_t hora_final_IEEE[4] = {0};
    uint8_t i = 0;
    
    for(i = 0; i < 4; i++){
        hora_final_IEEE[i] = ptrMensaje[24 + i];
    }
    
    hora_final_minutos = (uint16_t) (IEEE754_A_Float(hora_final_IEEE));
    
    DATAEE_WriteByte(L_HORA_FIN_M, ((uint8_t)((hora_final_minutos & 0xFF00) >> 8)));
    DATAEE_WriteByte((L_HORA_FIN_M + 1), ((uint8_t)(hora_final_minutos & 0x00FF)));
// </editor-fold>
}

void saveEEPROM_IntervaloMinutos(void){
// <editor-fold defaultstate="collapsed" desc="Guarda en la eeprom el tiempo de los intervalos">
    uint16_t intervalo_minutos = 0;
    uint8_t *ptrMensaje = serial_cadena;
    uint8_t intervalo_minutos_IEEE[4] = {0};
    uint8_t i = 0;
    
    for(i = 0; i < 4; i++){
        intervalo_minutos_IEEE[i] = ptrMensaje[28 + i];
    }
    
    intervalo_minutos = (uint16_t) (IEEE754_A_Float(intervalo_minutos_IEEE));
    
    DATAEE_WriteByte(L_INTERVALO_MIN_M, ((uint8_t)((intervalo_minutos & 0xFF00) >> 8)));
    DATAEE_WriteByte((L_INTERVALO_MIN_M + 1), ((uint8_t)(intervalo_minutos & 0x00FF)));
// </editor-fold>
}

void saveEEPROM_DuracionSegundos(void){
// <editor-fold defaultstate="collapsed" desc="Guarda en la eeprom la duracion de la alimentacion">
    uint16_t duracion_segundos = 0;
    uint8_t *ptrMensaje = serial_cadena;
    uint8_t duracion_segundos_IEEE[4] = {0};
    uint8_t i = 0;
    
    for(i = 0; i < 4; i++){
        duracion_segundos_IEEE[i] = ptrMensaje[32 + i];
    }
    
    duracion_segundos = (uint16_t) (IEEE754_A_Float(duracion_segundos_IEEE));
    
    DATAEE_WriteByte(L_DURACION_SEGUNDOS_M, ((uint8_t)((duracion_segundos & 0xFF00) >> 8)));
    DATAEE_WriteByte((L_DURACION_SEGUNDOS_M + 1), ((uint8_t)(duracion_segundos & 0x00FF)));
// </editor-fold>
}

uint16_t readEEPROM_DuracionSegundos(void){
// <editor-fold defaultstate="collapsed" desc="Leer de EEPROM duracion de segundos guardada">
    uint16_t duracion = 0;
    
    duracion = DATAEE_ReadByte(L_DURACION_SEGUNDOS_M);
    duracion = duracion << 8;
    duracion = DATAEE_ReadByte(L_DURACION_SEGUNDOS_M + 1);
    
    return duracion;
// </editor-fold> 
}

///Arreglar variables
void saveEEPROM_VelocidadMinima(void){
// <editor-fold defaultstate="collapsed" desc="Guarda en la eeprom la Velocidad minima">
    uint8_t velocidad_minima = 0;
    uint8_t *ptrMensaje = serial_cadena;
    uint8_t intervalo_minutos_IEEE[4] = {0};
    uint8_t i = 0;
    
    for(i = 0; i < 4; i++){
        intervalo_minutos_IEEE[i] = ptrMensaje[36 + i];
    }
    
    velocidad_minima = (uint8_t)(IEEE754_A_Float(intervalo_minutos_IEEE));
    
    DATAEE_WriteByte(L_VELOCIDAD_MINIMA_M, velocidad_minima);
// </editor-fold>
}

uint8_t readEEPROM_VelocidadMinima(void){
// <editor-fold defaultstate="collapsed" desc="Leer de EEPROM la Velocidad minima guardada">
    return DATAEE_ReadByte(L_VELOCIDAD_MINIMA_M);
// </editor-fold>
}

void saveEEPROM_VelocidadMaxima(void){
// <editor-fold defaultstate="collapsed" desc="Guarda en la eeprom la Velocidad Maxima">
    uint8_t velocidad_maxima = 0;
    uint8_t *ptrMensaje = serial_cadena;
    uint8_t intervalo_minutos_IEEE[4] = {0};
    uint8_t i = 0;
    
    for(i = 0; i < 4; i++){
        intervalo_minutos_IEEE[i] = ptrMensaje[40 + i];
    }
    
    velocidad_maxima = (uint8_t)(IEEE754_A_Float(intervalo_minutos_IEEE));
    
    DATAEE_WriteByte(L_VELOCIDAD_MAXIMA_M, velocidad_maxima);
// </editor-fold>
}

uint8_t readEEPROM_VelocidadMaxima(void){
// <editor-fold defaultstate="collapsed" desc="Leer de EEPROM la Velocidad Maxima guardada">
    return DATAEE_ReadByte(L_VELOCIDAD_MAXIMA_M);
// </editor-fold> 
}

void saveEEPROM_VelocidadDosificador(void){
// <editor-fold defaultstate="collapsed" desc="Guarda en la eeprom la Velocidad del Dosificiador">
    uint8_t velocidad_maxima = 0;
    uint8_t *ptrMensaje = serial_cadena;
    uint8_t intervalo_minutos_IEEE[4] = {0};
    uint8_t i = 0;
    
    for(i = 0; i < 4; i++){
        intervalo_minutos_IEEE[i] = ptrMensaje[44 + i];
    }
    
    velocidad_maxima = (uint8_t)(IEEE754_A_Float(intervalo_minutos_IEEE));
    
    DATAEE_WriteByte(L_VELOCIDAD_DOSIFICADOR, velocidad_maxima);
// </editor-fold>
}

uint8_t readEEPROM_VelocidadDosificador(void){
// <editor-fold defaultstate="collapsed" desc="Leer de EEPROM la Velocidad del Dosificador">
    if(DATAEE_ReadByte(L_VELOCIDAD_MAXIMA_M) > 100){
        DATAEE_WriteByte(L_VELOCIDAD_DOSIFICADOR, 100);
    }
    
    return DATAEE_ReadByte(L_VELOCIDAD_MAXIMA_M);
// </editor-fold> 
}

void saveEEPROM_DistribucionUniforme(void){
// <editor-fold defaultstate="collapsed" desc="Guarda en la eeprom Si hay distribucion uniforme">
    uint8_t *ptrDAlimentacion = serial_cadena;
    uint8_t distribucion_uniforme = 0;
    
    distribucion_uniforme = ptrDAlimentacion[48];
    distribucion_uniforme = decodificar_numero_ASCII(distribucion_uniforme);
    
    DATAEE_WriteByte(L_DISTRIBUCION_UNIFORME_M, distribucion_uniforme);
// </editor-fold>
}

void saveEEPROM_NumeroRutinas_RutinaSimple(void){
    DATAEE_WriteByte(L_CANTIDAD_RUTINAS, 0x01);
}

void saveEEPROM_NumeroRutinas(void){
    DATAEE_WriteByte(L_CANTIDAD_RUTINAS, convertASCII_hex(24, 25));
}

uint8_t readEEPROM_NumeroRutinas(void){
    uint8_t numero_rutinas = DATAEE_ReadByte(L_CANTIDAD_RUTINAS);
    if(numero_rutinas < 25){
        return numero_rutinas;
    }
    else{
        return 0;
    }
}

void saveEEPROM_DayAlimentacion_Multiples(void){
// <editor-fold defaultstate="collapsed" desc="Guarda en la eeprom el dia de alimentacion en rutinas multiples">
    DATAEE_WriteByte(L_DIA_ALIMENTACION_M, convertASCII_hex(18, 19));
}

uint8_t readEEPROM_DayAlimentacion_Multiples(void){
    return DATAEE_ReadByte(L_DIA_ALIMENTACION_M);
}

void saveEEPROM_InicioFinIntervaloDuracionTiempoRutina(uint8_t numero_rutinas){
// <editor-fold defaultstate="collapsed" desc="Guarda en la eeprom Hora Inicio">  
    for(; numero_rutinas > 0; numero_rutinas--){
        saveEEPROM_2Bytes(L_HORA_INICIO_M, (numero_rutinas - 1), 26, serial_cadena); //Guarda la Hora de inicio en EEPROM
        saveEEPROM_2Bytes(L_HORA_FIN_M, (numero_rutinas - 1), 28, serial_cadena);    //Guarda la Hora final en EEPROM
        saveEEPROM_2Bytes(L_INTERVALO_MIN_M, (numero_rutinas - 1), 30, serial_cadena);   //Guarda el intervalo en minutos en EEPROM
        saveEEPROM_2Bytes(L_DURACION_SEGUNDOS_M, (numero_rutinas - 1), 32, serial_cadena);   //Guarda la duracion en segundos en EEPROM
    }
// </editor-fold>
}

uint16_t readEEPROM_HoraInicioRutina(uint8_t numero_rutina){    
    return read_2AddressEEPROM(L_HORA_INICIO_M + (0x10 * (numero_rutina - 1)));
}

uint16_t readEEPROM_HoraFinalRutina(uint8_t numero_rutina){    
    return read_2AddressEEPROM(L_HORA_FIN_M + (0x10 * (numero_rutina - 1)));
}

uint16_t readEEPROM_IntervaloMinutosRutina(uint8_t numero_rutina){    
    return read_2AddressEEPROM(L_INTERVALO_MIN_M + (0x10 * (numero_rutina - 1)));
}

uint16_t readEEPROM_DuracionSegundosRutina(uint8_t numero_rutina){    
    return read_2AddressEEPROM(L_DURACION_SEGUNDOS_M + (0x10 * (numero_rutina - 1)));
}

void saveEEPROM_VelocidadMinMaxDistribucionUniformeGlobal(volatile uint8_t *ptrBufferRX, uint8_t numero_rutinas){
    uint8_t velocidadMinima = ptrBufferRX[20];
    uint8_t velocidadMaxima = ptrBufferRX[21];
    uint8_t velocidadDosificador = ptrBufferRX[22];
    uint8_t distribucionUniforme = decodificar_numero_ASCII(ptrBufferRX[23]);
    uint16_t localidadEEPROM = 0;
    
    for(; numero_rutinas > 0; numero_rutinas--){
        localidadEEPROM = L_VELOCIDAD_MINIMA_M + (0x10 * (numero_rutinas - 1));
        DATAEE_WriteByte(localidadEEPROM, velocidadMinima);
        localidadEEPROM++;
        DATAEE_WriteByte(localidadEEPROM, velocidadMaxima);
        localidadEEPROM++;
        DATAEE_WriteByte(localidadEEPROM, velocidadDosificador);
        localidadEEPROM++;
        DATAEE_WriteByte(localidadEEPROM, distribucionUniforme);
    }
}

uint8_t readEEPROM_VelocidadMinimaRutina(uint8_t numero_rutina){
    return DATAEE_ReadByte(L_VELOCIDAD_MINIMA_M + (0x10 * (numero_rutina - 1)));
}

uint8_t readEEPROM_VelocidadMaximaRutina(uint8_t numero_rutina){
    return DATAEE_ReadByte(L_VELOCIDAD_MAXIMA_M + (0x10 * (numero_rutina - 1)));
}

uint8_t readEEPROM_VelocidadDosificadorRutina(uint8_t numero_rutina){
// <editor-fold defaultstate="collapsed" desc="Leer de EEPROM la Velocidad Maxima guardada">
    if(DATAEE_ReadByte((L_VELOCIDAD_DOSIFICADOR + (0x10 * (numero_rutina - 1)))) > 100){
        DATAEE_WriteByte(L_VELOCIDAD_DOSIFICADOR, 100);
    }
    
    return DATAEE_ReadByte(L_VELOCIDAD_DOSIFICADOR + (0x10 * (numero_rutina - 1)));
// </editor-fold> 
}

bool readEEPROM_DistribucionUniformeRutina(uint8_t numero_rutina){
    uint8_t distribucion = DATAEE_ReadByte(L_DISTRIBUCION_UNIFORME_M + (0x10 * (numero_rutina - 1)));
    
    if(distribucion == 0xFF){
        return 0;
    }
    else{
        return distribucion;
    }
}

void selector_rutina(void){
    uint16_t horaNow = convertTime_minutes();
    
    RUTINA.numeroRutinaActual = buscar_rutina_adecuada(horaNow, RUTINA.numeroRutinas);
    init_struct_rutina_activa(RUTINA.numeroRutinaActual);
    actualizar_struct_rutina_con_rutina_activa();
    hora_next_alimentacion_minutos = getTimeNextAlimentacion(horaNow, RUTINA.inicio_horario, RUTINA.final_horario, RUTINA.intervalo_minutos);    
}

uint8_t buscar_rutina_adecuada(uint16_t horaNow, uint8_t numeroRutinas){
    uint16_t horaInicialRutina1 = readEEPROM_HoraInicioRutina(1);
    uint16_t horaFinal = 0;
    uint8_t rutinaActual = 0;
    
    if((horaNow < horaInicialRutina1) && (flags.horario_corrido)){
            horaNow += 1440;
    }
    
    do{
        rutinaActual++;
        
        horaFinal = readEEPROM_HoraFinalRutina(rutinaActual);
        
        if(horaFinal < horaInicialRutina1){           
            horaFinal += 1440;
        }
        
    }while((horaNow >= horaFinal) && (rutinaActual <= numeroRutinas));
    
    if(rutinaActual > numeroRutinas){
        return 1;
    }
    else{
        return rutinaActual;
    }
}

void create_horario(void){
// <editor-fold defaultstate="collapsed" desc="Crea el horario en el que alimentara en el dia">
    uint16_t hora_minutos_now = convertTime_minutes();
    uint16_t inicio_horario = read_2AddressEEPROM(L_HORA_INICIO);
    uint16_t final_horario = read_2AddressEEPROM(L_HORA_FIN);
    uint16_t intervalo_min = read_2AddressEEPROM(L_INTERVALO_MIN);
    uint16_t duracion_segundos = readEEPROM_DuracionSegundos();
   
    hora_next_alimentacion_minutos = 3000;
    
    if((flags.nueva_rutina_programada) && (inicio_horario <= hora_minutos_now)){
        inicio_horario = hora_minutos_now;
        flags.nueva_rutina_programada = false;
    }
    else{
        flags.nueva_rutina_programada = false;
    }
   
    for(; inicio_horario <= final_horario; inicio_horario = inicio_horario + intervalo_min){
        if((inicio_horario > hora_minutos_now) && (inicio_horario < 1439)){
            hora_next_alimentacion_minutos = inicio_horario;
            break;
        }
    }
// </editor-fold>
}

void create_horario_corrido(void){
// <editor-fold defaultstate="collapsed" desc="Crea el horario en el que alimentara en el dia horario corrido">
    uint16_t hora_minutos_now = convertTime_minutes();
    uint16_t inicio_horario = read_2AddressEEPROM(L_HORA_INICIO);
    uint16_t final_horario = read_2AddressEEPROM(L_HORA_FIN) + 1440;
    uint16_t intervalo_min = read_2AddressEEPROM(L_INTERVALO_MIN);
    uint16_t duracion_segundos = readEEPROM_DuracionSegundos();
    
    hora_next_alimentacion_minutos = 3000;
    if(hora_minutos_now < RUTINA.final_horario){
        hora_minutos_now += 1440;
    }
    
    if((flags.nueva_rutina_programada) && (inicio_horario <= hora_minutos_now)){
        inicio_horario = hora_minutos_now;
        flags.nueva_rutina_programada = false;
    }
    else{
        flags.nueva_rutina_programada = false;
    }
    
    for(; inicio_horario <= final_horario; inicio_horario = inicio_horario + intervalo_min){
        if((inicio_horario > hora_minutos_now) && (inicio_horario < 1440)){
            hora_next_alimentacion_minutos = inicio_horario;
            break;
        }
        else if((((inicio_horario == 1440) && (inicio_horario >= hora_minutos_now)) || (inicio_horario > hora_minutos_now)) 
               && (inicio_horario >= 1440)){
            hora_next_alimentacion_minutos = inicio_horario - 1440;
            break;
        }
    }
// </editor-fold>
}

uint16_t getTimeNextAlimentacion(uint16_t horaNow, uint16_t horaInicio, uint16_t horaFin, uint16_t intervaloMinutos){
    if(checkRutinaHorarioCorrido(horaInicio, horaFin)){
        if(horaNow < horaInicio){
            horaNow += 1440;
        }
        horaFin += 1440;
    }
    
    for(; (horaInicio <= horaFin) && (horaInicio <= horaNow); horaInicio += intervaloMinutos){
        if((horaInicio == 1440) && (horaInicio >= horaNow)){
            break;
        }
    }
    
    if(horaInicio > horaFin){
        return 3000;
    }
    else if(horaInicio > 1439){
        if(horaNow < 1440){
            return horaInicio;
        }
        else{
            return horaInicio - 1440;
        }
    }
    else{
        return horaInicio;
    }
}

//bool revisar_dia_rutina(void){
//// <editor-fold defaultstate="collapsed" desc="Compara si el dia de la semana corresponde a un dia donde se realiza alimentacion">
//    uint8_t dias_alimentacion = DATAEE_ReadByte(L_DIA_ALIMENTACION);
//    uint8_t dia_mascara_resultado = 0;
//    bool rutina_hoy = false;
//    
//    //Seleccionamos la mascara a aplicar segun el dia que sea hoy
//    switch(dia_hoy){
//        case 1:
//            dia_mascara_resultado = dias_alimentacion & 0b00000001;
//            break;
//        case 2:
//            dia_mascara_resultado = dias_alimentacion & 0b00000010;
//            break;
//        case 3:
//            dia_mascara_resultado = dias_alimentacion & 0b00000100;
//            break;
//        case 4:
//            dia_mascara_resultado = dias_alimentacion & 0b00001000;
//            break;
//        case 5:
//            dia_mascara_resultado = dias_alimentacion & 0b00010000;
//            break;
//        case 6:
//            dia_mascara_resultado = dias_alimentacion & 0b00100000;
//            break;
//        case 7:
//            dia_mascara_resultado = dias_alimentacion & 0b01000000;
//            break;
//    }
//    
//    if(dia_mascara_resultado != 0){
//        rutina_hoy = true;
//    }
//    else{
//        rutina_hoy = false;
//    }
//    
//    return rutina_hoy;
//// </editor-fold>
//}

bool revisar_dia_rutina(void){
// <editor-fold defaultstate="collapsed" desc="Compara si el dia de la semana corresponde a un dia donde se realiza alimentacion">
    uint8_t dia_mascara_resultado = 0;
    bool rutina_hoy = false;
    
    //Seleccionamos la mascara a aplicar segun el dia que sea hoy
    switch(dia_hoy){
        case 1:
            dia_mascara_resultado = RUTINA.dias_alimentacion & 0b00000001;
            break;
        case 2:
            dia_mascara_resultado = RUTINA.dias_alimentacion & 0b00000010;
            break;
        case 3:
            dia_mascara_resultado = RUTINA.dias_alimentacion & 0b00000100;
            break;
        case 4:
            dia_mascara_resultado = RUTINA.dias_alimentacion & 0b00001000;
            break;
        case 5:
            dia_mascara_resultado = RUTINA.dias_alimentacion & 0b00010000;
            break;
        case 6:
            dia_mascara_resultado = RUTINA.dias_alimentacion & 0b00100000;
            break;
        case 7:
            dia_mascara_resultado = RUTINA.dias_alimentacion & 0b01000000;
            break;
    }
    
    if(dia_mascara_resultado != 0){
        rutina_hoy = true;
    }
    else{
        rutina_hoy = false;
    }
    
    return rutina_hoy;
// </editor-fold>
}

uint16_t read_2AddressEEPROM(uint16_t localidad_eeprom){
// <editor-fold defaultstate="collapsed" desc="Devuelve el valor de la localidad EEPROM seleccionada y la siguiente en 16 bits HB-8 LB-8">
    uint16_t data = 0;
    
    data = DATAEE_ReadByte(localidad_eeprom);
    data = data << 8;
    data = data + DATAEE_ReadByte(localidad_eeprom + 1);
    
    return data;
// </editor-fold>
}

void crear_mensaje(uint8_t *ptrMAC, uint8_t *ptrMensaje, uint8_t tamanio_mensaje){
// <editor-fold defaultstate="collapsed" desc="Crea mensaje para enviar por xbee">
    tamanio_mensajeTX_completo = 0;   ////********
    uint8_t i = 0;
    
    mensaje_TX_completo[0] = 0x00;  //Frame Type
    mensaje_TX_completo[1] = 0x01;  //Frame ID
    //Incluyendo MAC 8 Bytes
    for(i = 0; i < 8; i++){
        mensaje_TX_completo[i + 2] = ptrMAC[i];
    }
    mensaje_TX_completo[10] = 0x00; //Options
    //Incluyendo Mensaje
    for(i = 0; i < tamanio_mensaje; i++){
        mensaje_TX_completo[i + 11] = ptrMensaje[i];
    }
    
    tamanio_mensajeTX_completo = i + 11;
// </editor-fold>                 
}

uint8_t convertYear_hex(void){
// <editor-fold defaultstate="collapsed" desc="Convertir a�o a hexadecimal">
    uint8_t year = 0;
    
    //Decimal a�o
    year = convertASCII_hex(18, 19);
    
    return year;
// </editor-fold>
}

uint8_t convertMonth_hex(void){
// <editor-fold defaultstate="collapsed" desc="Convertir mes a hexadecimal">
    uint8_t month = 0;
    
    month = convertASCII_hex(20, 21);
    
    return month;
// </editor-fold>
}

uint8_t convertDate_hex(void){
// <editor-fold defaultstate="collapsed" desc="Convertir dia del mes a hexadecimal">
    uint8_t date = 0;
    
    date = convertASCII_hex(22, 23);
    
    return date;
// </editor-fold>
}

uint8_t convertDayWeek_hex(void){
// <editor-fold defaultstate="collapsed" desc="Convertir dia de la semana a hexadecimal">
    uint8_t day_week = 0;
    
    day_week = convertASCII_hex(24, 25);
    
    return day_week;
// </editor-fold>
}

uint8_t convertHour_hex(void){
// <editor-fold defaultstate="collapsed" desc="Configurar hora a hexadecimal">
    uint8_t hour = 0;
    
    hour = convertASCII_hex(26, 27);
    
    return hour;
// </editor-fold>
}

uint8_t convertMinutes_hex(void){
// <editor-fold defaultstate="collapsed" desc="Configurar minutos a hexadecimal">
    uint8_t minutes = 0;
    
    minutes = convertASCII_hex(28, 29);
    
    return minutes;
// </editor-fold>
}

uint8_t convertSeconds_hex(void){
// <editor-fold defaultstate="collapsed" desc="Configurar segundos a hexadecimal">
    uint8_t seconds = 0;
    
    seconds = convertASCII_hex(30, 31);
    
    return seconds;
// </editor-fold>
}

uint8_t convertASCIItoDecimal(volatile uint8_t *ptrBufferRX, uint8_t lugar_cadena_decimal, uint8_t lugar_cadena_unidad){
    uint8_t numero = 0;
    
    //Decimal
    numero = decodificar_numero_ASCII(ptrBufferRX[lugar_cadena_decimal]);
    numero = numero * 10;
    //Unidades
    numero = numero + decodificar_numero_ASCII(ptrBufferRX[lugar_cadena_unidad]);
    
    return numero;
}

uint8_t convertASCII_hex(uint8_t lugar_cadena_decimal, uint8_t lugar_cadena_unidad){
// <editor-fold defaultstate="collapsed" desc="Convierter el numero ASCII decimales y unidades a su equivalente hexadecimal">
    uint8_t *ptrASCII = serial_cadena;
    uint8_t numero = 0;
    
    //Decimal
    numero = decodificar_numero_ASCII(ptrASCII[lugar_cadena_decimal]);
    numero = numero << 4;
    //Unidades
    numero = numero + decodificar_numero_ASCII(ptrASCII[lugar_cadena_unidad]);
    
    return numero;
// </editor-fold>
}

uint8_t convertHex_ASCII(uint8_t hex){
// <editor-fold defaultstate="collapsed" desc="Convertir Hexadecimal a letra o numero ASCII">
    uint8_t ASCII = 0;
    
    if(hex <= 0x09){
        ASCII = hex + 0x30;
    }
    else if(hex >= 0x0A){
        ASCII = hex + 0x37;
    }
    
    return ASCII;
// </editor-fold> 
}

uint8_t decodificar_numero_ASCII(uint8_t ASCII){
// <editor-fold defaultstate="collapsed" desc="Convierte cualquier numero ASCII a hexadecimal">
    uint8_t numero_hex = 0;
    
    switch(ASCII){
        case '0':
            numero_hex = 0x00;
            break;
        case '1':
            numero_hex = 0x01;
            break;
        case '2':
            numero_hex = 0x02;
            break;
        case '3':
            numero_hex = 0x03;
            break;
        case '4':
            numero_hex = 0x04;
            break;
        case '5':
            numero_hex = 0x05;
            break;
        case '6':
            numero_hex = 0x06;
            break;
        case '7':
            numero_hex = 0x07;
            break;
        case '8':
            numero_hex = 0x08;
            break;
        case '9':
            numero_hex = 0x09;
            break;
        case 'A':
            numero_hex = 0x0A;
            break;
        case 'B':
            numero_hex = 0x0B;
            break;
        case 'C':
            numero_hex = 0x0C;
            break;
        case 'D':
            numero_hex = 0x0D;
            break;
        case 'E':
            numero_hex = 0x0E;
            break;
        case 'F':
            numero_hex = 0x0F;
            break;
    }
    return numero_hex;
// </editor-fold>
}

void create_mensaje_hora(void){
// <editor-fold defaultstate="collapsed" desc="Crea mensaje el TX_data de la hora que se enviara en el mensaje con la Info de la Rutina">
    mensaje_TX_data[0] = ID_ALIMENTADOR_GLOBAL;
    mensaje_TX_data[1] = 'H';  
    mensaje_TX_data[2] = 'R';
    mensaje_TX_data[3] = ID_ALIMENTADOR_ASCII1;
    mensaje_TX_data[4] = ID_ALIMENTADOR_ASCII2;
    mensaje_TX_data[5] = ID_ALIMENTADOR_ASCII3;
    mensaje_TX_data[6] = getYear_RTC();
    mensaje_TX_data[7] = getMonth_RTC();
    mensaje_TX_data[8] = getDate_RTC();
    mensaje_TX_data[9] = getDay_RTC();
    mensaje_TX_data[10] = getHour_RTC();
    mensaje_TX_data[11] = getMinutes_RTC();
    mensaje_TX_data[12] = getSeconds_RTC();
    mensaje_TX_data[13] = RTC.fallo_rtc;
    
    tamanio_mensaje_data = 14;
// </editor-fold> 
}

void create_mensaje_version_firmware(void){
// <editor-fold defaultstate="collapsed" desc="Crea mensaje el TX_data que se enviara en el mensaje con la Info de la Rutina">
    
    //ID_
    mensaje_TX_data[0] = ID_ALIMENTADOR_GLOBAL;
    mensaje_TX_data[1] = 'F';  
    mensaje_TX_data[2] = 'W';
    mensaje_TX_data[3] = ID_ALIMENTADOR_ASCII1;
    mensaje_TX_data[4] = ID_ALIMENTADOR_ASCII2;
    mensaje_TX_data[5] = ID_ALIMENTADOR_ASCII3;
    mensaje_TX_data[6] = VERSION_FIRMWARE_1;
    mensaje_TX_data[7] = VERSION_FIRMWARE_2;
    mensaje_TX_data[8] = VERSION_FIRMWARE_3;
    
    tamanio_mensaje_data = 9;
// </editor-fold> 
}

void send_hora_alimentador(void){
// <editor-fold defaultstate="collapsed" desc="Envia version la hora que tenga el alimentador">
    save_MAC_InfoRutina();
    create_mensaje_hora();
    enviar_mensaje_TX_InfoRutina();
// </editor-fold>
}

void send_version_firmware(void){
// <editor-fold defaultstate="collapsed" desc="Envia version del Firmware">
    save_MAC_InfoRutina();
    create_mensaje_version_firmware();
    enviar_mensaje_TX_InfoRutina();
// </editor-fold>
}

void enviar_mensaje_TX_xbee(void){
// <editor-fold defaultstate="collapsed" desc="Mensaje de transmitido xbee">
    uint8_t *ptrMensaje = mensaje_TX;
    uint16_t ADC16_PBateria = getADC_promediado(P_BATERIA);
    uint16_t ADC16_Bateria = getADC_promediado(BATERIA);
    uint16_t ADC16_M1 = getADC_promediado(A_MT1);
    uint16_t ADC16_M2 = getADC_promediado(A_MT2);
    uint16_t ADC16_Panel = getADC_promediado(PANEL);
    
    ptrMensaje[0] = ID_ALIMENTADOR_GLOBAL;
    ptrMensaje[1] = ID_ALIMENTADOR_ASCII1;
    ptrMensaje[2] = ID_ALIMENTADOR_ASCII2;
    ptrMensaje[3] = ID_ALIMENTADOR_ASCII3;
    ptrMensaje[4] = fallo;
    ptrMensaje[5] = dia_hoy;
    ptrMensaje[6] = getYear_RTC();
    ptrMensaje[7] = getMonth_RTC();
    ptrMensaje[8] = getDate_RTC();
    ptrMensaje[9] = getDay_RTC();
    ptrMensaje[10] = getHour_RTC();
    ptrMensaje[11] = getMinutes_RTC();
    ptrMensaje[12] = getSeconds_RTC();
    ptrMensaje[13] = 0xBA;
    ptrMensaje[14] = (uint8_t)(ADC16_PBateria >> 8);
    ptrMensaje[15] = (uint8_t)(ADC16_PBateria);
    ptrMensaje[16] = (uint8_t)(ADC16_Panel >> 8);
    ptrMensaje[17] = (uint8_t)(ADC16_Panel);
    ptrMensaje[18] = (uint8_t)(ADC16_M1 >> 8);
    ptrMensaje[19] = (uint8_t)(ADC16_M1);
    ptrMensaje[20] = (uint8_t)(ADC16_M2 >> 8);
    ptrMensaje[21] = (uint8_t)(ADC16_M2);
    ptrMensaje[22] = (uint8_t)(tiempo_transcurrido_parpadeo >> 8);
    ptrMensaje[23] = (uint8_t)(tiempo_transcurrido_parpadeo);
    
    crear_mensaje(MAC_Monitor, mensaje_TX, sizeof(mensaje_TX));
    
    //Byte que delimita el principio el mensaje
    UART1_Write(0x7E);
    
    //Cantidad de bytes enviados
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo >> 8));
    UART1_Write((uint8_t) (tamanio_mensajeTX_completo));
    
    //Envio de mensaje
    enviar_cadena_USART1(mensaje_TX_completo, tamanio_mensajeTX_completo);
    
    //Calcula y envia el checksum
    UART1_Write(calculate_checksum(mensaje_TX_completo, tamanio_mensajeTX_completo));
    
    mensaje_enviado = true;
    
// </editor-fold>   
}