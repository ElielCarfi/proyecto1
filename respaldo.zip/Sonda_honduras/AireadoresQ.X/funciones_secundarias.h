/* 
 * File:   funciones_secundarias.h
 * Author: acuic
 *
 * Created on 19 de julio de 2022, 04:27 PM
 */

#ifndef FUNCIONES_SECUNDARIAS_H
#define	FUNCIONES_SECUNDARIAS_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <stdint.h>
#include "mcc_generated_files/mcc.h"
#include "Float_IEEE754.h"

void saveEEPROM_2Bytes(uint16_t localidadEEPROM, uint8_t numero_rutina, uint8_t posicionDato1HB, uint8_t *ptrBufferRX);

uint16_t compesancionTiempoNuevaRutina(uint16_t horaNextAlimentacion, uint16_t horaNow);

#ifdef	__cplusplus
}
#endif

#endif	/* FUNCIONES_SECUNDARIAS_H */

