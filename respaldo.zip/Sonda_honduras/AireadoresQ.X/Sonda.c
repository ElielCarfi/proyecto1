
#include "Sonda.h"

void init_sonda(void){
// <editor-fold defaultstate="collapsed" desc="Init sonda">
    initStructEstanque1();
//    initStructEstanque2();
            
    RS485_IDLE;
   
    COMANDO = Config(COMANDO, ID_EN_COMANDO, carga_comando);                                     
    estado_estanques = obtener_estado_estanques();
    readSensoresConectadosEstanque1();
    intervaloMediciones = readTimeMeasurements();
    
    getLecturasSeteadasEEPROM(obtener_id_estanque(1));
//   if (estado_estanques == 0) {//Activa desactiva alimentacion sensores sonda
//      output_high(ENABLE_2); 
//   } else output_low(ENABLE_2);
    for(uint8_t i = 0; i < 200; i++){
        TOGGLE_LED_ROJO
        __delay_ms(100);
    }
    #ifdef  ALIMENTADOR_CON_SONDA
//    getKBSaturacion(0x01);
//    getSoftwareHardwareVersion(0x01);
//    desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x01);                              
//    desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x02); //Descomentar luego sensor de salinidad y conductividad
    #else
    if(estado_estanques == 1){
        desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x01);                              
        desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x02);                                     
    }
    else if(estado_estanques == 2){
        desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x03);
        desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x04);
    }
    else if (estado_estanques == 3){
        desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x01);                                
        desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x02);
        desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x03);
        desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x04);
    }
    #endif
    controlLedTomandoLecturas();
    tomar_lecturas();
    timeNextMedicion = calculoNextMedicion();
    diaHoySonda = getDay_RTC();
//Posible borrado no se ocupa guardar mac    obtener_mac();                                                                               //Obtengo macs guardadas y las pongo en DAL
    COMANDO = DORMIR_SONDA;                                                                      //Inicio con la sonda en este modo                                                                                 //Inicio comunicacion con monitor
// </editor-fold>
}

void main_sonda(void){
// <editor-fold defaultstate="collapsed" desc="main_sonda">
//    if (mensajeNuevo == 1) COMANDO = decodificar_comandos(buffer);                            //Busca si se recibio alguna peticion o comando      
      
//    COMANDO = Config(COMANDO, ID_EN_COMANDO, carga_comando);
    
    controlTomarLecturas();
    
//    if(COMANDO == DORMIR_SONDA) {
//        sleep_sonda();
//    }
      
//    //Ejecuto si el sistema necesita tomar lecturas o si se le ordeno tomar lectura de algun estanque
//    if((COMANDO == TOMAR_LECTURAS) || (COMANDO == T_E_LECTURAS) || (BOTON_FUNC3 == 0)){          
//        timeNextMedicion = intervaloMediciones + tomar_lecturas();
//    }
    
    while(FLAGS_SONDA.modoConfiguration){
        if((COMANDO == TOMAR_LECTURAS) || (COMANDO == T_E_LECTURAS) || (BOTON_FUNC3 == 0)){  
            LED_VERDE
            LED_ROJO_APAGADO
            tomar_lecturas();
            LED_VERDE_APAGADO
        }
        else if((COMANDO == CALIBRAR_TEMP_L) || (COMANDO == CALIBRAR_O2_L) || (COMANDO == CALIBRAR_SAL_L) || (COMANDO == CALIBRAR_CON_L) ||
                (COMANDO == CALIBRAR_TEMP_H) || (COMANDO == CALIBRAR_O2_H) || (COMANDO == CALIBRAR_SAL_H) || (COMANDO == CALIBRAR_CON_H)) {
            LED_VERDE
            LED_ROJO_APAGADO
            calibracion();
            LED_VERDE_APAGADO
        }
        else if(FLAGS_SONDA.configPuntoBajoAlto){
            configHighLowPointCalibration();
            FLAGS_SONDA.configPuntoBajoAlto = false;
        }
        else if(FLAGS_SONDA.configFrecuenciaMediciones){
            configTimeMeasurements();
            FLAGS_SONDA.configFrecuenciaMediciones = false;
        }
        for(uint8_t i = 0; ((i < 100) && (FLAGS_SONDA.modoConfiguration)); i++){
            __delay_ms(1);
        }
        TOGGLE_LED_VERDE
        TOGGLE_LED_ROJO
        for(uint8_t i = 0; ((i < 100) && (FLAGS_SONDA.modoConfiguration)); i++){
            __delay_ms(1);
        }
        if(!FLAGS_SONDA.modoConfiguration){
            LED_VERDE_APAGADO
            LED_ROJO_APAGADO
        }
    }
//    if((COMANDO == ESPERAR_PETICION) || (COMANDO == PROG_T_L)) { 
//        esperar_peticion();
//    }
      
//    if(!FUNC1 || !FUNC2 || !FUNC3){
//        if (!FUNC1) {
//            ID_EN_COMANDO = ESTANQUE1.id;
//            BOTON_FUNC1 = 0;
//            __delay_ms(1000);            
//        } else if (!FUNC2) {
////            ID_EN_COMANDO = ESTANQUE2.id;
////            BOTON_FUNC2 = 0;
//            COMANDO = CALIBRAR_TEMP_L;
//            __delay_ms(1000);            
//        } else if (!FUNC3) {
//            COMANDO = TOMAR_LECTURAS;
//            BOTON_FUNC3 = 0;
//            __delay_ms(1000);            
//        } 
//    } else BOTON_FUNC1 = 1,BOTON_FUNC2 = 1,BOTON_FUNC3 = 1;
// </editor-fold>
}

void initStructEstanque1(void){
// <editor-fold defaultstate="collapsed" desc="Inicializacion Struct Estanque 1">
    ESTANQUE1.id = 0;
    ESTANQUE1.amonio = 0;
    ESTANQUE1.conductividad = 0;
    ESTANQUE1.ion_amonio = 0;
    ESTANQUE1.o2 = 0;
    ESTANQUE1.orp = 0;
    ESTANQUE1.ph = 0;
    ESTANQUE1.potasio = 0;
    ESTANQUE1.salinidad = 0;
    ESTANQUE1.saturacion = 0;
    ESTANQUE1.temperatura = 0;
// </editor-fold>
}

void resetMedicionesEstanque1(void){
// <editor-fold defaultstate="collapsed" desc="Resetea la mediciones de la Structura Estanque 1">
    ESTANQUE1.amonio = 0;
    ESTANQUE1.conductividad = 0;
    ESTANQUE1.ion_amonio = 0;
    ESTANQUE1.o2 = 0;
    ESTANQUE1.orp = 0;
    ESTANQUE1.ph = 0;
    ESTANQUE1.potasio = 0;
    ESTANQUE1.salinidad = 0;
    ESTANQUE1.saturacion = 0;
    ESTANQUE1.temperatura = 0;
// </editor-fold>
}

void initStructEstanque2(void){
// <editor-fold defaultstate="collapsed" desc="Inicializacion Struct Estanque 2">
    ESTANQUE2.id = 0;
    ESTANQUE2.amonio = 0;
    ESTANQUE2.conductividad = 0;//
    ESTANQUE2.ion_amonio = 0;
    ESTANQUE2.o2 = 0;//
    ESTANQUE2.orp = 0;
    ESTANQUE2.ph = 0;//
    ESTANQUE2.potasio = 0;
    ESTANQUE2.salinidad = 0;//
    ESTANQUE2.saturacion = 0;//
    ESTANQUE2.temperatura = 0;//
// </editor-fold>
}

void resetMedicionesEstanque2(void){
// <editor-fold defaultstate="collapsed" desc="Resetea la mediciones de la Structura Estanque 2">
    ESTANQUE2.amonio = 0;
    ESTANQUE2.conductividad = 0;//
    ESTANQUE2.ion_amonio = 0;
    ESTANQUE2.o2 = 0;//
    ESTANQUE2.orp = 0;
    ESTANQUE2.ph = 0;//
    ESTANQUE2.potasio = 0;
    ESTANQUE2.salinidad = 0;//
    ESTANQUE2.saturacion = 0;//
    ESTANQUE2.temperatura = 0;//
// </editor-fold>
}

void accionesSonda(uint8_t identificadorAccion1, uint8_t identificadorAccion2){
    if((identificadorAccion1 == SOLICITUD_MEDICIONES_ASCII1) && (identificadorAccion2 == SOLICITUD_MEDICIONES_ASCII2)){
        sendMediciones();
    }
    else if((identificadorAccion1 == RESET_SONDA_ASCII1) && (identificadorAccion2 == RESET_SONDA_ASCII2)){
        resetSonda();
    }
    else if((identificadorAccion1 == ESPECIFICA_SENSORES_SONDA_ASCII1) && (identificadorAccion2 == ESPECIFICA_SENSORES_SONDA_ASCII2)){
        if(FLAGS_SONDA.modoConfiguration) configurarSensoresConectados(0x01);
    }
    else if((identificadorAccion1 == ENTRAR_MODO_CONFIGURACION_ASCII1) && (identificadorAccion2 == ENTRAR_MODO_CONFIGURACION_ASCII2)){
        FLAGS_SONDA.modoConfiguration = true;
        LED_VERDE_APAGADO
        LED_ROJO_APAGADO
        mensaje_respuesta_OK(18);
    }
    else if((identificadorAccion1 == SALIR_MODO_CONFIGURACION_ASCII1) && (identificadorAccion2 == SALIR_MODO_CONFIGURACION_ASCII2)){
        FLAGS_SONDA.modoConfiguration = false;
        mensaje_respuesta_OK(18);
    }
    else if((identificadorAccion1 == SOLICITAR_MEDICIONES_SENSOR_ASCII1) && (identificadorAccion2 == SOLICITAR_MEDICIONES_SENSOR_ASCII2)){
        activarSolicitudMediciones();
    }
    else if((identificadorAccion1 == DESHABILITAR_LECTURA_ASCII1) && (identificadorAccion2 == DESHABILITAR_LECTURA_ASCII2)){
        NOP();//Cambiar
    }
    else if((identificadorAccion1 == ACTIVAR_LECTURA_ASCII1) && (identificadorAccion2 == ACTIVAR_LECTURA_ASCII2)){
        NOP();//Cambiar
        NOP();
    }
    else if((identificadorAccion1 == CONFIG_FRECUENCIA_TOMA_MEDICIONES_ASCII1) && (identificadorAccion2 == CONFIG_FRECUENCIA_TOMA_MEDICIONES_ASCII2)){
        if(FLAGS_SONDA.modoConfiguration) FLAGS_SONDA.configFrecuenciaMediciones = true;
    }
    else if((identificadorAccion1 == PUNTO_BAJO_ALTO_CALIBRACION_SONDA_ASCII1) && (identificadorAccion2 == PUNTO_BAJO_ALTO_CALIBRACION_SONDA_ASCII2)){
        if(FLAGS_SONDA.modoConfiguration) FLAGS_SONDA.configPuntoBajoAlto = true;
    }
    else if((identificadorAccion1 == RESPUESTA_INFO_CONFIGURACION_ASCII1) && (identificadorAccion2 == RESPUESTA_INFO_CONFIGURACION_ASCII2)){
        sendInfoConfiguration();
    }
}

void createMensajeMediciones(void){
// <editor-fold defaultstate="collapsed" desc="Crea el mensaje de mensaje de mediciones">
    uint8_t tamanioMensaje = 14; //11 Por el tama�o del mensaje por defecto
    uint16_t sensoresConectados = obtener_config_sensores(obtener_id_estanque(1));
    uint32_t data32_IEE = 0;
    
    dataTX[11] = ID_GLOBAL_SONDA;
    dataTX[12] = SOLICITUD_MEDICIONES_ASCII1;
    dataTX[13] = SOLICITUD_MEDICIONES_ASCII2;
    dataTX[14] = ID_SONDA_ASCII1;
    dataTX[15] = ID_SONDA_ASCII2;
    dataTX[16] = ID_SONDA_ASCII3;
    dataTX[17] = ESTANQUE1_HORA.dia_del_mes;
    dataTX[18] = ESTANQUE1_HORA.mes;
    dataTX[19] = ESTANQUE1_HORA.hora;
    dataTX[20] = ESTANQUE1_HORA.minutos;
    dataTX[21] = ESTANQUE1_HORA.segundos;
    dataTX[22] = convertHex_ASCII((uint8_t)(sensoresConectados >> 8));
    dataTX[23] = convertHex_ASCII((uint8_t)((sensoresConectados & 0x00F0) >> 4));
    dataTX[24] = convertHex_ASCII((uint8_t)(sensoresConectados & 0x000F));
    if(Sonda.sensorTemperatura){
        data32_IEE = float_a_IEEE754((float) ESTANQUE1.temperatura);
        dataTX[tamanioMensaje + 11] = (uint8_t)(data32_IEE >> 24);
        dataTX[tamanioMensaje + 12] = (uint8_t)(data32_IEE >> 16);
        dataTX[tamanioMensaje + 13] = (uint8_t)(data32_IEE >> 8);
        dataTX[tamanioMensaje + 14] = (uint8_t)(data32_IEE);
        tamanioMensaje += 4;
    }
    if(Sonda.sensorO2){
        data32_IEE = float_a_IEEE754((float) ESTANQUE1.o2);
        dataTX[tamanioMensaje + 11] = (uint8_t)(data32_IEE >> 24);
        dataTX[tamanioMensaje + 12] = (uint8_t)(data32_IEE >> 16);
        dataTX[tamanioMensaje + 13] = (uint8_t)(data32_IEE >> 8);
        dataTX[tamanioMensaje + 14] = (uint8_t)(data32_IEE);
        tamanioMensaje += 4;
    }
    if(Sonda.sensorSaturacion){
        data32_IEE = float_a_IEEE754((float) ESTANQUE1.saturacion);
        dataTX[tamanioMensaje + 11] = (uint8_t)(data32_IEE >> 24);
        dataTX[tamanioMensaje + 12] = (uint8_t)(data32_IEE >> 16);
        dataTX[tamanioMensaje + 13] = (uint8_t)(data32_IEE >> 8);
        dataTX[tamanioMensaje + 14] = (uint8_t)(data32_IEE);
        tamanioMensaje += 4;
    }
    if(Sonda.sensorSalinidad){
        data32_IEE = float_a_IEEE754((float) ESTANQUE1.salinidad);
        dataTX[tamanioMensaje + 11] = (uint8_t)(data32_IEE >> 24);
        dataTX[tamanioMensaje + 12] = (uint8_t)(data32_IEE >> 16);
        dataTX[tamanioMensaje + 13] = (uint8_t)(data32_IEE >> 8);
        dataTX[tamanioMensaje + 14] = (uint8_t)(data32_IEE);
        tamanioMensaje += 4;
    }
    if(Sonda.sensorConductividad){
        data32_IEE = float_a_IEEE754((float) ESTANQUE1.conductividad);
        dataTX[tamanioMensaje + 11] = (uint8_t)(data32_IEE >> 24);
        dataTX[tamanioMensaje + 12] = (uint8_t)(data32_IEE >> 16);
        dataTX[tamanioMensaje + 13] = (uint8_t)(data32_IEE >> 8);
        dataTX[tamanioMensaje + 14] = (uint8_t)(data32_IEE);
        tamanioMensaje += 4;
    }
    if(Sonda.sensorPh){
        data32_IEE = float_a_IEEE754((float) ESTANQUE1.ph);
        dataTX[tamanioMensaje + 11] = (uint8_t)(data32_IEE >> 24);
        dataTX[tamanioMensaje + 12] = (uint8_t)(data32_IEE >> 16);
        dataTX[tamanioMensaje + 13] = (uint8_t)(data32_IEE >> 8);
        dataTX[tamanioMensaje + 14] = (uint8_t)(data32_IEE);
        tamanioMensaje += 4;
    }
    if(Sonda.sensorOrp){
        data32_IEE = float_a_IEEE754((float) ESTANQUE1.orp);
        dataTX[tamanioMensaje + 11] = (uint8_t)(data32_IEE >> 24);
        dataTX[tamanioMensaje + 12] = (uint8_t)(data32_IEE >> 16);
        dataTX[tamanioMensaje + 13] = (uint8_t)(data32_IEE >> 8);
        dataTX[tamanioMensaje + 14] = (uint8_t)(data32_IEE);
        tamanioMensaje += 4;
    }
    if(Sonda.sensorAmonio){
        data32_IEE = float_a_IEEE754((float) ESTANQUE1.amonio);
        dataTX[tamanioMensaje + 11] = (uint8_t)(data32_IEE >> 24);
        dataTX[tamanioMensaje + 12] = (uint8_t)(data32_IEE >> 16);
        dataTX[tamanioMensaje + 13] = (uint8_t)(data32_IEE >> 8);
        dataTX[tamanioMensaje + 14] = (uint8_t)(data32_IEE);
        tamanioMensaje += 4;
    }
    if(Sonda.sensorAmoniaco){
        data32_IEE = float_a_IEEE754((float) ESTANQUE1.amoniaco);
        dataTX[tamanioMensaje + 11] = (uint8_t)(data32_IEE >> 24);
        dataTX[tamanioMensaje + 12] = (uint8_t)(data32_IEE >> 16);
        dataTX[tamanioMensaje + 13] = (uint8_t)(data32_IEE >> 8);
        dataTX[tamanioMensaje + 14] = (uint8_t)(data32_IEE);
        tamanioMensaje += 4;
    }
    if(Sonda.sensorPotasio){
        data32_IEE = float_a_IEEE754((float) ESTANQUE1.potasio);
        dataTX[tamanioMensaje + 11] = (uint8_t)(data32_IEE >> 24);
        dataTX[tamanioMensaje + 12] = (uint8_t)(data32_IEE >> 16);
        dataTX[tamanioMensaje + 13] = (uint8_t)(data32_IEE >> 8);
        dataTX[tamanioMensaje + 14] = (uint8_t)(data32_IEE);
        tamanioMensaje += 4;
    }
    
    completarMensajeEnviar(MAC_InfoRutina, tamanioMensaje);  //Varibale MAC_InfoRutina en funciones compartidas *******
// </editor-fold>
}

void sendMediciones(void){
// <editor-fold defaultstate="collapsed" desc="Envia las mediciones la MAC de quien se la pide">
    save_MAC_InfoRutina();
    createMensajeMediciones();
    enviarMensajeTX_Xbee();
// </editor-fold>
}

void createInfoConfiguration(void){
// <editor-fold defaultstate="collapsed" desc="Crea el mensaje de configuracion de la sonda">
    uint32_t data32_IEEE = 0;
    uint16_t sensoresConectados = obtener_config_sensores(obtener_id_estanque(1));
    
    dataTX[11] = ID_GLOBAL_SONDA;
    dataTX[12] = RESPUESTA_INFO_CONFIGURACION_ASCII1;
    dataTX[13] = RESPUESTA_INFO_CONFIGURACION_ASCII2;
    dataTX[14] = ID_SONDA_ASCII1;
    dataTX[15] = ID_SONDA_ASCII2;
    dataTX[16] = ID_SONDA_ASCII3;
    dataTX[17] = convertHex_ASCII((uint8_t)(sensoresConectados >> 8));
    dataTX[18] = convertHex_ASCII((uint8_t)((sensoresConectados & 0x00F0) >> 4));
    dataTX[19] = convertHex_ASCII((uint8_t)(sensoresConectados & 0x000F));
    dataTX[20] = '1';
    data32_IEEE = float_a_IEEE754((float) (intervaloMediciones));
    dataTX[21] = (uint8_t)(data32_IEEE >> 24);
    dataTX[22] = (uint8_t)(data32_IEEE >> 16);
    dataTX[23] = (uint8_t)(data32_IEEE >> 8);
    dataTX[24] = (uint8_t)(data32_IEEE);
    dataTX[25] = DATAEE_ReadByte(L_VALOR_LECTURA_SALINIDAD);   //IEEE Salinidad configurada
    dataTX[26] = DATAEE_ReadByte(L_VALOR_LECTURA_SALINIDAD + 1);
    dataTX[27] = DATAEE_ReadByte(L_VALOR_LECTURA_SALINIDAD + 2);
    dataTX[28] = DATAEE_ReadByte(L_VALOR_LECTURA_SALINIDAD + 3);
    dataTX[29] = '1';
    
    completarMensajeEnviar(MAC_InfoRutina, 19);
// </editor-fold>
}

void sendInfoConfiguration(void){
// <editor-fold defaultstate="collapsed" desc="Envia la configuracion a la MAC de quien se la pide">
    save_MAC_InfoRutina();
    createInfoConfiguration();
    enviarMensajeTX_Xbee();
// </editor-fold>
}

void saveHoraMediciones(struct horaMediciones *estanque){
// <editor-fold defaultstate="collapsed" desc="Guarda la fecha y hora en la estructura ESTANQUEX_HORA">    
    estanque->mes = getMonth_RTC();
    estanque->dia_del_mes = getDate_RTC();
    estanque->hora = getHour_RTC();
    estanque->minutos = getMinutes_RTC();
    estanque->segundos = getSeconds_RTC();
// </editor-fold>
}

void activarSolicitudMediciones(void){
    COMANDO = TOMAR_LECTURAS;
}

void guardar_id_estanques(uint16_t comandos, char *datos) {
// <editor-fold defaultstate="collapsed" desc="Guarda ID de los estanques">
    char data[7] = {0};
    uint16_t ID1 = 0, ID2 = 0;
   
    if(comandos == CAMBIAR_ID_UNICO){
        data[0] = '0';
        data[1] = 'X';
        data[2] = datos[0];
        data[3] = datos[1];
        data[4] = datos[2];
        data[5] = 0;
        ID1 = atol(data);
        saveEEPROM_ID1(ID1);
        saveEEPROM_ID2(ID2);
    } 
    else if(comandos == CAMBIAR_ID_DOBLE){
        data[0] = '0';
        data[1] = 'X';
        data[2] = datos[0];
        data[3] = datos[1];
        data[4] = datos[2];
        data[5] = 0;
        ID1 = atol(data);
        saveEEPROM_ID1(ID1);
        data[0] = '0';
        data[1] = 'X';
        data[2] = datos[3];
        data[3] = datos[4];
        data[4] = datos[5];
        data[5] = 0;
        ID2 = atol(data);
        saveEEPROM_ID2(ID2);
   }
// </editor-fold>
}

uint16_t obtener_id_estanque(uint8_t estanque) {
// <editor-fold defaultstate="collapsed" desc="Obtiene el ID del estanque">
   uint16_t ID_estanque = 0;
   
   if(estanque == 1){
        ID_estanque = readEEPROM_ID1_estanque();
   }
   else if(estanque == 2){
        ID_estanque = readEEPROM_ID2_estanque();
   }
   else{
        ID_estanque = 0;
   }
   
   return ID_estanque;
// </editor-fold>
}

//Posible Borrar, fallo en datos[i] ver funcion internamente
//void guardar_mac_dispositivo_configurador(void){
//// <editor-fold defaultstate="collapsed" desc="Guarda la MAC del Dispositivo Configurador">
////void guardar_mac(int16 comandos, char *datos) {
//    uint8_t i = 0;
//   
////   if (comandos == CONFIG_SONDA) {
//    for(; i < 8; i++){
//        DATAEE_WriteByte((L_MAC_DISPOSITIVO_CONFIGURADOR + i), datos[i]);
//    }
////   }
//// </editor-fold>
//}

// <editor-fold defaultstate="collapsed" desc="Posible borrar">
//extern unsigned uint8_t obtener_mac_propia(char *data) {
///*
//Esta funcion asegura el lograr entrar al modo comandos AT realizando hasta 3 intentos simultaneos.
//Vacia en el puntero pasado como argumento los 8 caracteres correspondientes a la mac del XBEE.
//Regresara un 0 si no se pudo entrar al modo AT despues de 3 intentos.
//Regresa un 1 si se logro entrar al modo AT pero el XBEE jamas respondio con su mac.
//Regresa un 2 si el XBEE respondio con su mac pero no pudo forzarce a salir del modo AT.
//Regresa un 3 si todos los comandos sucediron con exito.
//*/
//   unsigned uint8_t intentos = 0, delays = 0, validacion = 0;
//   
//   delay_ms(60);     
//   for(uint8_t n = 0; n < 100; n++) buffer[n] = NULL;
//   for (intentos = 0; intentos <= 2; intentos++) {                                              //Realizo 3 intentos para entrar a comandos AT
//      ptrBuffer = 0;
//      fprintf(Xbee,"+++");                                                                      //Manda comando AT
//      for (delays = 0; delays <= 100; delays++) {                                               //Espera recibir respuesta durante 1 segundo maximo
//         delay_ms(10);                                                                          //Base de tiempo minima
//         if ((buffer[0] == 'O') && (buffer[1] == 'K') && (buffer[2] == 0X0D)) {                 //Identifica respuesta al comando AT para validar y enviar el siguiente                                                                      
//            intentos = 2;                                                                       //Salgo de intentos
//            validacion = 1;                                                                     //Valido primer comando
//            break;                                                                              //Salgo de espera de 1 segundo
//         }
//      }
//      for(uint8_t n = 0; n < 100; n++) buffer[n] = NULL;                                           //Borro buffer
//   }
//   if ((delays >= 100) && (validacion != 1)) return validacion;
//   ptrBuffer = 0;
//   fprintf(Xbee,"ATSL\r");                                                                    //Envia comando para obtener MAC
//   for (delays = 0; delays <= 100; delays++) {
//      delay_ms(10); 
//      if ((ptrBuffer == 9) && (buffer[8] == 0X0D)) {
//         data[0] = buffer[0],data[1] = buffer[1],data[2] = buffer[2],data[3] = buffer[3],data[4] = buffer[4],data[5] = buffer[5],data[6] = buffer[6],data[7] = buffer[7];
//         validacion = 2;                                                                        //Valido segundo comando
//         break;                                                                                 //Salgo de espera de 1 segundo
//      }
//   }
//   for(uint8_t n = 0; n < 100; n++) buffer[n] = NULL;
//   if ((delays >= 100) && (validacion != 2)) return validacion;
//   ptrBuffer = 0;
//   fprintf(Xbee,"ATCN\r");
//   for (delays = 0; delays <= 100; delays++) {
//      delay_ms(10); 
//      if ((buffer[0] == 'O') && (buffer[1] == 'K') && (buffer[2] == 0X0D)) {
//         validacion = 3;                                                                        //Valido tercer comando
//         break;                                                                                 //Salgo de espera de 1 segundo
//      }
//   }
//   for(uint8_t n = 0; n < 100; n++) buffer[n] = NULL;
//   ptrBuffer = 0;
//   if ((delays >= 100) && (validacion != 3)) return validacion;
//   delay_ms(60);
//   return validacion;                                                                       //Todos los comandos se efectuaron correctamente
//}
// </editor-fold>

//void obtener_mac(void) {
//// <editor-fold defaultstate="collapsed" desc="Obtiene la MAC">
//   DAL[0][0] = DATAEE_ReadByte(8);
//   DAL[0][1] = DATAEE_ReadByte(9);
//   DAL[0][2] = DATAEE_ReadByte(10);
//   DAL[0][3] = DATAEE_ReadByte(11);
//   DAL[0][4] = DATAEE_ReadByte(12);
//   DAL[0][5] = DATAEE_ReadByte(13);
//   DAL[0][6] = DATAEE_ReadByte(14);
//   DAL[0][7] = DATAEE_ReadByte(15);
//   DAL[1][0] = DATAEE_ReadByte(16);
//   DAL[1][1] = DATAEE_ReadByte(17);
//   DAL[1][2] = DATAEE_ReadByte(18);
//   DAL[1][3] = DATAEE_ReadByte(19);
//   DAL[1][4] = DATAEE_ReadByte(20);
//   DAL[1][5] = DATAEE_ReadByte(21);
//   DAL[1][6] = DATAEE_ReadByte(22);
//   DAL[1][7] = DATAEE_ReadByte(23); 
//// </editor-fold>
//}

void guardar_config_sensores(uint16_t comandos, uint16_t id_estanque, char *datos) {
// <editor-fold defaultstate="collapsed" desc="Guardar configuracion de sensores">
   char data[6] = {0};
   uint16_t Id1 = obtener_id_estanque(1); 
   uint16_t Id2 = obtener_id_estanque(2);
   uint16_t configuracion = 0;
   
   if((comandos == CONFIG_SENSORES) && (id_estanque == Id1)){
      data[0] = '0';
      data[1] = 'X';
      data[2] = datos[0];
      data[3] = datos[1];
      data[4] = datos[2];
      data[5] = 0;
      configuracion = atol(data);
      saveEEPROM_configuration_estanque1(configuracion);
   } 
   else if((comandos == CONFIG_SENSORES) && (id_estanque == Id2)){
      data[0] = '0';
      data[1] = 'X';
      data[2] = datos[0];
      data[3] = datos[1];
      data[4] = datos[2];
      data[5] = 0;
      configuracion = atol(data);
      saveEEPROM_configuration_estanque1(configuracion);
   }
// </editor-fold>
}

uint16_t obtener_config_sensores(uint16_t id_estanque){
// <editor-fold defaultstate="collapsed" desc="Obtiene la configuracion de los sensores de la EEPROM">
   uint16_t id2 = obtener_id_estanque(2);
   
   if (id_estanque == obtener_id_estanque(1)) {
      return readEEPROM_configuracion_estanque1();
   } 
   else if ((id_estanque ==  id2) && (id2 != 0x0000)){
      return readEEPROM_configuracion_estanque2();
   }
   
   return 0xFFFF;
// </editor-fold>
}

//void guardar_lecturas(uint16_t id_estanque, float ion_potasio, float amoniaco, float ion_amonio, float orp, float ph, float conductividad, float salinidad, float saturacion, float oxigeno, float temperatura) {
//// <editor-fold defaultstate="collapsed" desc="Guardar Lecturas">
//   uint16_t sensores =  obtener_config_sensores(id_estanque);
//   uint16_t posicion = 0;
//   uint16_t estanque_1 = obtener_id_estanque(1);;
//   uint16_t estanque_2 = obtener_id_estanque(2);
//   uint32_t dato = 0;
//   
//   if(id_estanque == estanque_1){
//      posicion = 0;
//   } 
//   else if(id_estanque == estanque_2){
//       posicion = 40;
//   }
//   if ((sensores & SEN_T_ACTIVO) != 0) {                                                                                                                  
//      dato = float_a_IEEE754(temperatura);
//      DATAEE_WriteByte((40 + posicion), (uint8_t)(dato >> 24));
//      DATAEE_WriteByte((41 + posicion), (uint8_t)(dato >> 16));
//      DATAEE_WriteByte((42 + posicion), (uint8_t)(dato >> 8));
//      DATAEE_WriteByte((43 + posicion), (uint8_t)(dato));
//   }                      
//   if ((sensores & SEN_O_ACTIVO) != 0) {
//      dato = float_a_IEEE754(oxigeno);
//      DATAEE_WriteByte((44 + posicion), (uint8_t)(dato >> 24));
//      DATAEE_WriteByte((45 + posicion), (uint8_t)(dato >> 16));
//      DATAEE_WriteByte((46 + posicion), (uint8_t)(dato >> 8));
//      DATAEE_WriteByte((47 + posicion), (uint8_t)(dato));
//   }
//   if ((sensores & SEN_SATO_ACTIVO) != 0) {
//      dato = float_a_IEEE754(saturacion);
//      DATAEE_WriteByte((48 + posicion), (uint8_t)(dato >> 24));
//      DATAEE_WriteByte((49 + posicion), (uint8_t)(dato >> 16));
//      DATAEE_WriteByte((50 + posicion), (uint8_t)(dato >> 8));
//      DATAEE_WriteByte((51 + posicion), (uint8_t)(dato));
//   }                                                          
//   if ((sensores & SEN_S_ACTIVO) != 0) {
//      dato = float_a_IEEE754(salinidad);
//      DATAEE_WriteByte((52 + posicion), (uint8_t)(dato >> 24));
//      DATAEE_WriteByte((53 + posicion), (uint8_t)(dato >> 16));
//      DATAEE_WriteByte((54 + posicion), (uint8_t)(dato >> 8));
//      DATAEE_WriteByte((55 + posicion), (uint8_t)(dato));
//   }
//   if ((sensores & SEN_C_ACTIVO) != 0) {
//      dato = float_a_IEEE754(conductividad);
//      DATAEE_WriteByte((56 + posicion), (uint8_t)(dato >> 24));
//      DATAEE_WriteByte((57 + posicion), (uint8_t)(dato >> 16));
//      DATAEE_WriteByte((58 + posicion), (uint8_t)(dato >> 8));
//      DATAEE_WriteByte((59 + posicion), (uint8_t)(dato));
//   }
//   if ((sensores & SEN_PH_ACTIVO) != 0) {
//      dato = float_a_IEEE754(ph);
//      DATAEE_WriteByte((60 + posicion), (uint8_t)(dato >> 24));
//      DATAEE_WriteByte((61 + posicion), (uint8_t)(dato >> 16));
//      DATAEE_WriteByte((62 + posicion), (uint8_t)(dato >> 8));
//      DATAEE_WriteByte((63 + posicion), (uint8_t)(dato));
//   }            
//   if ((sensores & SEN_ORP_ACTIVO) != 0) {
//      dato = float_a_IEEE754(orp);
//      DATAEE_WriteByte((64 + posicion), (uint8_t)(dato >> 24));
//      DATAEE_WriteByte((65 + posicion), (uint8_t)(dato >> 16));
//      DATAEE_WriteByte((66 + posicion), (uint8_t)(dato >> 8));
//      DATAEE_WriteByte((67 + posicion), (uint8_t)(dato));
//   }
//   if ((sensores & SEN_NH4_ACTIVO) != 0) {
//      dato = float_a_IEEE754(ion_amonio);
//      DATAEE_WriteByte((68 + posicion), (uint8_t)(dato >> 24));
//      DATAEE_WriteByte((69 + posicion), (uint8_t)(dato >> 16));
//      DATAEE_WriteByte((70 + posicion), (uint8_t)(dato >> 8));
//      DATAEE_WriteByte((71 + posicion), (uint8_t)(dato));
//   }
//   if ((sensores & SEN_NH3N_ACTIVO) != 0) {
//      dato = float_a_IEEE754(amoniaco);
//      DATAEE_WriteByte((72 + posicion), (uint8_t)(dato >> 24));
//      DATAEE_WriteByte((73 + posicion), (uint8_t)(dato >> 16));
//      DATAEE_WriteByte((74 + posicion), (uint8_t)(dato >> 8));
//      DATAEE_WriteByte((75 + posicion), (uint8_t)(dato));
//   }
//   if ((sensores & SEN_K_ACTIVO) != 0) {
//      dato = float_a_IEEE754(ion_potasio);
//      DATAEE_WriteByte((76 + posicion), (uint8_t)(dato >> 24));
//      DATAEE_WriteByte((77 + posicion), (uint8_t)(dato >> 16));
//      DATAEE_WriteByte((78 + posicion), (uint8_t)(dato >> 8));
//      DATAEE_WriteByte((79 + posicion), (uint8_t)(dato));
//   }
//// </editor-fold>
//}


////////Cambiar Localidad EEPROM    //Descomentar 3 veces luego
//////void obtener_lecturas(uint16_t id_estanque){  //Solo revisa las localidades donde guardaban las mediciones ocn sensores
//////// <editor-fold defaultstate="collapsed" desc="Obtener Lecturas">
//////    uint16_t sensores = obtener_config_sensores(id_estanque); 
//////    uint16_t estanque_1 = obtener_id_estanque(1); 
//////    #ifndef ALIMENTADOR_CON_SONDA
//////    uint16_t estanque_2 = obtener_id_estanque(2);
//////    #endif
//////    uint16_t posicion = 0;
//////    uint8_t dato[4] = {0};
//////   
//////    if(id_estanque == estanque_1){
//////        posicion = 0;
//////    }
//////    #ifndef ALIMENTADOR_CON_SONDA
//////    else if(id_estanque == estanque_2){
//////        posicion = 40;
//////    }
//////    #endif
//////    if ((sensores & SEN_T_ACTIVO) != 0){                                                                                                                  
///////*        dato[0] = DATAEE_ReadByte(40 + posicion); No se ocupa guardar parametro Temperatura
//////        dato[1] = DATAEE_ReadByte(41 + posicion);
//////        dato[2] = DATAEE_ReadByte(42 + posicion);
//////        dato[3] = DATAEE_ReadByte(43 + posicion);
//////        if (id_estanque == estanque_1){
//////            ESTANQUE1.temperatura = IEEE754_A_Float(dato);
//////        }*/
//////        #ifndef ALIMENTADOR_CON_SONDA
//////        else if (id_estanque == estanque_2){
//////            temperatura2 = IEEE754_A_Float(dato);
//////        }
//////        #endif
//////    }                      
//////    if ((sensores & SEN_O_ACTIVO) != 0){
//////        dato[0] = DATAEE_ReadByte(44 + posicion);
//////        dato[1] = DATAEE_ReadByte(45 + posicion);
//////        dato[2] = DATAEE_ReadByte(46 + posicion);
//////        dato[3] = DATAEE_ReadByte(47 + posicion);
//////        if (id_estanque == estanque_1) {
//////            ESTANQUE1.o2 = IEEE754_A_Float(dato);
//////        } 
//////        #ifndef ALIMENTADOR_CON_SONDA
//////        else if (id_estanque == estanque_2){
//////          O2_mgl_2 = IEEE754_A_Float(dato);
//////        }
//////        #endif
//////    }
//////    if((sensores & SEN_SATO_ACTIVO) != 0){
//////        dato[0] = DATAEE_ReadByte(48 + posicion);
//////        dato[1] = DATAEE_ReadByte(49 + posicion);
//////        dato[2] = DATAEE_ReadByte(50 + posicion);
//////        dato[3] = DATAEE_ReadByte(51 + posicion);
//////        if (id_estanque == estanque_1) {
//////            ESTANQUE1.saturacion = IEEE754_A_Float(dato);
//////        }
//////        #ifndef ALIMENTADOR_CON_SONDA
//////        else if (id_estanque == estanque_2){
//////            saturacion2 = IEEE754_A_Float(dato);
//////        }
//////        #endif
//////    }                                                          
//////    if ((sensores & SEN_S_ACTIVO) != 0) {
//////        dato[0] = DATAEE_ReadByte(52 + posicion);
//////        dato[1] = DATAEE_ReadByte(53 + posicion);
//////        dato[2] = DATAEE_ReadByte(54 + posicion);
//////        dato[3] = DATAEE_ReadByte(55 + posicion);
//////        if (id_estanque == estanque_1) {
//////            ESTANQUE1.salinidad = IEEE754_A_Float(dato);
//////        }
//////        #ifndef ALIMENTADOR_CON_SONDA
//////        else if (id_estanque == estanque_2){
//////            sal2 = IEEE754_A_Float(dato);
//////        }
//////        #endif
//////    }
//////    if ((sensores & SEN_C_ACTIVO) != 0) {
//////        dato[0] = DATAEE_ReadByte(56 + posicion);
//////        dato[1] = DATAEE_ReadByte(57 + posicion);
//////        dato[2] = DATAEE_ReadByte(58 + posicion);
//////        dato[3] = DATAEE_ReadByte(59 + posicion);
//////        if (id_estanque == estanque_1) {
//////            ESTANQUE1.conductividad = IEEE754_A_Float(dato);
//////        }
//////        #ifndef ALIMENTADOR_CON_SONDA
//////        else if (id_estanque == estanque_2){
//////            conductividad2 = IEEE754_A_Float(dato);
//////        }
//////        #endif
//////    }
//////    if ((sensores & SEN_PH_ACTIVO) != 0) {
//////        dato[0] = DATAEE_ReadByte(60 + posicion);
//////        dato[1] = DATAEE_ReadByte(61 + posicion);
//////        dato[2] = DATAEE_ReadByte(62 + posicion);
//////        dato[3] = DATAEE_ReadByte(63 + posicion);
//////        if (id_estanque == estanque_1) {
//////            ESTANQUE1.ph = IEEE754_A_Float(dato);
//////        } 
//////        #ifndef ALIMENTADOR_CON_SONDA
//////        else if (id_estanque == estanque_2){
//////            ph2 = IEEE754_A_Float(dato);
//////        }
//////        #endif
//////    }            
//////    if ((sensores & SEN_ORP_ACTIVO) != 0) {
//////        dato[0] = DATAEE_ReadByte(64 + posicion);
//////        dato[1] = DATAEE_ReadByte(65 + posicion);
//////        dato[2] = DATAEE_ReadByte(66 + posicion);
//////        dato[3] = DATAEE_ReadByte(67 + posicion);
//////        if (id_estanque == estanque_1) {
//////            ESTANQUE1.orp = IEEE754_A_Float(dato);
//////        }
//////        #ifndef ALIMENTADOR_CON_SONDA
//////        else if (id_estanque == estanque_2){
//////            orp2 = IEEE754_A_Float(dato);
//////        }
//////        #endif
//////    }
//////    if ((sensores & SEN_NH4_ACTIVO) != 0) {
//////        dato[0] = DATAEE_ReadByte(68 + posicion);
//////        dato[1] = DATAEE_ReadByte(69 + posicion);
//////        dato[2] = DATAEE_ReadByte(70 + posicion);
//////        dato[3] = DATAEE_ReadByte(71 + posicion);
//////        if (id_estanque == estanque_1) {
//////            ESTANQUE1.ion_amonio = IEEE754_A_Float(dato);
//////        }
//////        #ifndef ALIMENTADOR_CON_SONDA
//////        else if (id_estanque == estanque_2){
//////            ion_amonio2 = IEEE754_A_Float(dato);
//////        }
//////        #endif
//////    }
//////    if ((sensores & SEN_NH3N_ACTIVO) != 0) {
//////        dato[0] = DATAEE_ReadByte(72 + posicion);
//////        dato[1] = DATAEE_ReadByte(73 + posicion);
//////        dato[2] = DATAEE_ReadByte(74 + posicion);
//////        dato[3] = DATAEE_ReadByte(75 + posicion);
//////        if(id_estanque == estanque_1) {
//////            ESTANQUE1.amonio = IEEE754_A_Float(dato);
//////        }
//////        #ifndef ALIMENTADOR_CON_SONDA
//////        else if(id_estanque == estanque_2){
//////            amonio2 = IEEE754_A_Float(dato);
//////        }
//////        #endif
//////    }
//////    if ((sensores & SEN_K_ACTIVO) != 0) {
//////        dato[0] = DATAEE_ReadByte(76 + posicion);
//////        dato[1] = DATAEE_ReadByte(77 + posicion);
//////        dato[2] = DATAEE_ReadByte(78 + posicion);
//////        dato[3] = DATAEE_ReadByte(79 + posicion);
//////        if (id_estanque == estanque_1) {
//////            ESTANQUE1.potasio = IEEE754_A_Float(dato);
//////        }
//////        #ifndef ALIMENTADOR_CON_SONDA
//////        else if (id_estanque == estanque_2){
//////            potasio2 = IEEE754_A_Float(dato);
//////        }
//////        #endif
//////    }
//////// </editor-fold>
//////}

void getLecturasSeteadasEEPROM(uint16_t id_estanque){
// <editor-fold defaultstate="collapsed" desc="Obtener Lecturas">
    uint16_t estanque_1 = obtener_id_estanque(1);
    uint16_t posicion = 0;
    uint8_t dato[5] = {0};
   
    if(id_estanque == estanque_1){
        posicion = 0;
    }    
//    dato[0] = DATAEE_ReadByte(44 + posicion);
//    dato[1] = DATAEE_ReadByte(45 + posicion);
//    dato[2] = DATAEE_ReadByte(46 + posicion);
//    dato[3] = DATAEE_ReadByte(47 + posicion);
//    ESTANQUE1.o2 = IEEE754_A_Float(dato);
    
    dato[0] = DATAEE_ReadByte(L_VALOR_LECTURA_SALINIDAD);
    dato[1] = DATAEE_ReadByte(L_VALOR_LECTURA_SALINIDAD + 1);
    dato[2] = DATAEE_ReadByte(L_VALOR_LECTURA_SALINIDAD + 2);
    dato[3] = DATAEE_ReadByte(L_VALOR_LECTURA_SALINIDAD + 3);
    ESTANQUE1.salinidad = IEEE754_A_Float(dato);
    
    dato[0] = DATAEE_ReadByte(56 + posicion);
    dato[1] = DATAEE_ReadByte(57 + posicion);
    dato[2] = DATAEE_ReadByte(58 + posicion);
    dato[3] = DATAEE_ReadByte(59 + posicion);
//    dato[0] = DATAEE_ReadByte(L_VALOR_LECTURA_CONDUCTIVIDAD);
//    dato[1] = DATAEE_ReadByte(L_VALOR_LECTURA_CONDUCTIVIDAD + 1);
//    dato[2] = DATAEE_ReadByte(L_VALOR_LECTURA_CONDUCTIVIDAD + 2);
//    dato[3] = DATAEE_ReadByte(L_VALOR_LECTURA_CONDUCTIVIDAD + 3);
    ESTANQUE1.conductividad = IEEE754_A_Float(dato);
    
//    dato[0] = DATAEE_ReadByte(60 + posicion);
//    dato[1] = DATAEE_ReadByte(61 + posicion);
//    dato[2] = DATAEE_ReadByte(62 + posicion);
//    dato[3] = DATAEE_ReadByte(63 + posicion);
    dato[0] = DATAEE_ReadByte(L_VALOR_LECTURA_PH);
    dato[1] = DATAEE_ReadByte(L_VALOR_LECTURA_PH + 1);
    dato[2] = DATAEE_ReadByte(L_VALOR_LECTURA_PH + 2);
    dato[3] = DATAEE_ReadByte(L_VALOR_LECTURA_PH + 3);
    ESTANQUE1.ph = IEEE754_A_Float(dato);
    
//    dato[0] = DATAEE_ReadByte(64 + posicion);
//    dato[1] = DATAEE_ReadByte(65 + posicion);
//    dato[2] = DATAEE_ReadByte(66 + posicion);
//    dato[3] = DATAEE_ReadByte(67 + posicion);
    dato[0] = DATAEE_ReadByte(L_VALOR_LECTURA_ORP);
    dato[1] = DATAEE_ReadByte(L_VALOR_LECTURA_ORP + 1);
    dato[2] = DATAEE_ReadByte(L_VALOR_LECTURA_ORP + 2);
    dato[3] = DATAEE_ReadByte(L_VALOR_LECTURA_ORP + 3);
    ESTANQUE1.orp = IEEE754_A_Float(dato);
    
//    dato[0] = DATAEE_ReadByte(68 + posicion);
//    dato[1] = DATAEE_ReadByte(69 + posicion);
//    dato[2] = DATAEE_ReadByte(70 + posicion);
//    dato[3] = DATAEE_ReadByte(71 + posicion);
    dato[0] = DATAEE_ReadByte(L_VALOR_LECTURA_ION_DE_AMONIO);
    dato[1] = DATAEE_ReadByte(L_VALOR_LECTURA_ION_DE_AMONIO + 1);
    dato[2] = DATAEE_ReadByte(L_VALOR_LECTURA_ION_DE_AMONIO + 2);
    dato[3] = DATAEE_ReadByte(L_VALOR_LECTURA_ION_DE_AMONIO + 3);
    ESTANQUE1.ion_amonio = IEEE754_A_Float(dato);
    
//    dato[0] = DATAEE_ReadByte(72 + posicion);
//    dato[1] = DATAEE_ReadByte(73 + posicion);
//    dato[2] = DATAEE_ReadByte(74 + posicion);
//    dato[3] = DATAEE_ReadByte(75 + posicion);
    dato[0] = DATAEE_ReadByte(L_VALOR_LECTURA_AMONIACO);
    dato[1] = DATAEE_ReadByte(L_VALOR_LECTURA_AMONIACO + 1);
    dato[2] = DATAEE_ReadByte(L_VALOR_LECTURA_AMONIACO + 2);
    dato[3] = DATAEE_ReadByte(L_VALOR_LECTURA_AMONIACO + 3);
    ESTANQUE1.amonio = IEEE754_A_Float(dato);
    
//    dato[0] = DATAEE_ReadByte(76 + posicion);
//    dato[1] = DATAEE_ReadByte(77 + posicion);
//    dato[2] = DATAEE_ReadByte(78 + posicion);
//    dato[3] = DATAEE_ReadByte(79 + posicion);
    dato[0] = DATAEE_ReadByte(L_VALOR_LECTURA_ION_DE_POTASIO);
    dato[1] = DATAEE_ReadByte(L_VALOR_LECTURA_ION_DE_POTASIO + 1);
    dato[2] = DATAEE_ReadByte(L_VALOR_LECTURA_ION_DE_POTASIO + 2);
    dato[3] = DATAEE_ReadByte(L_VALOR_LECTURA_ION_DE_POTASIO + 3);
    ESTANQUE1.potasio = IEEE754_A_Float(dato);
// </editor-fold>
}

void guardar_parametro(uint16_t comandos, uint16_t id_estanque, char *datos) {
// <editor-fold defaultstate="collapsed" desc="Guardar parametros">
    uint16_t estanque_1 = 0, estanque_2 = 0, config = 0;
    uint8_t  data[6] = {0};
    uint16_t dato = 0;
    uint16_t localidadEEPROM = 0;

        if (comandos == SETEAR_PARAMETRO) {
            data[0] = '0';
            data[1] = 'X';           
            data[2] = datos[0];
            data[3] = datos[1];
            data[4] = datos[2];
            data[5] = 0;
            dato = datos[1];
            dato = dato << 8;
            dato += datos[2];
            config = dato;
//            config = atol(data);                                                                      //obtengo el bit del parametro que se va a setear.
            estanque_1 = obtener_id_estanque(1);
            estanque_2 = obtener_id_estanque(2);                                                      //Obtengo el id guardado de los 2 estanques.
//            dato_byte[0] = datos[3];
//            dato_byte[1] = datos[4];
//            dato_byte[0] = (uint8_t)strtol(dato_byte, 0, 16);
//            dato_byte[0] = datos[5];
//            dato_byte[1] = datos[6];
//            data[1] = (uint8_t)strtol(dato_byte, 0, 16);
//            dato_byte[0] = datos[7];
//            dato_byte[1] = datos[8];
//            data[2] = (uint8_t)strtol(dato_byte, 0, 16);
//            dato_byte[0] = datos[9];
//            dato_byte[1] = datos[10];
//            data[3] = (uint8_t)strtol(dato_byte, 0, 16);
            data[0] = datos[3];
            data[1] = datos[4];
            data[2] = datos[5];
            data[3] = datos[6];
            if (id_estanque == estanque_1) {
                localidadEEPROM = 0;
            }
            #ifndef ALIMENTADOR_CON_SONDA
            else if (id_estanque == estanque_2) {
                localidadEEPROM = 40;
            } 
            #endif
            else return;
            if (config == SEN_T_ACTIVO) {
                localidadEEPROM += L_VALOR_LECTURA_TEMPERATURA;
            } 
            else if (config == SEN_O_ACTIVO) {
                localidadEEPROM += L_VALOR_LECTURA_OXIGENO_DISUELTO;
            }
            else if (config == SEN_SATO_ACTIVO) {
                localidadEEPROM += L_VALOR_LECTURA_SATURACION_OXIGENO;
            }
            else if (config == SEN_S_ACTIVO) {
                localidadEEPROM += L_VALOR_LECTURA_SALINIDAD;
            }
            else if (config == SEN_C_ACTIVO) {
                localidadEEPROM += L_VALOR_LECTURA_CONDUCTIVIDAD;
            }
            else if (config == SEN_PH_ACTIVO) {
                localidadEEPROM += L_VALOR_LECTURA_PH;
            }
            else if (config == SEN_ORP_ACTIVO) {
                localidadEEPROM += L_VALOR_LECTURA_ORP;
            }
            else if (config == SEN_NH4_ACTIVO) {
                localidadEEPROM += L_VALOR_LECTURA_ION_DE_AMONIO;
            }
            else if (config == SEN_NH3N_ACTIVO) {
                localidadEEPROM += L_VALOR_LECTURA_AMONIACO;
            }
            else if (config == SEN_K_ACTIVO) {
                localidadEEPROM += L_VALOR_LECTURA_ION_DE_POTASIO;
            }
            else{
                return;
            }
            
            for(uint8_t i = 0; i < 4; i++){
                DATAEE_WriteByte((localidadEEPROM + i), data[i]);
            }
    }
// </editor-fold>
}

float obtener_parametro(uint16_t id_estanque, uint16_t parametro){
// <editor-fold defaultstate="collapsed" desc="Obtener parametro">
    uint16_t localidadEEPROM = 0;
    uint8_t dato[4] = {0};

    if(id_estanque == obtener_id_estanque(2)){
        localidadEEPROM = 40;
    }
    
    if(parametro == SEN_T_ACTIVO){
        localidadEEPROM += L_VALOR_LECTURA_TEMPERATURA;
    }
    else if(parametro == SEN_O_ACTIVO){
        localidadEEPROM += L_VALOR_LECTURA_OXIGENO_DISUELTO;
    }
    else if(parametro == SEN_SATO_ACTIVO){
        localidadEEPROM += L_VALOR_LECTURA_SATURACION_OXIGENO;
    }
    else if(parametro == SEN_S_ACTIVO){
        localidadEEPROM += L_VALOR_LECTURA_SALINIDAD;
    }
    else if(parametro == SEN_C_ACTIVO){
        localidadEEPROM += L_VALOR_LECTURA_CONDUCTIVIDAD;
    }
    else if(parametro == SEN_PH_ACTIVO){
        localidadEEPROM += L_VALOR_LECTURA_PH;
    }
    else if(parametro == SEN_ORP_ACTIVO){
        localidadEEPROM += L_VALOR_LECTURA_ORP;
    }
    else if(parametro == SEN_NH4_ACTIVO){
        localidadEEPROM += L_VALOR_LECTURA_ION_DE_AMONIO;
    }
    else if(parametro == SEN_NH3N_ACTIVO){
        localidadEEPROM += L_VALOR_LECTURA_AMONIACO;
    }
    else if(parametro == SEN_K_ACTIVO){
        localidadEEPROM += L_VALOR_LECTURA_ION_DE_POTASIO;
    }
    
    for(uint8_t i = 0; i < 4; i++){
        dato[i] = DATAEE_ReadByte(localidadEEPROM + i);
    }
        
    return IEEE754_A_Float(dato);
// </editor-fold>
}

//Cambiar localidad EEPROM
void guardar_referencias(uint16_t comandos, uint16_t id_estanque, float referencia, float setpoint){
// <editor-fold defaultstate="collapsed" desc="Guardar referencias">
    uint16_t inicio = 0, posicion = 0, habilitacion = 0, obtenido = 0;
    uint32_t dato1 = 0, dato2 = 0;
   
    if (id_estanque == obtener_id_estanque(1)){
        posicion = 0;
    }
    #ifndef ALIMENTADOR_CON_SONDA
    else if(id_estanque == obtener_id_estanque(2)){
        posicion = 58;
    }
    #endif
    
    dato1 = float_a_IEEE754(referencia);
    dato2 = float_a_IEEE754(setpoint);
    
    if(comandos == CALIBRAR_TEMP_L){                                                                                                                  
        inicio = 205;
        obtenido = 0x0001;
    } 
    else if(comandos == CALIBRAR_O2_L){
        inicio = 213;
        obtenido = 0x0004;
    }
    else if(comandos == CALIBRAR_SAL_L){
        inicio = 221;
        obtenido = 0x0008;
    }
    else if(comandos == CALIBRAR_CON_L){
        inicio = 229;
        obtenido = 0x0010;
    }
    else if(comandos == CALIBRAR_PH_L){
        inicio = 237;
        obtenido = 0x0020;
    }
    else if(comandos == CALIBRAR_ORP_L){
        inicio = 245;
        obtenido = 0x0040;
    }
    else if(comandos == CALIBRAR_AMONIO_L){
        inicio = 253;
        obtenido = 0x0080;
    }
    
    DATAEE_WriteByte((inicio + 0 + posicion), (uint8_t)(dato1 >> 24));                       
    DATAEE_WriteByte((inicio + 1 + posicion), (uint8_t)(dato1 >> 16));
    DATAEE_WriteByte((inicio + 2 + posicion), (uint8_t)(dato1 >> 8));
    DATAEE_WriteByte((inicio + 3 + posicion), (uint8_t)(dato1));
    DATAEE_WriteByte((inicio + 4 + posicion), (uint8_t)(dato2 >> 24));
    DATAEE_WriteByte((inicio + 5 + posicion), (uint8_t)(dato2 >> 16));
    DATAEE_WriteByte((inicio + 6 + posicion), (uint8_t)(dato2 >> 8));
    DATAEE_WriteByte((inicio + 7 + posicion), (uint8_t)(dato2));                               //260 maximo    
    
    habilitacion = DATAEE_ReadByte(261 + posicion);
    habilitacion = (habilitacion << 8) | DATAEE_ReadByte(262 + posicion);
    habilitacion = obtenido | habilitacion;
    DATAEE_WriteByte((261 + posicion), (uint8_t)(habilitacion >> 8));
    DATAEE_WriteByte((262 + posicion), (uint8_t)(habilitacion));    //Parece que el maximo es 320***
// </editor-fold>
}

uint8_t* obtener_referencias(uint16_t comandos, uint16_t id_estanque){
// <editor-fold defaultstate="collapsed" desc="obtener_referencias">
    uint16_t estanque_1 = obtener_id_estanque(1);
    #ifndef ALIMENTADOR_CON_SONDA
    uint16_t estanque_2 = obtener_id_estanque(2); 
    #endif
    uint16_t inicio = 0, posicion = 0, obtenido = 0, habilitacion = 0, habilitado = 0;
    uint8_t *dato = 0, dato1[11] = {0};
   
    if (id_estanque == estanque_1) {
        posicion = 0;
    }
    #ifndef ALIMENTADOR_CON_SONDA
    else if (id_estanque == estanque_2){
        posicion = 58;
    }
    #endif

    if(comandos == CALIBRAR_TEMP_H){   
        inicio = 205;
        obtenido = 0xFFFE;
    }
    else if(comandos == CALIBRAR_O2_H){
        inicio = 213;
        obtenido = 0xFFFB;
    }
    else if(comandos == CALIBRAR_SAL_H){
        inicio = 221;
        obtenido = 0xFFF7;
    }
    else if(comandos == CALIBRAR_CON_H){
        inicio = 229;
        obtenido = 0xFFEF;
    }
    else if(comandos == CALIBRAR_PH_H){
        inicio = 237;
        obtenido = 0xFFDF;
    }
    else if(comandos == CALIBRAR_ORP_H){
        inicio = 245;
        obtenido = 0xFFBF;
    }
    else if(comandos == CALIBRAR_AMONIO_H){
        inicio = 253;
        obtenido = 0xFF7F;
    }
    else{
        return 0;
    }
    
    dato1[0] = DATAEE_ReadByte(inicio + 0 + posicion);
    dato1[1] = DATAEE_ReadByte(inicio + 1 + posicion);
    dato1[2] = DATAEE_ReadByte(inicio + 2 + posicion);
    dato1[3] = DATAEE_ReadByte(inicio + 3 + posicion);  
    dato1[4] = DATAEE_ReadByte(inicio + 4 + posicion);
    dato1[5] = DATAEE_ReadByte(inicio + 5 + posicion);
    dato1[6] = DATAEE_ReadByte(inicio + 6 + posicion);
    dato1[7] = DATAEE_ReadByte(inicio + 7 + posicion);
    
    habilitado = DATAEE_ReadByte(261 + posicion);
    habilitado = (habilitado << 8) | DATAEE_ReadByte(262 + posicion);
    dato1[8] = (uint8_t)(habilitado >> 8);
    dato1[9] = (uint8_t)(habilitado);
    dato = &dato1;
    habilitacion = obtenido & habilitado;
    DATAEE_WriteByte((261 + posicion), (uint8_t)(habilitacion >> 8));
    DATAEE_WriteByte((262 + posicion), (uint8_t)habilitacion);
    
    return dato;
// </editor-fold>
}

//Cambiar localidad EEPROM
uint16_t obtener_estado_estanques(void) {                                                          //Regresa una variable que indica cual de los 2 esanques esta lleno o si ambos estan llenos
// <editor-fold defaultstate="collapsed" desc="Obetener el estado del estanque">
    uint16_t e_estanque_1 = 0, e_estanque_2 = 0, estado = 0;
   
    estado = DATAEE_ReadByte(200);
    estado = estado << 8;
    estado = estado | DATAEE_ReadByte(201);
    e_estanque_1 = estado;                                                            
    e_estanque_1 = e_estanque_1 >> 12;
    
    estado = DATAEE_ReadByte(202);
    estado = estado << 8;
    estado = estado | DATAEE_ReadByte(203);
    e_estanque_2 = estado;
    e_estanque_2 = e_estanque_2 >> 12;
    
    estado = 0;                                                                               //Si ningun estanque esta lleno estado vale 0
    if (e_estanque_1 == 0x0001) {                                                             //Si el estanque 1 esta lleno sumo a estado 1
       estado = estado + 1;
    }
    if (e_estanque_2 == 0x0001) {                                                             //Si el estanque 2 esta lleno sumo a estado 2
       estado = estado + 2;
    }
    return estado;                                                                            //Si ambos estanques estan llenos estado vale 3;
// </editor-fold>
}

//Cambiar localidad EEPROM
void setear_estado_estanques(uint16_t comandos, uint16_t id_estanque) {                               //Recibe como argumento un comando junto con el id de estanque al que se la aplicara la modificacion
// <editor-fold defaultstate="collapsed" desc="Setear estado de estanques">
    uint16_t estanque_1 = obtener_id_estanque(1);
    #ifndef ALIMENTADOR_CON_SONDA
    uint16_t estanque_2 = obtener_id_estanque(2);
    #endif
    uint16_t estado = 0, posicion = 0;
   
    if (comandos == LLENAR_ESTANQUE) {                                                        //Identifico cual es el nuevo estado del estanque a modificar
        estado = 0x1000;                                                                    //0X1000 para un estanque lleno
    }
    else if(comandos == VACIAR_ESTANQUE){
        estado = 0x0000;                                                                    //0X0000 para un estanque vacio
    }
    if (id_estanque == estanque_1) {                                                          //Identifico el id del estanque que se va a modificar 
        posicion = 0;
        estado = estado | estanque_1;
    }
    #ifndef ALIMENTADOR_CON_SONDA
    else if (id_estanque == estanque_2) {
        posicion = 2;
        estado = estado | estanque_2;
    }
    #endif
    else return;
    
    DATAEE_WriteByte((200 + posicion), (uint8_t)(estado >> 8));                                            //Guardo el nuevo estado del estanque
    DATAEE_WriteByte((201 + posicion), (uint8_t)(estado));
// </editor-fold>
}

//Cambiar localidad EEPROM
void calibrar_temperatura(uint16_t comandos, float setpoint_bajo, float setpoint_alto, uint8_t id_sensor, uint16_t config){
// <editor-fold defaultstate="collapsed" desc="calibrar_temperatura">
    uint8_t  intentos = 0, *p_datos = 0, dato1[4] = {0}, dato2[4] = {0};
    uint16_t K_mas_B[9], posicion = 0, ID_ESTANQUE = 0, habilitacion = 0;
    uint32_t K_IEEE754 = 0, B_IEEE754 = 0;
    float referencia = 0.0, referencia_temp_bajo = 0.0, referencia_temp_alto = 0.0, K = 0.0, B = 0.0;
   
    if (id_sensor == 0x01){
        posicion = 0;
        ID_ESTANQUE = obtener_id_estanque(1);
    }
    #ifndef ALIMENTADOR_CON_SONDA
    else if (id_sensor == 0x03){
        posicion = 8;
        ID_ESTANQUE = obtener_id_estanque(2);
    }
    #endif
    __delay_ms(1000); 
    desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, id_sensor);
    if(comandos == CALIBRAR_TEMP_L){
        DATAEE_WriteByte((24 + posicion), 0x3F);    //Las siguientes escrituras en EEPROM ya se realizan cuando la memoria
        DATAEE_WriteByte((25 + posicion), 0x80);    //tiene 0xFF revisar si se puede borrar
        DATAEE_WriteByte((26 + posicion), 0x00);
        DATAEE_WriteByte((27 + posicion), 0x00);
        
        DATAEE_WriteByte((28 + posicion), 0x00);
        DATAEE_WriteByte((29 + posicion), 0x00);
        DATAEE_WriteByte((30 + posicion), 0x00);
        DATAEE_WriteByte((31 + posicion), 0x00);
//        if(config == SEN_T_ACTIVO){           //Posible borrado                                                     //Si el estanque 1 solo tiene sensor de temperatura obtenemos temperatura con pt-1000      
//            for(intentos = 0; intentos < 20; intentos++){                                           //Espero a que se estabilicen las mediciones durante 3 minutos
//                __delay_ms(1000);
////////                referencia = obtener_temperatura_PT_1000();
//                if (intentos >= 10) {
//                    referencia_temp_bajo = referencia_temp_bajo + referencia;
//                }
//            } 
//        }
//        else{      
        for(intentos = 0; intentos < 20; intentos++){                                              //Espero a que se estabilicen las mediciones durante 3 minutos
            referencia = desun_temperatura(id_sensor);
            if(intentos >= 10){
                referencia_temp_bajo = referencia_temp_bajo + referencia;
            }
        } 
//        }
        referencia_temp_bajo = referencia_temp_bajo / 10.0;
//        fprintf(Xbee, "\r\nID estanque: %1X%2X, CAL: Temperatura L, Ref: %5.2f%cC, Setpoint: %5.2f%cC\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE, referencia_temp_bajo, 0XB0, setpoint_bajo, 0XB0);
        guardar_referencias(comandos, ID_ESTANQUE, referencia_temp_bajo, setpoint_bajo);
    }
    else if(comandos == CALIBRAR_TEMP_H){
        p_datos = obtener_referencias(comandos, ID_ESTANQUE);
        dato1[0] = p_datos[0],dato1[1] = p_datos[1],dato1[2] = p_datos[2],dato1[3] = p_datos[3];        
        dato2[0] = p_datos[4],dato2[1] = p_datos[5],dato2[2] = p_datos[6],dato2[3] = p_datos[7];
        habilitacion = p_datos[8];
        habilitacion = (habilitacion << 8) | p_datos[9];
        referencia_temp_bajo = IEEE754_A_Float(dato1);
        setpoint_bajo = IEEE754_A_Float(dato2);
        if ((habilitacion & 0x0001) != 0x0001) {
//            fprintf(Xbee, "\r\nID estanque: %1X%2X, Proceda con la CAL: Temperatura L\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE,);
            __delay_ms(100);  
            return;
        }
//        if(config == SEN_T_ACTIVO){               //Posible Borrado                                                 //Si el estanque 1 solo tiene sensor de temperatura obtenemos temperatura con pt-1000      
//            for(intentos = 0; intentos < 20; intentos++){                                           //Espero a que se estabilicen las mediciones durante 3 minutos
//                __delay_ms(1000);
////////                referencia = obtener_temperatura_PT_1000();
//                if (intentos >= 10) {
//                    referencia_temp_alto = referencia_temp_alto + referencia;
//                }
//            } 
//        }
//        else{      
        for(intentos = 0; intentos < 20; intentos++){                                              //Espero a que se estabilicen las mediciones durante 3 minutos
            referencia = desun_temperatura(id_sensor);
            if (intentos >= 10) {
                referencia_temp_alto = referencia_temp_alto + referencia;
            }
        } 
//        }
        referencia_temp_alto = referencia_temp_alto / 10.0;
//////        fprintf(Xbee, "\r\nID estanque: %1X%2X, CAL: Temperatura H, Ref: %5.2f%cC, Setpoint: %5.2f%cC\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE, referencia_temp_alto, 0XB0, setpoint_alto, 0XB0);    
        K = (setpoint_alto / referencia_temp_alto) + ((setpoint_alto / referencia_temp_alto) - (setpoint_bajo / referencia_temp_bajo));
        K_IEEE754 = float_a_IEEE754(K);
        B = ((setpoint_alto - (referencia_temp_alto * K)) + (setpoint_bajo - (referencia_temp_bajo * K))) / 2.0;
        B_IEEE754 = float_a_IEEE754(B); 
//////        fprintf(Xbee, "ID estanque: %1X%2X, Datos de compensacion obtenidos K = %6.3f B = %6.3f\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE, K, B);
        K_mas_B[0] = (uint8_t)(K_IEEE754 >> 24);                                                                      
        K_mas_B[1] = (uint8_t)(K_IEEE754 >> 16);                                                 
        K_mas_B[2] = (uint8_t)(K_IEEE754 >> 8);                                                         
        K_mas_B[3] = (uint8_t)(K_IEEE754);   
        
        K_mas_B[4] = (uint8_t)(B_IEEE754 >> 24);                                                              
        K_mas_B[5] = (uint8_t)(B_IEEE754 >> 16);                                                                  
        K_mas_B[6] = (uint8_t)(B_IEEE754 >> 8);                                                                        
        K_mas_B[7] = (uint8_t)(B_IEEE754);
        
        DATAEE_WriteByte((24 + posicion), (uint8_t)(K_mas_B[0]));
        DATAEE_WriteByte((25 + posicion), (uint8_t)(K_mas_B[1]));
        DATAEE_WriteByte((26 + posicion), (uint8_t)(K_mas_B[2]));
        DATAEE_WriteByte((27 + posicion), (uint8_t)(K_mas_B[3]));
        
        DATAEE_WriteByte((28 + posicion), (uint8_t)(K_mas_B[4]));
        DATAEE_WriteByte((29 + posicion), (uint8_t)(K_mas_B[5]));
        DATAEE_WriteByte((30 + posicion), (uint8_t)(K_mas_B[6]));
        DATAEE_WriteByte((31 + posicion), (uint8_t)(K_mas_B[7]));   
////////        fprintf(Xbee, "ID estanque: %1X%2X, Calibracion de Temperatura finalizada\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE);
    }  
// </editor-fold>
}

//Cambiar localidad EEPROM
float compensar_temperatura(float temperatura, uint8_t id_sensor){
// <editor-fold defaultstate="collapsed" desc="compensar_temperatura">
    uint8_t  K_IEEE754[5], B_IEEE754[5];
    uint16_t posicion = 0;
    float K = 0.0, B = 0.0;
//    float temperatura_compensada = 0.0;
   
    if(id_sensor == 0x01){
        posicion = 0;
    }
    #ifndef ALIMENTADOR_CON_SONDA
    else{
        posicion = 8;
    }
    #endif
    
    K_IEEE754[0] = DATAEE_ReadByte(24 + posicion);
    K_IEEE754[1] = DATAEE_ReadByte(25 + posicion);
    K_IEEE754[2] = DATAEE_ReadByte(26 + posicion);
    K_IEEE754[3] = DATAEE_ReadByte(27 + posicion);
    
    B_IEEE754[0] = DATAEE_ReadByte(28 + posicion);    
    B_IEEE754[1] = DATAEE_ReadByte(29 + posicion);
    B_IEEE754[2] = DATAEE_ReadByte(30 + posicion);
    B_IEEE754[3] = DATAEE_ReadByte(31 + posicion);
    
    K = IEEE754_A_Float(K_IEEE754);
    B = IEEE754_A_Float(B_IEEE754);
    
//    temperatura_compensada = (temperatura * K) + B; 
    
//    return temperatura_compensada;
    return (temperatura * K) + B; 
// </editor-fold>
}

// <editor-fold defaultstate="collapsed" desc="Posible Borrar">
//float obtener_temperatura_PT_1000(void) {
//   float voltaje = 0, voltaje_diferencial = 0, escalon_adc = 0, resistencia = 0, temperatura = 0;
//   uint16_t i = 0, valor_adc = 0;
//   
//   //escalon_adc = 3.33 / 1023;                                                                   //Escalon para ADC de 10 bits  
//   escalon_adc = 3.33 / 4095;                                                                   //Escalon para ADC de 12 bits
//    for (i = 0; i < 1000; i++) {
//        set_adc_channel(PT_1000);
//        delay_us(10);
//        valor_adc = read_adc(ADC_START_AND_READ);
//        voltaje = voltaje + (valor_adc * escalon_adc);
//        delay_ms(1);
//    } 
//    voltaje = voltaje / 1000.0;    
//    /*voltaje_diferencial = (voltaje * 2) / 27.0502;
//    resistencia = (voltaje_diferencial / 0.00247104) + 1000.0;*/
//    voltaje_diferencial = (voltaje * 2) / 24.34;     
//    resistencia = (voltaje_diferencial / 0.00234807) + 1000.0;    
//    temperatura = ((-1) * 0.00232 * resistencia) + 17.59246;    
//    temperatura = sqrt(temperatura);                                
//    temperatura = -((temperatura - 3.908) / 0.00116); //obtengo temperatura
//    return temperatura;  
//}
// </editor-fold>

float oxigeno(float porcentaje, float temp, float salinidad) {
// <editor-fold defaultstate="collapsed" desc="oxigeno">
    float Ts = 273.15 + temp, resultado1 = 0, resultado2 = 0, O2 = 0, OM = 0;

    resultado1 = (-173.4292) + (249.6339 * (100 / Ts)) + (143.3483 * (log(Ts / 100))) + ((-21.8492) * (Ts / 100));
    resultado2 = salinidad * ((-0.033096) + (0.014259 * (Ts / 100)) + ((-0.0017) * ((Ts / 100)*(Ts / 100))));
    O2 = pow(2.718281, resultado1 + resultado2);
    OM = (porcentaje / 100) * O2 * 1.42903;
    
    return OM;
// </editor-fold>
}

void desun_start_measurements(uint16_t tipo_sensor, uint8_t id_sensor) {
// <editor-fold defaultstate="collapsed" desc="desun_start_measurements">
    uint8_t i = 0, a = 0, numero_bytes = 0, intentos = 0, COMANDO = 0;
    uint16_t CRC_RECIBIDO = 0, CRC_CALCULADO = 0, STARTING_ADDRESS = 0, N_REGISTERS = 0;
   
    for (i = 0; i < 50; i++) buffer1[i] = 0x00;
    if (tipo_sensor == (SEN_T_ACTIVO | SEN_O_ACTIVO | SEN_SATO_ACTIVO)){
        COMANDO = RS485_LEER;
        STARTING_ADDRESS = 0x2500;
        N_REGISTERS = 0x0001;
    } else if (tipo_sensor == (SEN_S_ACTIVO | SEN_C_ACTIVO)) {
        COMANDO = RS485_ESCRIBIR;
        STARTING_ADDRESS = 0x1C00;
        N_REGISTERS = 0x0000;
    } else if (tipo_sensor == (SEN_PH_ACTIVO | SEN_ORP_ACTIVO | SEN_NH4_ACTIVO | SEN_NH3N_ACTIVO | SEN_K_ACTIVO)) {
        COMANDO = RS485_ESCRIBIR;
        STARTING_ADDRESS = 0x3100;
        N_REGISTERS = 0x0000;
    }
    for (intentos = 0;intentos < 3;intentos++) {
    //comunicacion_RS485(UNSIGNED INT8 id, UNSIGNED INT8 funcion, UNSIGNED INT16 start_address, UNSIGNED INT16 n_registers,  UNSIGNED INT16 *data);
        CRC_RECIBIDO = comunicacion_RS485(id_sensor, COMANDO, STARTING_ADDRESS, N_REGISTERS, datos);
        numero_bytes = contador - 2;
        CRC_CALCULADO = crc_modbus(buffer1, numero_bytes);
//!      a = CRC_RECIBIDO >> 8;
//!      fprintf(Xbee, "CRC recibido: %2X%2X, ", a, CRC_RECIBIDO);
//!      a = CRC_CALCULADO >> 8;
//!      fprintf(Xbee, "CRC calculado: %2X%2X \r\n", a, CRC_CALCULADO);
        if (CRC_RECIBIDO == CRC_CALCULADO) break;
    }
// </editor-fold>
}

void desun_cambiar_direccion(uint8_t id_actual, uint8_t id_nueva) {
// <editor-fold defaultstate="collapsed" desc="desun_cambiar_direccion">
    uint8_t i = 0, a = 0, numero_bytes = 0, intentos = 0;
    uint16_t CRC_RECIBIDO = 0, CRC_CALCULADO = 0, datos[4] = {0};
    
    datos[0] = id_nueva;
    datos[0] = (datos[0] << 8) & 0XFF00;
    for (i = 0; i < 50; i++) buffer1[i] = 0x00;    
    for (intentos = 0; intentos < 2; intentos++) {
         //comunicacion_RS485(UNSIGNED INT8 id, UNSIGNED INT8 funcion, UNSIGNED INT16 start_address, UNSIGNED INT16 n_registers,  UNSIGNED INT16 *data);
         CRC_RECIBIDO = comunicacion_RS485(id_actual, RS485_ESCRIBIR, 0x3000, 0x0001, datos);
         numero_bytes = contador - 2;
         CRC_CALCULADO = crc_modbus(buffer1, numero_bytes);
//!         a = CRC_RECIBIDO >> 8;
//!         fprintf(Xbee, "CRC recibido: %2X%2X, ", a, CRC_RECIBIDO);
//!         a = CRC_CALCULADO >> 8;
//!         fprintf(Xbee, "CRC calculado: %2X%2X \r\n", a, CRC_CALCULADO);
         if (CRC_RECIBIDO == CRC_CALCULADO) break;
    }
    //disable_interrupts(int_rda);
// </editor-fold>
}

float desun_temperatura(uint8_t id_sensor) {
// <editor-fold defaultstate="collapsed" desc="desun_temperatura">
    uint8_t i = 0, a = 0, numero_bytes = 0, temp[4] = {0}, intentos = 0;
    uint16_t crc_recibido = 0, crc_calculado = 0;
    static float t = 0.0;
    
    for (i = 0; i < 50; i++) buffer1[i] = 0x00;   
    for (intentos = 0; intentos < 2; intentos++) {
         __delay_ms(1000); //delay requerido
         //comunicacion_RS485(UNSIGNED INT8 id, UNSIGNED INT8 funcion, UNSIGNED INT16 start_address, UNSIGNED INT16 n_registers,  UNSIGNED INT16 *data);
//         crc_recibido = comunicacion_RS485(id_sensor, RS485_LEER, 0x2000, 0x0006, datos); //sensor nuevo
        crc_recibido = comunicacion_RS485(id_sensor, RS485_LEER, 0x2600, 0x0004, datos);       //metodo para obtener temperatura y saturacion de oxigeno, datos[3-6] datos[7-10] respetivamente
         numero_bytes = contador - 2;
         crc_calculado = crc_modbus(buffer1, numero_bytes);
//!         a = crc_recibido >> 8;
//!         fprintf(Xbee, "CRC recibido: %2X%2X, ", a, crc_recibido);
//!         a = crc_calculado >> 8;
//!         fprintf(Xbee, "CRC calculado: %2X%2X \r\n", a, crc_calculado);
         if (crc_recibido == crc_calculado) break;
    }
    temp[0] = buffer1[6];
    temp[1] = buffer1[5];
    temp[2] = buffer1[4];
    temp[3] = buffer1[3];
    t = IEEE754_A_Float(temp);
    //disable_interrupts(int_rda);
    return t;
// </editor-fold>
}

float desun_saturacion(uint8_t id_sensor) {
// <editor-fold defaultstate="collapsed" desc="desun_saturacion">
    uint8_t i = 0, a = 0, numero_bytes = 0, saturacion_o2[4] = {0}, intentos = 0;
    uint16_t CRC_RECIBIDO = 0, CRC_CALCULADO = 0;
    static float Saturacion = 0, O2 = 0.0;
    
    for (i = 0; i < 50; i++) buffer1[i] = 0x00;    
    for (intentos = 0; intentos < 2; intentos++){
         __delay_ms(1000); //delay requerido
         //comunicacion_RS485(UNSIGNED INT8 id, UNSIGNED INT8 funcion, UNSIGNED INT16 start_address, UNSIGNED INT16 n_registers,  UNSIGNED INT16 *data);
        // CRC_RECIBIDO = comunicacion_RS485(id_sensor, RS485_LEER, 0x2000, 0x0006, datos);//sensor nuevo
         CRC_RECIBIDO = comunicacion_RS485(id_sensor, RS485_LEER, 0x2600, 0x0004, datos);       //metodo para obtener temperatura y saturacion de oxigeno, datos[3-6] datos[7-10] respetivamente
         numero_bytes = contador - 2;
         CRC_CALCULADO = crc_modbus(buffer1, numero_bytes);
//!         a = CRC_RECIBIDO >> 8;
//!         fprintf(Xbee, "CRC recibido: %2X%2X, ", a, CRC_RECIBIDO);
//!         a = CRC_CALCULADO >> 8;
//!         fprintf(Xbee, "CRC calculado: %2X%2X \r\n", a, CRC_CALCULADO);
         if (CRC_RECIBIDO == CRC_CALCULADO) break;
    }
    saturacion_o2[0] = buffer1[10];
    saturacion_o2[1] = buffer1[9];
    saturacion_o2[2] = buffer1[8];
    saturacion_o2[3] = buffer1[7];
    Saturacion = IEEE754_A_Float(saturacion_o2);
    O2 = Saturacion * 100.0;
    //disable_interrupts(int_rda);
    return O2;
// </editor-fold>
}

//Esta funcion actualiza las variables de temperatura y saturacion del Estanque1
void desun_TemperaturaSaturacion(uint8_t id_sensor){
// <editor-fold defaultstate="collapsed" desc="desun_temperatura">
    uint8_t i = 0, numero_bytes = 0, intentos = 0;
    uint8_t temperatura[4] = {0};
    uint8_t saturacion[4] = {0};
    uint16_t crc_recibido = 0, crc_calculado = 0;
//    float t = 0.0;
//    float saturacion = 0.0;
    
    for (i = 0; i < 50; i++) buffer1[i] = 0x00;   
    for (intentos = 0; intentos < 2; intentos++) {
         __delay_ms(1000); //delay requerido
         //comunicacion_RS485(UNSIGNED INT8 id, UNSIGNED INT8 funcion, UNSIGNED INT16 start_address, UNSIGNED INT16 n_registers,  UNSIGNED INT16 *data);
         //crc_recibido = comunicacion_RS485(id_sensor, RS485_LEER, 0x2000, 0x0006, datos);//sensor nuevo
         crc_recibido = comunicacion_RS485(id_sensor, RS485_LEER, 0x2600, 0x0004, datos);       //metodo para obtener temperatura y saturacion de oxigeno, datos[3-6] datos[7-10] respetivamente
         numero_bytes = contador - 2;
         crc_calculado = crc_modbus(buffer1, numero_bytes);
//!         a = crc_recibido >> 8;
//!         fprintf(Xbee, "CRC recibido: %2X%2X, ", a, crc_recibido);
//!         a = crc_calculado >> 8;
//!         fprintf(Xbee, "CRC calculado: %2X%2X \r\n", a, crc_calculado);
         if (crc_recibido == crc_calculado) break;
    }
    temperatura[0] = buffer1[6];
    temperatura[1] = buffer1[5];
    temperatura[2] = buffer1[4];
    temperatura[3] = buffer1[3];
    ESTANQUE1.temperatura = IEEE754_A_Float(temperatura);
    
    saturacion[0] = buffer1[10];
    saturacion[1] = buffer1[9];
    saturacion[2] = buffer1[8];
    saturacion[3] = buffer1[7];
    ESTANQUE1.saturacion = IEEE754_A_Float(saturacion) * 100.0;
    //disable_interrupts(int_rda);
// </editor-fold>
}

float desun_salinidad(uint8_t id_sensor, float presion) {
// <editor-fold defaultstate="collapsed" desc="desun_salinidad">
   uint8_t i = 0, a = 0, numero_bytes = 0, data_byte[4] = {0}, intentos = 0;
   uint16_t CRC_RECIBIDO = 0, CRC_CALCULADO = 0;
   static float ppt = 0.0, temperatura = 0.0;
    
   for (i = 0; i < 50; i++) buffer1[i] = 0x00;    
   for (intentos = 0; intentos < 2; intentos++) {
      __delay_ms(3000); //delay requerido
      //comunicacion_RS485(UNSIGNED INT8 id, UNSIGNED INT8 funcion, UNSIGNED INT16 start_address, UNSIGNED INT16 n_registers,  UNSIGNED INT16 *data);
      CRC_RECIBIDO = comunicacion_RS485(id_sensor, RS485_LEER, 0x2600, 0x0005, datos);       //metodo para obtener temperatura y conductividad en mS/cm, datos[3-6] datos[7-10] respetivamente
      numero_bytes = contador - 2;
      CRC_CALCULADO = crc_modbus(buffer1, numero_bytes);
//!      a = CRC_RECIBIDO >> 8;
//!      fprintf(Xbee, "CRC recibido: %2X%2X, ", a, CRC_RECIBIDO);
//!      a = CRC_CALCULADO >> 8;
//!      fprintf(Xbee, "CRC calculado: %2X%2X \r\n", a, CRC_CALCULADO);
      if (CRC_RECIBIDO == CRC_CALCULADO) break;
   }
   data_byte[0] = buffer1[10];
   data_byte[1] = buffer1[9];
   data_byte[2] = buffer1[8];
   data_byte[3] = buffer1[7];
   mili_Siemens = IEEE754_A_Float(data_byte);
   data_byte[0] = buffer1[6];
   data_byte[1] = buffer1[5];
   data_byte[2] = buffer1[4];
   data_byte[3] = buffer1[3];
   temperatura = IEEE754_A_Float(data_byte);
   ppt = gsw_sp_from_c(mili_Siemens, 25.0, presion);                                     //Convertir a salinidad
   return ppt;
// </editor-fold>
}

void desun_calibrar_o2(uint16_t comandos, float setpoint_bajo, float setpoint_alto, uint8_t id_sensor) {
// <editor-fold defaultstate="collapsed" desc="desun_calibrar_o2">
    uint8_t i = 0, a = 0, numero_bytes = 0, intentos = 0, *p_datos = 0, dato1[4] = {0}, dato2[4] = {0};
    uint16_t CRC_RECIBIDO = 0, CRC_CALCULADO = 0, K_mas_B[4] = {0}, ID_ESTANQUE = 0, habilitacion = 0;
    uint32_t K_IEEE754 = 0, B_IEEE754 = 0;
    float referencia = 0.0, referenciaO2_bajo = 0.0, referenciaO2_alto = 0.0, referenciaO2_alto2 = 0.0, K = 0.0, B = 0.0;
    
    if(id_sensor == 0x01){
        ID_ESTANQUE = obtener_id_estanque(1);
    }
    else if(id_sensor == 0x03){
        ID_ESTANQUE = obtener_id_estanque(2);
    }
    for (i = 0; i < 50; i++) buffer1[i] = 0x00;
    __delay_ms(1000); 
    desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, id_sensor);
    if (comandos == CALIBRAR_O2_L) {
        K_mas_B[0] = 0x0000;
        K_mas_B[1] = 0x803F;
        K_mas_B[2] = 0x0000;
        K_mas_B[3] = 0x0000;        
        for (intentos = 0; intentos < 2; intentos++) {
            __delay_ms(1000);                                                                           //delay requerido
            //comunicacion_RS485(UNSIGNED INT8 id, UNSIGNED INT8 funcion, UNSIGNED INT16 start_address, UNSIGNED INT16 n_registers,  UNSIGNED INT16 *data);
            //CRC_RECIBIDO = comunicacion_RS485(id_sensor, RS485_ESCRIBIR, 0x2200, 0x0004, K_mas_B);//sensor nuevo
            CRC_RECIBIDO = comunicacion_RS485(id_sensor, RS485_ESCRIBIR, 0x1100, 0x0004, K_mas_B);    //metodo para setear coeficientes de calibracion
            numero_bytes = contador - 2;
            CRC_CALCULADO = crc_modbus(buffer1, numero_bytes);
            if (CRC_RECIBIDO == CRC_CALCULADO) break;
        }   
        for (intentos = 0; intentos < 20; intentos++) {                                              //Espero a que se estabilicen las mediciones durante 3 minutos
            referencia = desun_saturacion(id_sensor);
            if (intentos >= 10) {
                referenciaO2_bajo = referenciaO2_bajo + referencia;
            }
        }   
        referenciaO2_bajo = referenciaO2_bajo / 10.0;
//        fprintf(Xbee, "\r\nID estanque: %1X%2X, CAL: Saturacion L, Ref: %5.2f%%, Setpoint: %5.2f%%\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE, referenciaO2_bajo, setpoint_bajo);   
        guardar_referencias(comandos, ID_ESTANQUE, referenciaO2_bajo, setpoint_bajo);
    }
    else if(comandos == CALIBRAR_O2_H){
        p_datos = obtener_referencias(comandos, ID_ESTANQUE);
        dato1[0] = p_datos[0],dato1[1] = p_datos[1],dato1[2] = p_datos[2],dato1[3] = p_datos[3];        
        dato2[0] = p_datos[4],dato2[1] = p_datos[5],dato2[2] = p_datos[6],dato2[3] = p_datos[7];
        habilitacion = p_datos[8];
        habilitacion = (habilitacion << 8) | p_datos[9];
        referenciaO2_bajo = IEEE754_A_Float(dato1);
        setpoint_bajo = IEEE754_A_Float(dato2);
        if((habilitacion & 0X0004) != 0X0004){
//            fprintf(Xbee, "\r\nID estanque: %1X%2X, Proceda con la CAL: Saturacion L\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE);
            __delay_ms(100);  
            return;
        }
        for (intentos = 0; intentos < 20; intentos++) {                                              //Espero a que se estabilicen las mediciones durante 3 minutos
            referencia = desun_saturacion(id_sensor);
            if (intentos >= 10) {
                referenciaO2_alto = referenciaO2_alto + referencia;
            }
        }   
        referenciaO2_alto = referenciaO2_alto / 10.0;
//        fprintf(Xbee, "\r\nID estanque: %1X%2X, CAL: Saturacion H, Ref: %5.2f%%, Setpoint: %5.2f%%\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE, referenciaO2_alto, setpoint_alto);        
        if((referenciaO2_bajo <= 0.0) || (setpoint_bajo == 0)){
            B = -(referenciaO2_bajo);
            referenciaO2_alto2 = referenciaO2_alto + B;
            K = setpoint_alto / referenciaO2_alto2;
            B = (B + (((setpoint_alto - ((referenciaO2_alto * K) + B)) + (setpoint_bajo - ((referenciaO2_bajo * K) + B)))/2.0))/100.0;
        }
        else{
            K = (setpoint_alto / referenciaO2_alto) + ((setpoint_alto / referenciaO2_alto) - (setpoint_bajo / referenciaO2_bajo));
            B = ((setpoint_alto - (referenciaO2_alto * K)) + (setpoint_bajo - (referenciaO2_bajo * K))) / 200.0;
        }
        K_IEEE754 = float_a_IEEE754(K);   
        B_IEEE754 = float_a_IEEE754(B);        
////////        fprintf(Xbee, "ID estanque: %1X%2X, Datos de compensacion obtenidos K = %6.3f B = %6.3f\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE, K, B);     
        a = (uint8_t)(K_IEEE754);                                                                               //Rescato en a el byte mas bajo de K
        K_mas_B[0] = a;                                                                              //Muevo el byte mas bajo de K al byte mas alto del primer registro que se enviara
        a = (uint8_t)(K_IEEE754 >> 8);                                                                          //Rescato el segundo byte de K
        K_mas_B[0] = (K_mas_B[0] << 8) + a;                                                          //Muevo el segundo byte de K al byte mas bajo del primer registro que se enviara
        a = (uint8_t)(K_IEEE754 >> 16);                                                                         //Rescato el tercer byte de K
        K_mas_B[1] = a;                                                                              //Muevo el tercer byte de K al byte mas alto del segundo registro que se enviara
        a = (uint8_t)(K_IEEE754 >> 24);                                                                         //Rescato el cuarto byte de K
        
        K_mas_B[1] = (K_mas_B[1] << 8) + a;                                                          //Muevo el cuarto byte de K al byte mas bajo del segundo registro que se enviara
        a = (uint8_t)(B_IEEE754);
        K_mas_B[2] = a;
        a = (uint8_t)(B_IEEE754 >> 8);
        K_mas_B[2] = (K_mas_B[2] << 8) + a;
        a = (uint8_t)(B_IEEE754 >> 16);
        K_mas_B[3] = a;
        a = (uint8_t)(B_IEEE754 >> 24);
        K_mas_B[3] = (K_mas_B[3] << 8) + a;   
        for (intentos = 0; intentos < 2; intentos++) {
            __delay_ms(1000);                                                                           //delay requerido
            //comunicacion_RS485(UNSIGNED INT8 id, UNSIGNED INT8 funcion, UNSIGNED INT16 start_address, UNSIGNED INT16 n_registers,  UNSIGNED INT16 *data);
            //CRC_RECIBIDO = comunicacion_RS485(id_sensor, RS485_ESCRIBIR, 0x2200, 0x0004, K_mas_B);//nuevo
            CRC_RECIBIDO = comunicacion_RS485(id_sensor, RS485_ESCRIBIR, 0x1100, 0x0004, K_mas_B);    //metodo para setear coeficientes de calibracion
            numero_bytes = contador - 2;
            CRC_CALCULADO = crc_modbus(buffer1, numero_bytes);
            if (CRC_RECIBIDO == CRC_CALCULADO) break;
        }
////////        fprintf(Xbee, "ID estanque: %1X%2X, Calibracion de Saturacion de oxigeno finalizada\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE);
    }   
// </editor-fold>
}

void desun_calibrar_salinidad(uint16_t comandos, float setpoint_bajo, float setpoint_alto, float pesion, uint8_t id_sensor) {
// <editor-fold defaultstate="collapsed" desc="desun_calibrar_salinidad">
/* Sera necesario introducir a la ecuaci�n una temperatura fija de 25 grados y a su vez calibrar con salinidad obteniendo 
   la conductividad del agua de referencia con una temperatura de 25�C, el agua tambi�n deber�a estar a una temperatura de 
   25�C para obtener mejores resultados. */
    uint8_t i = 0, a = 0, numero_bytes = 0, intentos = 0, *p_datos = 0, dato1[4] = {0}, dato2[4] = {0};
    uint16_t CRC_RECIBIDO = 0, CRC_CALCULADO = 0, K_mas_B[4] = {0}, ID_ESTANQUE = 0, habilitacion = 0;
    uint32_t K_IEEE754 = 0, B_IEEE754 = 0;
    float t_ref = 0.0, referencia = 0.0, referencia_c_bajo = 0.0, referencia_c_alto = 0.0, referencia_s_bajo = 0.0, referencia_s_alto = 0.0, K = 0.0, B = 0.0;
    
    if (id_sensor == 0x02) {
        ID_ESTANQUE = obtener_id_estanque(1);
    }
    #ifndef ALIMENTADOR_CON_SONDA
    else if (id_sensor == 0x04) {
        ID_ESTANQUE = obtener_id_estanque(2);
    }
    #endif
    if ((comandos == CALIBRAR_SAL_L) || (comandos == CALIBRAR_CON_L)) {
        K_mas_B[0] = 0x0000;
        K_mas_B[1] = 0x803F;
        K_mas_B[2] = 0x0000;
        K_mas_B[3] = 0x0000;
        for (i = 0; i < 50; i++) buffer1[i] = 0x00;    
        for (intentos = 0; intentos < 2; intentos++) {
            __delay_ms(3000);                                                                              //delay requerido
            //comunicacion_RS485(UNSIGNED INT8 id, UNSIGNED INT8 funcion, UNSIGNED INT16 start_address, UNSIGNED INT16 n_registers,  UNSIGNED INT16 *data);
            CRC_RECIBIDO = comunicacion_RS485(id_sensor, RS485_ESCRIBIR, 0x1100, 0x0004, K_mas_B);    //metodo para setear coeficientes de calibracion
            numero_bytes = contador - 2;
            CRC_CALCULADO = crc_modbus(buffer1, numero_bytes);
            if (CRC_RECIBIDO == CRC_CALCULADO) break;
        }   
        mili_Siemens = 0.0;
        for (intentos = 0; intentos < 10; intentos++) {                                              //Espero a que se estabilicen las mediciones durante 3 minutos
            if (mili_Siemens <= 5.0) {                                                                //Si las mediciones de conductividad estan por debajo de 5mS reinicio los sensores
////////                output_high(ENABLE_2);
////////                delay_ms(2000);
////////                output_low(ENABLE_2);
                intentos = 0;
                referencia_s_bajo = 0.0;
                referencia_c_bajo = 0.0;
                t_ref = 0.0;
                desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0X01);
                desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0X02);
                desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0X03);
                desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0X04);
            }
            referencia = desun_salinidad(id_sensor, presion);
            if (intentos >= 5) {
                referencia_s_bajo = referencia_s_bajo + referencia;
                referencia_c_bajo = referencia_c_bajo + mili_Siemens;
                t_ref = t_ref + temperatura;
            }
        }
        referencia_s_bajo = referencia_s_bajo / 5.0;
        referencia_c_bajo = referencia_c_bajo / 5.0;
        t_ref = t_ref / 5.0;
        if(comandos == CALIBRAR_SAL_L){
////////            fprintf(Xbee, "\r\nID estanque: %1X%2X, CAL: Salinidad L, Ref: %5.2fppt, Setpoint: %5.2fppt\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE, referencia_s_bajo, setpoint_bajo); 
            guardar_referencias(comandos, ID_ESTANQUE, referencia_s_bajo, setpoint_bajo);
        }
        else{
////////            fprintf(Xbee, "\r\nID estanque: %1X%2X, CAL: Conductividad L, Ref: %5.2fmS, Setpoint: %5.2fmS\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE, referencia_c_bajo, setpoint_bajo);   
            guardar_referencias(comandos, ID_ESTANQUE, referencia_c_bajo, setpoint_bajo);
        }
    }
    else if ((comandos == CALIBRAR_SAL_H) || (comandos == CALIBRAR_CON_H)) {
        p_datos = obtener_referencias(comandos, ID_ESTANQUE);       
        dato1[0] = p_datos[0],dato1[1] = p_datos[1],dato1[2] = p_datos[2],dato1[3] = p_datos[3];        
        dato2[0] = p_datos[4],dato2[1] = p_datos[5],dato2[2] = p_datos[6],dato2[3] = p_datos[7];
        habilitacion = p_datos[8];
        habilitacion = (habilitacion << 8) | p_datos[9];
        if (comandos == CALIBRAR_SAL_H) {
            referencia_s_bajo = IEEE754_A_Float(dato1);
            setpoint_bajo = IEEE754_A_Float(dato2);
        }
        else if (comandos == CALIBRAR_CON_H) {
            referencia_c_bajo = IEEE754_A_Float(dato1);
            setpoint_bajo = IEEE754_A_Float(dato2);
        }
        if(((habilitacion & 0x0008) != 0x0008) && ((habilitacion & 0x0010) != 0x0010)){
//            if (comandos == CALIBRAR_SAL_H) {
//////////                fprintf(Xbee, "\r\nID estanque: %1X%2X, Proceda con la CAL: Salinidad L\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE);
//            } else if (comandos == CALIBRAR_CON_H) { 
//////////                fprintf(Xbee, "\r\nID estanque: %1X%2X, Proceda con la CAL: Conductividad L\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE);
//            }
            __delay_ms(100);  
            return;
        } 
        mili_Siemens = 0.0;
        for(intentos = 0; intentos < 10; intentos++){                                              //Espero a que se estabilicen las mediciones durante 3 minutos
            if (mili_Siemens <= 5.0) {                                                                //Si las mediciones de conductividad estan por debajo de 5mS reinicio los sensores
//////                output_high(ENABLE_2);
//////                delay_ms(2000);
//////                output_low(ENABLE_2);
                intentos = 0;
                referencia_s_alto = 0.0;
                referencia_c_alto = 0.0;
                t_ref = 0.0;
                desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0X01);
                desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0X02);
                desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0X03);
                desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0X04);
            }
            referencia = desun_salinidad(id_sensor, presion);
            if (intentos >= 5) {
                referencia_s_alto = referencia_s_alto + referencia;
                referencia_c_alto = referencia_c_alto + mili_Siemens;
                t_ref = t_ref + temperatura;
            }
        }
        referencia_s_alto = referencia_s_alto / 5.0;
        referencia_c_alto = referencia_c_alto / 5.0;
        t_ref = t_ref / 5.0;
        if (comandos == CALIBRAR_SAL_H) {
////////            fprintf(Xbee, "\r\nID estanque: %1X%2X, CAL: Salinidad H, Ref: %5.2fppt, Setpoint: %5.2fppt\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE, referencia_s_alto, setpoint_alto);
            setpoint_bajo = gsw_c_from_sp(setpoint_bajo, 25.0, presion);
            setpoint_alto = gsw_c_from_sp(setpoint_alto, 25.0, presion);
            referencia_c_bajo = gsw_c_from_sp(referencia_s_bajo, 25.0, presion);
            referencia_c_alto = gsw_c_from_sp(referencia_s_alto, 25.0, presion);
        } 
//        else {
//////////            fprintf(Xbee, "\r\nID estanque: %1X%2X, CAL: Conductividad H, Ref: %5.2fmS, Setpoint: %5.2fmS\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE, referencia_c_alto, setpoint_alto);   
//        }
        K = (setpoint_alto / referencia_c_alto) + ((setpoint_alto / referencia_c_alto) - (setpoint_bajo / referencia_c_bajo));
        K_IEEE754 = float_a_IEEE754(K);
        B = ((setpoint_alto - (referencia_c_alto * K)) + (setpoint_bajo - (referencia_c_bajo * K))) / 2.0;
        B_IEEE754 = float_a_IEEE754(B);
////////        fprintf(Xbee, "ID estanque: %1X%2X, Datos de compensacion obtenidos K = %6.3f B = %6.3f\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE, K, B);
        a = (uint8_t)(K_IEEE754);                                                                               //Rescato en a el byte mas bajo de K
        K_mas_B[0] = a;                                                                              //Muevo el byte mas bajo de K al byte mas alto del primer registro que se enviara
        a = (uint8_t)(K_IEEE754 >> 8);                                                                          //Rescato el segundo byte de K
        K_mas_B[0] = (K_mas_B[0] << 8) + a;                                                          //Muevo el segundo byte de K al byte mas bajo del primer registro que se enviara
        a = (uint8_t)(K_IEEE754 >> 16);                                                                         //Rescato el tercer byte de K
        K_mas_B[1] = a;                                                                              //Muevo el tercer byte de K al byte mas alto del segundo registro que se enviara
        a = (uint8_t)(K_IEEE754 >> 24);                                                                         //Rescato el cuarto byte de K
        K_mas_B[1] = (K_mas_B[1] << 8) + a;                                                          //Muevo el cuarto byte de K al byte mas bajo del segundo registro que se enviara
        
        a = (uint8_t)(B_IEEE754);
        K_mas_B[2] = a;
        a = (uint8_t)(B_IEEE754 >> 8);
        K_mas_B[2] = (K_mas_B[2] << 8) + a;
        a = (uint8_t)(B_IEEE754 >> 16);
        K_mas_B[3] = a;
        a = (uint8_t)(B_IEEE754 >> 24);
        K_mas_B[3] = (K_mas_B[3] << 8) + a;
        
        for (i = 0; i < 50; i++) buffer1[i] = 0x00;    
        for (intentos = 0; intentos < 2; intentos++) {
            __delay_ms(3000);                                                                           //delay requerido
            //comunicacion_RS485(UNSIGNED INT8 id, UNSIGNED INT8 funcion, UNSIGNED INT16 start_address, UNSIGNED INT16 n_registers,  UNSIGNED INT16 *data);
            CRC_RECIBIDO = comunicacion_RS485(id_sensor, RS485_ESCRIBIR, 0x1100, 0x0004, K_mas_B);    //metodo para setear coeficientes de calibracion
            numero_bytes = contador - 2;
            CRC_CALCULADO = crc_modbus(buffer1, numero_bytes);
            if (CRC_RECIBIDO == CRC_CALCULADO) break;
        }
//        if (comandos == CALIBRAR_SAL_H) {
//////////            fprintf(Xbee, "ID estanque: %1X%2X, Calibracion de Salinidad finalizada\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE);
//        }
//        else {
//////////            fprintf(Xbee, "ID estanque: %1X%2X, Calibracion de Conductividad finalizada\r\n", (ID_ESTANQUE>>8), ID_ESTANQUE);
//        }
    }    
// </editor-fold>
}

void getKBSaturacion(uint8_t id_sensor){
// <editor-fold defaultstate="collapsed" desc="Lee K y B de la saturacion del sensor (Version Nueva)">
    uint8_t numero_bytes = 0;
    uint16_t crc_recibido = 0, crc_calculado = 0;
    
    for (uint8_t i = 0; i < 50; i++){
        buffer1[i] = 0x00;
    }
    for (uint8_t intentos = 0; intentos < 2; intentos++) {
         __delay_ms(1000); //delay requerido
         //comunicacion_RS485(UNSIGNED INT8 id, UNSIGNED INT8 funcion, UNSIGNED INT16 start_address, UNSIGNED INT16 n_registers,  UNSIGNED INT16 *data);
         crc_recibido = comunicacion_RS485(id_sensor, RS485_LEER, 0x2200, 0x0004, datos);
//         crc_recibido = comunicacion_RS485(id_sensor, RS485_LEER, 0x1100, 0x0004, datos);       //metodo para obtener temperatura y saturacion de oxigeno, datos[3-6] datos[7-10] respetivamente
         numero_bytes = contador - 2;
         crc_calculado = crc_modbus(buffer1, numero_bytes);
         if (crc_recibido == crc_calculado) break;
    }
    
    Sonda.b_Saturacion[0] = buffer1[10];
    Sonda.b_Saturacion[1] = buffer1[9];
    Sonda.b_Saturacion[2] = buffer1[8];
    Sonda.b_Saturacion[3] = buffer1[7];
    
    Sonda.k_Saturacion[0] = buffer1[6];
    Sonda.k_Saturacion[1] = buffer1[5];
    Sonda.k_Saturacion[2] = buffer1[4];
    Sonda.k_Saturacion[3] = buffer1[3];
// </editor-fold>
}

void getSoftwareHardwareVersion(uint8_t id_sensor){
// <editor-fold defaultstate="collapsed" desc="Toma la version del Software y Hardware de la sonda (Solo funciona version vieja)">
    uint8_t numero_bytes = 0;
    uint16_t crc_recibido = 0, crc_calculado = 0;
    
    for (uint8_t i = 0; i < 50; i++){
        buffer1[i] = 0x00;
    }
    for (uint16_t intentos = 0; intentos < 2; intentos++) {
        __delay_ms(1000); //delay requerido
        crc_recibido = comunicacion_RS485(id_sensor, RS485_LEER, 0x0700, 0x0002, datos);       //metodo para obtener temperatura y saturacion de oxigeno, datos[3-6] datos[7-10] respetivamente
        numero_bytes = contador - 2;
        crc_calculado = crc_modbus(buffer1, numero_bytes);
        if (crc_recibido == crc_calculado) break;
    }
    Sonda.versionHardwareEntero = buffer1[3];
    Sonda.versionHardwareDecimal = buffer1[4];
    Sonda.versionSoftwareEntero = buffer1[5];
    Sonda.versionSoftwareDecimal = buffer1[6];
// </editor-fold>
}

void configurarSensoresConectados(uint8_t idSensor){
// <editor-fold defaultstate="collapsed" desc="Configura los sensores conectados a la sonda">
    uint16_t configuration = 0;
    
    configuration = convertASCII_hex(18, 18) & 0x0F;
    configuration = configuration << 8;
    configuration |= convertASCII_hex(19, 20);
    
    saveEEPROM_configuration_estanque1(configuration);
    readSensoresConectadosEstanque1();
// </editor-fold>
}

void readSensoresConectadosEstanque1(void){
// <editor-fold defaultstate="collapsed" desc="Activando banderas sensores">
    uint16_t sensoresConectados = obtener_config_sensores(obtener_id_estanque(1));
    
    Sonda.sensorTemperatura = sensoresConectados & SEN_T_ACTIVO;
    Sonda.sensorO2 = sensoresConectados & SEN_O_ACTIVO;
    Sonda.sensorSaturacion = sensoresConectados & SEN_SATO_ACTIVO;
    Sonda.sensorSalinidad = sensoresConectados & SEN_S_ACTIVO;
    Sonda.sensorConductividad = sensoresConectados & SEN_C_ACTIVO;
    Sonda.sensorPh = sensoresConectados & SEN_PH_ACTIVO;
    Sonda.sensorOrp = sensoresConectados & SEN_ORP_ACTIVO;
    Sonda.sensorAmonio = sensoresConectados & SEN_NH4_ACTIVO;
    Sonda.sensorAmoniaco = sensoresConectados & SEN_NH3N_ACTIVO;
    Sonda.sensorPotasio = sensoresConectados & SEN_K_ACTIVO;
// </editor-fold>
}

//uint16_t decodificar_comandos(char *data7) {
//// <editor-fold defaultstate="collapsed" desc="decodificar_comandos">
//   char  dato_byte[3] = {0};
//   uint8_t  data[6] = {0}, a = 0, z = 0;
//   uint16_t comandos = 0;
//   
//////////   if (compararACK()) {
//      data[0] = '0';
//      data[1] = 'X';           
//      data[2] = data7[4];
//      data[3] = data7[5];
//      data[4] = data7[6];
//      data[5] = 0;
//      ID_EN_COMANDO = atol(data);               
//      
//      if ((data7[0] == '?') & (data7[1] == 'i') & (data7[2] == 'm') & (data7[3] == 's')) {         //Checo si recibi alguna peticion de datos.  Aqui no tengo que cambiar la mac del xbee.
//         comandos = ENVIAR_LECTURA;
//////////         enviarACK(RECEPTOR);
//         //fprintf(Xbee, "Comando: ?ims, ID en comando: %lu \r\n", ID_EN_COMANDO);
//      } else if ((data7[0] == '?') & (data7[1] == 'i') & (data7[2] == 'm') & (data7[3] == 'f')) {         //Checo si recibi alguna peticion de datos.  Aqui no tengo que cambiar la mac del xbee.
//         comandos = ENVIAR_LECTURA_F;
//////////         enviarACK(2);
//      } else if ((data7[0] == '>') & (data7[1] == 't') & (data7[2] == 'o') & (data7[3] == 'l')) {
//         comandos = TOMAR_LECTURAS;
//         ID_EN_COMANDO = 0x0000;
//////////         enviarACK(RECEPTOR);
//      } else if ((data7[0] == '>') & (data7[1] == 'v') & (data7[2] == 'a') & (data7[3] == 'c')) {
//         comandos = VACIAR_ESTANQUE;
//////////         enviarACK(RECEPTOR);
//      } else if ((data7[0] == '>') & (data7[1] == 'a') & (data7[2] == 'g') & (data7[3] == 'a')) {
//         comandos = LLENAR_ESTANQUE;
//////////         enviarACK(RECEPTOR);
//      } else if ((data7[0] == '>') & (data7[1] == 'h') & (data7[2] == 'r') & (data7[3] == 'a')) {  //Checo si recibi algun comando de seteo de hora.  Aqui no tengo que cambiar la mac del xbee.
//         comandos = SETEAR_HORA;
//         ID_EN_COMANDO = 0x0000;
//         carga_comando[0] = data7[4], carga_comando[1] = data7[5], carga_comando[2] = data7[6], carga_comando[3] = data7[7], carga_comando[4] = data7[8], 
//         carga_comando[5] = data7[9], carga_comando[6] = data7[10], carga_comando[7] = data7[11], carga_comando[8] = data7[12], carga_comando[9] = data7[13], 
//         carga_comando[10] = data7[14], carga_comando[11] = data7[15], carga_comando[12] = data7[16], carga_comando[13] = data7[17];
//         //enviarACK(RECEPTOR);
//         //fprintf(Xbee, "Comando: >hra, Fecha y hora: Dia %c%c %c%c/%c%c/%c%c %c%c:%c%c:%c%c \r\n",carga_comando[6], carga_comando[7], carga_comando[4], carga_comando[5], carga_comando[2], carga_comando[3], carga_comando[0], carga_comando[1], carga_comando[8], carga_comando[9], carga_comando[10], carga_comando[11], carga_comando[12], carga_comando[13]);
//      } else if ((data7[0] == '>') & (data7[1] == 'd') & (data7[2] == 'o') & (data7[3] == 'b') & (ptrBuffer == 11)) {   //Checo si recibi algun comando de configuracion de ID de estanque unico.   Aqui no tengo que cambiar la mac del xbee.
//         comandos = CAMBIAR_ID_UNICO;
//         ID_EN_COMANDO = 0x0000;
//         carga_comando[0] = data7[4], carga_comando[1] = data7[5], carga_comando[2] = data7[6];
//////////         enviarACK(2);
//         //fprintf(Xbee, "Comando: >dob, ID unico en comando: %Lu \r\n", ID_EN_COMANDO);
//      } else if ((data7[0] == '>') & (data7[1] == 'd') & (data7[2] == 'o') & (data7[3] == 'b') & (ptrBuffer == 14)) {   //Checo si recibi algun comando de configuracion de ID de estanque doble.   Aqui no tengo que cambiar la mac del xbee.
//         comandos = CAMBIAR_ID_DOBLE;
//         ID_EN_COMANDO = 0x0000;
//         carga_comando[0] = data7[4], carga_comando[1] = data7[5], carga_comando[2] = data7[6], 
//         carga_comando[3] = data7[7], carga_comando[4] = data7[8], carga_comando[5] = data7[9];
//////////         enviarACK(2);
//         //fprintf(Xbee, "Comando: >dob, ID doble en comando: %Lu \r\n", ID_EN_COMANDO);
//      } else if ((data7[0] == '>') & (data7[1] == 'b') & (data7[2] == 'y') & (data7[3] == 't')) {  //Checo si recibi algun comando de configuracion de parametros.   Aqui no tengo que cambiar la mac del xbee.
//         comandos = CONFIG_SENSORES;
//         carga_comando[0] = data7[7], carga_comando[1] = data7[8], carga_comando[2] = data7[9];
//////////         enviarACK(2);
//         //fprintf(Xbee, "Comando: >byt, ID en comando: %lu \r\n", ID_EN_COMANDO);
//      } else if ((data7[0] == '>') & (data7[1] == 'l') & (data7[2] == 'e') & (data7[3] == 'c')) {  //Checo si recibi algun comando de tomar y enviar nuevas lecturas.   Aqui no tengo que cambiar la mac del xbee.
//         comandos = T_E_LECTURAS;
//////////         enviarACK(2);
//         //fprintf(Xbee, "Comando: >lec, ID en comando: %lu \r\n", ID_EN_COMANDO);
//      } else if ((data7[0] == '>') & (data7[1] == 's') & (data7[2] == 'e') & (data7[3] == 't')) {  //Checo si recibi algun comando de vincular con su monitor.    Aqui no tengo que cambiar la mac del xbee.
//         comandos = SETEAR_PARAMETRO;
//         carga_comando[0] = data7[7], carga_comando[1] = data7[8], carga_comando[2] = data7[9], carga_comando[3] = data7[10], carga_comando[4] = data7[11], carga_comando[5] = data7[12], 
//         carga_comando[6] = data7[13], carga_comando[7] = data7[14], carga_comando[8] = data7[15], carga_comando[9] = data7[16], carga_comando[10] = data7[17];
//         //fprintf(Xbee, "Comando: >sal, ID en comando: %lu \r\n", ID_EN_COMANDO);
//      } else if ((data7[0] == '>') & (data7[1] == 'm') & (data7[2] == 'o') & (data7[3] == 'n')) {  //Checo si recibi algun comando de vincular con su monitor.    Aqui no tengo que cambiar la mac del xbee.
//         comandos = VIS_CON_M;
//         ID_EN_COMANDO = 0X0000;
//         carga_comando[0] = data7[4], carga_comando[1] = data7[5], carga_comando[2] = data7[6], carga_comando[3] = data7[7], 
//         carga_comando[4] = data7[8], carga_comando[5] = data7[9], carga_comando[6] = data7[10], carga_comando[7] = data7[11];
//////////         enviarACK(2);
//         //fprintf(Xbee, "Comando: >mon, ID en comando: %lu \r\n", ID_EN_COMANDO);
//      } else if ((data7[0] == '>') & (data7[1] == 'c') & (data7[2] == 'f') & (data7[3] == 'g')) {  //Checo si recibi el comando para entrar a modo de configuracion.    Aqui tengo que cambiar la mac del xbee.
//         comandos = CONFIG_SONDA;
//         ID_EN_COMANDO = 0x0000;
//         carga_comando[0] = data7[4], carga_comando[1] = data7[5], carga_comando[2] = data7[6], carga_comando[3] = data7[7], 
//         carga_comando[4] = data7[8], carga_comando[5] = data7[9], carga_comando[6] = data7[10], carga_comando[7] = data7[11];
//////////         enviarACK(2);
//         //fprintf(Xbee, "Comando: >cfg, ID en comando: %lu \r\n", ID_EN_COMANDO);
//      } else if ((data7[0] == '>') & (data7[1] == 'c') & (data7[2] == 'a') & (data7[3] == 'l')) {  //Checo si recibi algun comando de calibracion de sensores.    Aqui tengo que cambiar la mac del xbee.
//         dato_byte[0] = data7[11];
//         dato_byte[1] = data7[12];
//         data[0] = strtol(dato_byte, 0, 16);
//         dato_byte[0] = data7[13];
//         dato_byte[1] = data7[14];
//         data[1] = strtol(dato_byte, 0, 16);
//         dato_byte[0] = data7[15];
//         dato_byte[1] = data7[16];
//         data[2] = strtol(dato_byte, 0, 16);
//         dato_byte[0] = data7[17];
//         dato_byte[1] = data7[18];
//         data[3] = strtol(dato_byte, 0, 16);
//         DATO_SETPOINT = IEEE754_A_Float(data);
//         dato_byte[0] = data7[19];
//         dato_byte[1] = data7[20];
//         data[0] = strtol(dato_byte, 0, 16);
//         dato_byte[0] = data7[21];
//         dato_byte[1] = data7[22];
//         data[1] = strtol(dato_byte, 0, 16);
//         dato_byte[0] = data7[23];
//         dato_byte[1] = data7[24];
//         data[2] = strtol(dato_byte, 0, 16);
//         dato_byte[0] = data7[25];
//         dato_byte[1] = data7[26];
//         data[3] = strtol(dato_byte, 0, 16);
//         DATO_SETPOINT2 = IEEE754_A_Float(data);
//////////         enviarACK(2);         
//         if ((data7[7] == '0')&(data7[8] == '0')&(data7[9] == '1')&(data7[10] == 'L')) {           
//            comandos = CALIBRAR_TEMP_L;
//         } else if ((data7[7] == '0')&(data7[8] == '0')&(data7[9] == '1')&(data7[10] == 'H')) {    
//            comandos = CALIBRAR_TEMP_H;
//         } else if ((data7[7] == '0')&(data7[8] == '0')&(data7[9] == '4')&(data7[10] == 'L')) {    
//            comandos = CALIBRAR_O2_L;
//         } else if ((data7[7] == '0')&(data7[8] == '0')&(data7[9] == '4')&(data7[10] == 'H')) {    
//            comandos = CALIBRAR_O2_H;
//         } else if ((data7[7] == '0')&(data7[8] == '0')&(data7[9] == '8')&(data7[10] == 'L')) {    
//            comandos = CALIBRAR_SAL_L;
//         } else if ((data7[7] == '0')&(data7[8] == '0')&(data7[9] == '8')&(data7[10] == 'H')) {    
//            comandos = CALIBRAR_SAL_H;
//         } else if ((data7[7] == '0')&(data7[8] == '1')&(data7[9] == '0')&(data7[10] == 'L')) {    
//            comandos = CALIBRAR_CON_L;
//         } else if ((data7[7] == '0')&(data7[8] == '1')&(data7[9] == '0')&(data7[10] == 'H')) {    
//            comandos = CALIBRAR_CON_H;
//         } else if ((data7[7] == '0')&(data7[8] == '2')&(data7[9] == '0')&(data7[10] == 'L')) {    
//            comandos = CALIBRAR_PH_L;
//         } else if ((data7[7] == '0')&(data7[8] == '2')&(data7[9] == '0')&(data7[10] == 'H')) {    
//            comandos = CALIBRAR_PH_H;
//         } else if ((data7[7] == '0')&(data7[8] == '4')&(data7[9] == '0')&(data7[10] == 'L')) {    
//            comandos = CALIBRAR_ORP_L;
//         } else if ((data7[7] == '0')&(data7[8] == '4')&(data7[9] == '0')&(data7[10] == 'H')) {    
//            comandos = CALIBRAR_ORP_H;
//         } else if ((data7[7] == '1')&(data7[8] == '0')&(data7[9] == '0')&(data7[10] == 'L')) {    
//            comandos = CALIBRAR_AMONIO_L;
//         } else if ((data7[7] == '1')&(data7[8] == '0')&(data7[9] == '0')&(data7[10] == 'H')) {    
//            comandos = CALIBRAR_AMONIO_H;
//         } else comandos = COMANDO;
//      } else {
//         comandos = COMANDO;
//      }
////////////   } else {
////////////      comandos = COMANDO;
////////////   }
//   for (z = 0; z < 100; z++) {
//      buffer[z] = 0x00;
//   }
//   ptrBuffer = 0;
//   mensajeNuevo = 0; 
//   return comandos;
//// </editor-fold>
//}

//uint8_t Construir_string(char *data6, uint8_t dia_mes, uint8_t mes, uint8_t anio, uint8_t hora, uint8_t minuto, uint16_t id_estanque, float ion_potasio, float amoniaco, float ion_amonio, float orp, float ph, float conductividad, float salinidad, float saturacion, float oxigeno, float temperatura) {
//// <editor-fold defaultstate="collapsed" desc="Construir_string">
//   uint8_t  sumado = 0;
//   uint8_t  i = 0, id_alto = 0, id_bajo = 0, sensores_alto = 0, sensores_bajo = 0, num_caracteres = 0;
//   char  String_float[8] = {0};
//   uint16_t turno_medicion = 0, sensores = 0;
//   uint32_t dato = 0;
//   const uint8_t  arreglodia[13] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; 
//   
//   sensores = obtener_config_sensores(id_estanque);
//   id_alto = id_estanque >> 8;
//   id_bajo = id_estanque;
//   sensores_alto = sensores >> 8;
//   sensores_bajo = sensores;
//   turno_medicion = (((hora * 60.0) + minuto) / 30.0);      
//   if(turno_medicion == 47) {
//      turno_medicion = 0;
//      if(dia_mes == arreglodia[mes-1] && mes != 2 ){
//         dia_mes = 1;
//         if(mes == 12){
//            mes = 1;
//         }else
//            mes++;
//      }else if(dia_mes != arreglodia[mes-1]){
//         dia_mes++;
//         sumado = 1;
//      }       
////      if((((anio + 2000) % 4 == 0) && ((anio + 2000) % 100 != 0) || ((anio + 2000) % 400 == 0)) && (mes == 2)){
////         if( dia_mes == 29 || dia_mes == 30 ){
////            dia_mes = 1;
////            mes++;
////         }
////         else if(sumado == 0)
////            dia_mes++;
////       } else{     
////         if(dia_mes == arreglodia[mes-1] && sumado == 0 ){
////            dia_mes = 1;
////            if( mes == 12 )
////               mes = 1;
////            else
////               mes++;
////         }
////      }
//   } 
//   else{
//      turno_medicion++;
//   }                       
//   
////////   num_caracteres = sprintf(data6, ">ims%c%c%c%1X%2X%1X%2X", Codigo[dia_mes - 1], Codigo[mes - 1], Codigo[turno_medicion], id_alto, id_bajo, sensores_alto, sensores_bajo);
//   num_caracteres = num_caracteres - 1;
//   if ((sensores & SEN_T_ACTIVO) != 0) {                                                                                                                  
//      dato = float_a_IEEE754(temperatura);
////////      sprintf(String_float, "%2X%2X%2X%2X", (dato >> 24), (dato >> 16), (dato >> 8), dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      num_caracteres = num_caracteres + 8;
//   }                      
//   if ((sensores & SEN_O_ACTIVO) != 0) {
//      dato = float_a_IEEE754(oxigeno);
//////////      sprintf(String_float, "%2X%2X%2X%2X", (dato >> 24), (dato >> 16), (dato >> 8), dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      num_caracteres = num_caracteres + 8;
//   }
//   if ((sensores & SEN_SATO_ACTIVO) != 0) {
//      dato = float_a_IEEE754(saturacion);
//////////      sprintf(String_float, "%2X%2X%2X%2X", (dato >> 24), (dato >> 16), (dato >> 8), dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      num_caracteres = num_caracteres + 8;
//   }
//   if ((sensores & SEN_S_ACTIVO) != 0) {
//      dato = float_a_IEEE754(salinidad);
//////////      sprintf(String_float, "%2X%2X%2X%2X", (dato >> 24), (dato >> 16), (dato >> 8), dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      num_caracteres = num_caracteres + 8;
//   }
//   if ((sensores & SEN_C_ACTIVO) != 0) {
//      dato = float_a_IEEE754(conductividad);
//////////      sprintf(String_float, "%2X%2X%2X%2X", (dato >> 24), (dato >> 16), (dato >> 8), dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      num_caracteres = num_caracteres + 8;
//   }
//   if ((sensores & SEN_PH_ACTIVO) != 0) {
//      dato = float_a_IEEE754(ph);
//////////      sprintf(String_float, "%2X%2X%2X%2X", (dato >> 24), (dato >> 16), (dato >> 8), dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      num_caracteres = num_caracteres + 8;
//   }            
//   if ((sensores & SEN_ORP_ACTIVO) != 0) {
//      dato = float_a_IEEE754(orp);
//////////      sprintf(String_float, "%2X%2X%2X%2X", (dato >> 24), (dato >> 16), (dato >> 8), dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      num_caracteres = num_caracteres + 8;
//   }
//   if ((sensores & SEN_NH4_ACTIVO) != 0) {
//      dato = float_a_IEEE754(ion_amonio);
//////////      sprintf(String_float, "%2X%2X%2X%2X", (dato >> 24), (dato >> 16), (dato >> 8), dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      num_caracteres = num_caracteres + 8;
//   }
//   if((sensores & SEN_NH3N_ACTIVO) != 0){
//      dato = float_a_IEEE754(amoniaco);
//////////      sprintf(String_float, "%2X%2X%2X%2X", (dato >> 24), (dato >> 16), (dato >> 8), dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      num_caracteres = num_caracteres + 8;
//   }
//   if((sensores & SEN_K_ACTIVO) != 0){
//      dato = float_a_IEEE754(ion_potasio);
//////////      sprintf(String_float, "%2X%2X%2X%2X", (dato >> 24), (dato >> 16), (dato >> 8), dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      num_caracteres = num_caracteres + 8;
//   }
//   for(i = 0; i <= num_caracteres; i++){
//      if((data6[i] == ' ') || (data6[i] == 0)) data6[i] = '0';
//   }
//   num_caracteres = num_caracteres + 1;
//   return num_caracteres;  
//// </editor-fold>
//}

//uint8_t Construir_string_f(char *data6, uint16_t id_estanque, float ion_potasio, float amoniaco, float ion_amonio, float orp, float ph, float conductividad, float salinidad, float saturacion, float oxigeno, float temperatura) {
//// <editor-fold defaultstate="collapsed" desc="Construir_string_f">
//   uint8_t  i = 0, num_caracteres = 0;
//   char  String_float[20] = {0};
//   uint16_t sensores = 0;
//   float dato = 0.0;
//   
//   sensores = obtener_config_sensores(id_estanque);
//   num_caracteres = sprintf(data6, "\r\n>ID:%1X%2X ", (id_estanque >> 8), id_estanque);
//   num_caracteres = num_caracteres - 1;
//   if ((sensores & SEN_T_ACTIVO) != 0) {                                                                                                                  
//      dato = temperatura;
//      sprintf(String_float, "T:%6.2f ", dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      data6[num_caracteres + 9] = String_float[8];
//      num_caracteres = num_caracteres + 9;
//   }
//   if ((sensores & SEN_O_ACTIVO) != 0) {
//      dato = oxigeno;
//      sprintf(String_float, "O:%6.2f ", dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      data6[num_caracteres + 9] = String_float[8];
//      num_caracteres = num_caracteres + 9;
//   }
//   if ((sensores & SEN_SATO_ACTIVO) != 0) {
//      dato = saturacion;
//      sprintf(String_float, "O%%:%6.2f  ", dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      data6[num_caracteres + 9] = String_float[8];
//      data6[num_caracteres + 10] = String_float[9];
//      num_caracteres = num_caracteres + 10;
//   }
//   if ((sensores & SEN_S_ACTIVO) != 0) {
//      dato = salinidad;
//      sprintf(String_float, "S:%6.2f ", dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      data6[num_caracteres + 9] = String_float[8];
//      num_caracteres = num_caracteres + 9;
//   }
//   if ((sensores & SEN_C_ACTIVO) != 0) {
//      dato = conductividad;
//      sprintf(String_float, "C:%6.2f ", dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      data6[num_caracteres + 9] = String_float[8];
//      num_caracteres = num_caracteres + 9;
//   }
//   if ((sensores & SEN_PH_ACTIVO) != 0) {
//      dato = ph;
//      sprintf(String_float, "p:%6.2f ", dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      data6[num_caracteres + 9] = String_float[8];
//      num_caracteres = num_caracteres + 9;
//   }            
//   if ((sensores & SEN_ORP_ACTIVO) != 0) {
//      dato = orp;
//      sprintf(String_float, "o:%6.2f ", dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      data6[num_caracteres + 9] = String_float[8];
//      num_caracteres = num_caracteres + 9;
//   }
//   if ((sensores & SEN_NH4_ACTIVO) != 0) {
//      dato = ion_amonio;
//      sprintf(String_float, "A:%6.2f ", dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      data6[num_caracteres + 9] = String_float[8];
//      num_caracteres = num_caracteres + 9;
//   }
//   if ((sensores & SEN_NH3N_ACTIVO) != 0) {
//      dato = amoniaco;
//      sprintf(String_float, "a:%6.2f ", dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      data6[num_caracteres + 9] = String_float[8];
//      num_caracteres = num_caracteres + 9;
//   }
//   if ((sensores & SEN_K_ACTIVO) != 0) {
//      dato = ion_potasio;
//      sprintf(String_float, "K:%6.2f ", dato);
//      data6[num_caracteres + 1] = String_float[0];
//      data6[num_caracteres + 2] = String_float[1];
//      data6[num_caracteres + 3] = String_float[2];
//      data6[num_caracteres + 4] = String_float[3];
//      data6[num_caracteres + 5] = String_float[4];
//      data6[num_caracteres + 6] = String_float[5];
//      data6[num_caracteres + 7] = String_float[6];
//      data6[num_caracteres + 8] = String_float[7];
//      data6[num_caracteres + 9] = String_float[8];
//      num_caracteres = num_caracteres + 9;
//   }
//   for(i = 0; i <= num_caracteres; i++) {
//      if (data6[i] == 0) data6[i] = '0';
//   }
//   num_caracteres = num_caracteres + 1;
//   return num_caracteres;
//// </editor-fold>
//} 

uint16_t Config(uint16_t comandos, uint16_t id_estanque, char *data9) {
// <editor-fold defaultstate="collapsed" desc="Config">
//    char data[16] = {0};
    char data[11];
    uint16_t next_comando = comandos;
   
    if(comandos == 0x0000){                                                                    //Si comandos es igual a 0X0000 la sonda acaba de encender o reiniciarse.    
        //Si las localidades del ID del estanque 1 estan en 0XFF(primera ves que enciende la sonda) cargo el ID prestablecido de estanque 1.
        if(readEEPROM_ID1_estanque() == 0xFFFF){
            DATAEE_WriteByte(L_ID_ESTANQUE, ID1H);             
            DATAEE_WriteByte((L_ID_ESTANQUE + 1), ID1L);
        }
        //Si las localidads de la configuracion de lecturas de estanque 1 esta en 0xFF(primera ves que enciende la sonda) cargo la configuracion prestablecida de estanque 1.
        if(readEEPROM_configuracion_estanque1() == 0xFFFF){
            DATAEE_WriteByte(L_CONFIGURACION_ESTANQUE_1, CONFIG1H_sensores);
            DATAEE_WriteByte((L_CONFIGURACION_ESTANQUE_1 + 1), CONFIG1L_sensores);
        }
        #ifndef ALIMENTADOR_CON_SONDA
        //Si las localidades del ID del estanque 2 estan en 0XFF(primera ves que enciende la sonda) cargo el ID prestablecido de estanque 2.
        if(readEEPROM_ID2_estanque() == 0xFFFF){
            DATAEE_WriteByte(L_ID2_ESTANQUE, ID2H);             
            DATAEE_WriteByte((L_ID2_ESTANQUE + 1), ID2L); 
        }
        //Si las localidads de la configuracion de lecturas de estanque 2 esta en 0XFF(primera ves que enciende la sonda) cargo la configuracion prestablecida de estanque 2.
        if(readEEPROM_configuracion_estanque2() == 0xFFFF){
            DATAEE_WriteByte(L_CONFIGURACION_ESTANQUE_2, CONFIG2H_sensores);
            DATAEE_WriteByte((L_CONFIGURACION_ESTANQUE_2 + 1), CONFIG2L_sensores);
        }
        #endif
      
//        if (revisarConfigSondaEnBlanco(L_MAC_DISPOSITIVO_CONFIGURADOR, 8)){                               //Si las localidads de la configuracion de lecturas de estanque 2 esta en 0XFF(primera ves que enciende la sonda) cargo la configuracion prestablecida de estanque 2.
//            DATAEE_WriteByte(L_MAC_DISPOSITIVO_CONFIGURADOR, DAL_INIT_10);                                                      //Si las localidades donde se guarda la mac del configurador enstan en FF las inicializo con DAL_INIT[1].
//            DATAEE_WriteByte((L_MAC_DISPOSITIVO_CONFIGURADOR + 1), DAL_INIT_11);
//            DATAEE_WriteByte((L_MAC_DISPOSITIVO_CONFIGURADOR + 2), DAL_INIT_12);         
//            DATAEE_WriteByte((L_MAC_DISPOSITIVO_CONFIGURADOR + 3), DAL_INIT_13);
//            DATAEE_WriteByte((L_MAC_DISPOSITIVO_CONFIGURADOR + 4), DAL_INIT_14);
//            DATAEE_WriteByte((L_MAC_DISPOSITIVO_CONFIGURADOR + 5), DAL_INIT_15);
//            DATAEE_WriteByte((L_MAC_DISPOSITIVO_CONFIGURADOR + 6), DAL_INIT_16);         
//            DATAEE_WriteByte((L_MAC_DISPOSITIVO_CONFIGURADOR + 7), DAL_INIT_17);
//        }
        
        //Calibracion Temperatura
        if(revisarConfigSondaEnBlanco(L_VALOR_CALIBRACION_TEMPERATURA1, 4)){
            DATAEE_WriteByte(L_VALOR_CALIBRACION_TEMPERATURA1, 0x3F);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA1 + 1), 0x80);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA1 + 2), 0x00);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA1 + 3), 0x00);
        }
        if(revisarConfigSondaEnBlanco(L_VALOR_CALIBRACION_TEMPERATURA1_OFFSET, 4)){
            DATAEE_WriteByte(L_VALOR_CALIBRACION_TEMPERATURA1_OFFSET, 0x00);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA1_OFFSET + 1), 0x00);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA1_OFFSET + 2), 0x00);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA1_OFFSET + 3), 0x00);
        }
        #ifndef ALIMENTADOR_CON_SONDA
        //Calibracion Temperatura 2
        if(revisarConfigSondaEnBlanco(L_VALOR_CALIBRACION_TEMPERATURA2, 4)){
            DATAEE_WriteByte(L_VALOR_CALIBRACION_TEMPERATURA2, 0x3F);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA2 + 1), 0x80);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA2 + 2), 0x00);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA2 + 3), 0x00);
        }
        if(revisarConfigSondaEnBlanco(L_VALOR_CALIBRACION_TEMPERATURA2_OFFSET, 4)){
            DATAEE_WriteByte(L_VALOR_CALIBRACION_TEMPERATURA2_OFFSET, 0x00);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA2_OFFSET + 1), 0x00);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA2_OFFSET + 2), 0x00);
            DATAEE_WriteByte((L_VALOR_CALIBRACION_TEMPERATURA2_OFFSET + 3), 0x00); 
        }
        #endif

      
        ESTANQUE1.id = obtener_id_estanque(1);
        #ifndef ALIMENTADOR_CON_SONDA
        ESTANQUE2.id = obtener_id_estanque(2);
        #endif
//      data = "00141C80000";
        data[0] = '0';
        data[1] = 0x00;
        data[2] = 0x01;   //Cambiar por parametro SEN_C_ACTIVO
        data[3] = 0x41;
        data[4] = 0xC8;
        data[5] = 0x00;
        data[6] = 0x00;
        if (DATAEE_ReadByte(120) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE1.id, data);      //Setea 25.0 grados para estanque 1.
        #ifndef ALIMENTADOR_CON_SONDA
        if (DATAEE_ReadByte(160) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE2.id, data);      //Setea 25.0 grados para estanque 2.
        #endif
//      data = "00240A00000";
        data[0] = '0';
        data[1] = 0x00;
        data[2] = 0x02;
        data[3] = 0x40;
        data[4] = 0xA0;
        data[5] = 0x00;
        data[6] = 0x00;
        if (DATAEE_ReadByte(124) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE1.id, data);      //Setea 5.0 miligramos de oxigeno para estanque 1.
        #ifndef ALIMENTADOR_CON_SONDA
        if (DATAEE_ReadByte(164) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE2.id, data);      //Setea 5.0 miligramos de oxigeno para estanque 2. 
        #endif
//      data = "00442C80000";
        data[0] = '0';
        data[1] = 0x00;
        data[2] = 0x04;
        data[3] = 0x42;
        data[4] = 0xC8;
        data[5] = 0x00;
        data[6] = 0x00;
        if (DATAEE_ReadByte(128) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE1.id, data);      //Setea 100.0 porciento de saturacion para estanque 1.
        #ifndef ALIMENTADOR_CON_SONDA
        if (DATAEE_ReadByte(168) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE2.id, data);      //Setea 100.0 porciento de saturacion para estanque 2.
        #endif
//      data = "008420C0000";
        data[0] = '0';
        data[1] = 0x00;
        data[2] = 0x08;
        data[3] = 0x42;
        data[4] = 0x0C;
        data[5] = 0x00;
        data[6] = 0x00;
        if (DATAEE_ReadByte(132) == 0xFF){
            guardar_parametro(SETEAR_PARAMETRO, ESTANQUE1.id, data);      //Setea 35.0 ppt de salinidad para estanque 1.
        }
        #ifndef ALIMENTADOR_CON_SONDA
        if (DATAEE_ReadByte(172) == 0xFF){
            guardar_parametro(SETEAR_PARAMETRO, ESTANQUE2.id, data);      //Setea 35.0 ppt de salinidad para estanque 2.
        }
        #endif
//      data = "010425AC000";
        data[0] = '0';
        data[1] = 0x00;
        data[2] = 0x10;
        data[3] = 0x42;
        data[4] = 0x5A;
        data[5] = 0xC0;
        data[6] = 0x00;
        if (DATAEE_ReadByte(136) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE1.id, data);      //Setea 54.6875 mS de conductividad para estanque 1.
        #ifndef ALIMENTADOR_CON_SONDA
        if (DATAEE_ReadByte(176) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE2.id, data);      //Setea 54.6875 mS de conductividad para estanque 2.
        #endif
//      data = "02040E00000";
        data[0] = '0';
        data[1] = 0x00;
        data[2] = 0x20;
        data[3] = 0x40;
        data[4] = 0xE0;
        data[5] = 0x00;
        data[6] = 0x00;
        if (DATAEE_ReadByte(140) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE1.id, data);     //Setea 7.0 de ph para estanque 1.
        #ifndef ALIMENTADOR_CON_SONDA
        if (DATAEE_ReadByte(180) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE2.id, data);     //Setea 7.0 de ph para estanque 2.
        #endif
//      data = "040443B8000";
        data[0] = '0';
        data[1] = 0x00;
        data[2] = 0x40;
        data[3] = 0x44;
        data[4] = 0x3B;
        data[5] = 0x80;
        data[6] = 0x00;
        if (DATAEE_ReadByte(144) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE1.id, data);     //Setea 750.0 de orp en estanque 1.
        #ifndef ALIMENTADOR_CON_SONDA
        if (DATAEE_ReadByte(184) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE2.id, data);     //Setea 750.0 de orp en estanque 2.
        #endif
//      data = "08040000000";
        data[0] = '0';
        data[1] = 0x00;
        data[2] = 0x80;
        data[3] = 0x40;
        data[4] = 0x00;
        data[5] = 0x00;
        data[6] = 0x00;
        if (DATAEE_ReadByte(148) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE1.id, data);     //Setea 2.0 miligramos de ion de amonio para estanque 1.
        #ifndef ALIMENTADOR_CON_SONDA
        if (DATAEE_ReadByte(188) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE2.id, data);     //Setea 2.0 miligramos de ion de amonio para estanque 2.
        #endif
//      data = "10040000000";
        data[0] = '1';
        data[1] = 0x01;
        data[2] = 0x00;
        data[3] = 0x40;
        data[4] = 0x00;
        data[5] = 0x00;
        data[6] = 0x00;
        if (DATAEE_ReadByte(152) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE1.id, data);     //Setea 2.0 miligramos de amoniaco para estanque 1.
        #ifndef ALIMENTADOR_CON_SONDA
        if (DATAEE_ReadByte(192) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE2.id, data);     //Setea 2.0 miligramos de amoniaco para estanque 2.
        #endif
//      data = "20040000000";
        data[0] = '2';
        data[1] = 0x02;
        data[2] = 0x00;
        data[3] = 0x40;
        data[4] = 0x00;
        data[5] = 0x00;
        data[6] = 0x00;
        if (DATAEE_ReadByte(156) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE1.id, data);     //Setea 2.0 miligramos de potasio para estanque 1.
        #ifndef ALIMENTADOR_CON_SONDA
        if (DATAEE_ReadByte(196) == 0xFF) guardar_parametro(SETEAR_PARAMETRO, ESTANQUE2.id, data);     //Setea 2.0 miligramos de potasio para estanque 2.
        #endif
        
        if ((DATAEE_ReadByte(200) == 0xFF) && (DATAEE_ReadByte(201) == 0XFF)) setear_estado_estanques(LLENAR_ESTANQUE, ESTANQUE1.id);
        #ifndef ALIMENTADOR_CON_SONDA
        if ((DATAEE_ReadByte(202) == 0xFF) && (DATAEE_ReadByte(203) == 0XFF)) setear_estado_estanques(LLENAR_ESTANQUE, ESTANQUE2.id);
        #endif

        if ((DATAEE_ReadByte(261) == 0xFF) && (DATAEE_ReadByte(262) == 0XFF)) {
//            DATAEE_WriteByte(261, 0x00);
            DATAEE_WriteByte(262, 0x02); //Se quedan las localidades EEPROM 261 = 0xFF y 262 = 0x02
//            obtener_referencias(CALIBRAR_TEMP_H, ESTANQUE1.id);
//            obtener_referencias(CALIBRAR_O2_H, ESTANQUE1.id);
//            obtener_referencias(CALIBRAR_SAL_H, ESTANQUE1.id);
//            obtener_referencias(CALIBRAR_CON_H, ESTANQUE1.id);
//            obtener_referencias(CALIBRAR_PH_H, ESTANQUE1.id);
//            obtener_referencias(CALIBRAR_ORP_H, ESTANQUE1.id);
//            obtener_referencias(CALIBRAR_AMONIO_H, ESTANQUE1.id);
        }
        
        #ifndef ALIMENTADOR_CON_SONDA
        if ((DATAEE_ReadByte(261 + 58) == 0xFF) && (DATAEE_ReadByte(262 + 58) == 0xFF)){
            obtener_referencias(CALIBRAR_TEMP_H, ESTANQUE2.id);
            obtener_referencias(CALIBRAR_O2_H, ESTANQUE2.id);
            obtener_referencias(CALIBRAR_SAL_H, ESTANQUE2.id);
            obtener_referencias(CALIBRAR_CON_H, ESTANQUE2.id);
            obtener_referencias(CALIBRAR_PH_H, ESTANQUE2.id);
            obtener_referencias(CALIBRAR_ORP_H, ESTANQUE2.id);
            obtener_referencias(CALIBRAR_AMONIO_H, ESTANQUE2.id);
        }
        #endif
    }
   
    if ((comandos == CONFIG_SONDA) || (comandos == VIS_CON_M)){
//      LED_CIAN;
////////      guardar_mac(comandos, data9);
//        obtener_mac();         
        if(comandos == CONFIG_SONDA){
            RECEPTOR = 2;
//////         while (!direccionar_xbee(2));   //Apartir de aqui el transmisor solo puede enviar datos al configurador
//////         fprintf(Xbee, " \r\n");
//////         fprintf(Xbee, "Transmite a Configurador con MAC: %c%c%c%c%c%c%c%c \r\n", data9[0], data9[1],data9[2],data9[3],data9[4],data9[5],data9[6],data9[7]);
            __delay_ms(1000);
        }
        else if(comandos == VIS_CON_M){                                                     
//////         fprintf(Xbee, " \r\n");
//////         fprintf(Xbee, "Transmitira a Monitor con MAC: %c%c%c%c%c%c%c%c \r\n", data9[0], data9[1],data9[2],data9[3],data9[4],data9[5],data9[6],data9[7]);
            RECEPTOR = 1;                                               
            ESTANQUE1.id = obtener_id_estanque(1);
            ESTANQUE2.id = obtener_id_estanque(2);
            config1 = obtener_config_sensores(ESTANQUE1.id);
            config2 = obtener_config_sensores(ESTANQUE2.id);

            ID_superior = (uint8_t)(ESTANQUE1.id >> 8);
            ID_inferior = (uint8_t)(ESTANQUE1.id);
            __delay_ms(1000);
////////         validar = obtener_mac_propia(data);
////////         num = sprintf(bandeja_salida, ">vin%1X%2X%1X%2X%c%c%c%c%c%c%c%c", ID_superior, ID_inferior, (config1 >> 8), config1, data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7]);
//         LED_OFF;
//         ack_recibido = enviarMensaje(RECEPTOR);                                                //Apartir de aqui el transmisor solo puede enviar datos al monitor
//         if(ack_recibido == 4) {
//            LED_VERDE;
//         } else  LED_ROJO;
//         delay_ms(100);
//         LED_OFF;
//         delay_ms(1000);
            
            #ifndef ALIMENTADOR_CON_SONDA
            if (ESTANQUE2.id != 0x0000) {
                ID_superior = (uint8_t)(ESTANQUE2.id >> 8);
                ID_inferior = (uint8_t)(ESTANQUE2.id);
//////            num = sprintf(bandeja_salida, ">vin%1X%2X%1X%2X%c%c%c%c%c%c%c%c", ID_superior, ID_inferior, (config2 >> 8), config2, data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7]);
//////            ack_recibido = enviarMensaje(1);
//////            if((ack_recibido == 1) || (ack_recibido == 2)) {
//////               LED_ROJO;
//////            } else if (ack_recibido == 3) { 
//////               LED_AMARILLO;
//////            } else  LED_VERDE;
//////            delay_ms(100);
            }
            #endif
        }
////////      LED_OFF;
        next_comando = DORMIR_SONDA;    
    }
    else if((comandos == SETEAR_HORA) || (comandos == CAMBIAR_ID_UNICO) || (comandos == CAMBIAR_ID_DOBLE) || 
            (comandos == CONFIG_SENSORES) || (comandos == SETEAR_PARAMETRO) || (comandos == VACIAR_ESTANQUE) || 
            (comandos == LLENAR_ESTANQUE)){
////////      LED_CIAN;
        if (comandos == SETEAR_HORA){                                                            //Checo si llego comando de seteo de hora
////////         escribir_rtc_2(data9);
////////         enviarACK(RECEPTOR);
        }
        else if(comandos == SETEAR_PARAMETRO){ 
            guardar_parametro(comandos, id_estanque, data9);
////////         enviarACK(RECEPTOR);
        }
        else if((comandos == VACIAR_ESTANQUE) || (comandos == LLENAR_ESTANQUE)){
            setear_estado_estanques(comandos, id_estanque);
            estado_estanques = obtener_estado_estanques();
            if(estado_estanques == 0){
                AE_ESTANQUES = 0;
////////            output_high(ENABLE_2); 
            }
            else{
                AE_ESTANQUES = 1;
////////            output_low(ENABLE_2);
            }
        
            if(AE_ESTANQUES == 0){                                                               //Si acabo de apagar sensores establesco E_ESTANQUES en 0 para no iniciar sensores
                E_ESTANQUES = 0;
            }
            else if((AE_ESTANQUES == 1) && (E_ESTANQUES == 0)){                                //Si acabo de encender sensores y anteriormente los apague establesco E_ESTANQUES en 1 para iniciar sensores
                E_ESTANQUES = 1;
            }
        }
        else{
            __delay_ms(1000);
        }
        
        guardar_id_estanques(comandos, data9);
        guardar_config_sensores(comandos, id_estanque, data9);
////////      LED_OFF;
        if (comandos == SETEAR_PARAMETRO) {
            next_comando = PROG_T_L;
            temp0 = 0;
            temp1 = 0;
        }
        else{
            next_comando = DORMIR_SONDA;
        }
    }
    return next_comando;
// </editor-fold>
}

void saveEEPROM_ID1(uint16_t id){
// <editor-fold defaultstate="collapsed" desc="Guarda en EEPROM la ID del estanque 1">
    DATAEE_WriteByte(L_ID_ESTANQUE, (uint8_t)(id >> 8));
    DATAEE_WriteByte((L_ID_ESTANQUE + 1), (uint8_t)(id));
// </editor-fold>
}

void saveEEPROM_ID2(uint16_t id){
// <editor-fold defaultstate="collapsed" desc="Guarda en EEPROM la ID del estanque 2">
    DATAEE_WriteByte(L_ID2_ESTANQUE, (uint8_t)(id >> 8));
    DATAEE_WriteByte((L_ID2_ESTANQUE + 1), (uint8_t)(id));
// </editor-fold>
}

void saveEEPROM_configuration_estanque1(uint16_t configuracion){
// <editor-fold defaultstate="collapsed" desc="Guarda la configuracion del estanque 1">
    DATAEE_WriteByte(L_CONFIGURACION_ESTANQUE_1, (uint8_t)(configuracion >> 8));
    DATAEE_WriteByte((L_CONFIGURACION_ESTANQUE_1 + 1), (uint8_t)(configuracion));
// </editor-fold>
}

void saveEEPROM_configuration_estanque2(uint16_t configuracion){
// <editor-fold defaultstate="collapsed" desc="Guarda la configuracion del estanque 2">
    DATAEE_WriteByte(L_CONFIGURACION_ESTANQUE_2, (uint8_t)(configuracion >> 8));
    DATAEE_WriteByte((L_CONFIGURACION_ESTANQUE_2 + 1), (uint8_t)(configuracion));
// </editor-fold>
}

uint16_t readEEPROM_ID1_estanque(void){
// <editor-fold defaultstate="collapsed" desc="Leer el ID 1 del estanque de la EEPROM">
    uint16_t id_estanque = 0;
    
    id_estanque = DATAEE_ReadByte(L_ID_ESTANQUE);
    id_estanque = (id_estanque << 8) | DATAEE_ReadByte(L_ID_ESTANQUE + 1);
    
    return id_estanque;
// </editor-fold>
}

uint16_t readEEPROM_ID2_estanque(void){
// <editor-fold defaultstate="collapsed" desc="Leer el ID 2 del estanque de la EEPROM">
    uint16_t id_estanque = 0;
    
    id_estanque = DATAEE_ReadByte(L_ID2_ESTANQUE);
    id_estanque = (id_estanque << 8) | DATAEE_ReadByte(L_ID2_ESTANQUE + 1);
    
    return id_estanque;
// </editor-fold>
}

uint16_t readEEPROM_configuracion_estanque1(void){
// <editor-fold defaultstate="collapsed" desc="Leer configuracion del estanque 1 de la EEPROM">
    uint16_t configuracion_estanque = 0;
    
    configuracion_estanque = DATAEE_ReadByte(L_CONFIGURACION_ESTANQUE_1);
    configuracion_estanque = (configuracion_estanque << 8) | DATAEE_ReadByte(L_CONFIGURACION_ESTANQUE_1 + 1);
   
    return configuracion_estanque;
// </editor-fold>
}

uint16_t readEEPROM_configuracion_estanque2(void){
// <editor-fold defaultstate="collapsed" desc="Leer configuracion del estanque 2 de la EEPROM">
    uint16_t configuracion_estanque = 0;
    
    configuracion_estanque = DATAEE_ReadByte(L_CONFIGURACION_ESTANQUE_1);
    configuracion_estanque = (configuracion_estanque << 8) | DATAEE_ReadByte(L_CONFIGURACION_ESTANQUE_1 + 1);
   
    return configuracion_estanque;
// </editor-fold>
}

void sleep_sonda(void){
// <editor-fold defaultstate="collapsed" desc="Dormir Sonda">
//    RTC.segundos = getSeconds_RTC();
//    RTC.minutos = getMinutes_RTC();
//    RTC.hora = getHour_RTC();
//    RTC.dia_semana = getDay_RTC();
//    RTC.dia_del_mes = getDate_RTC();
//    RTC.mes = getMonth_RTC();
//    RTC.anio = getYear_RTC();
         
//    if (((rtc[0] <= 0x05) || (BOTON_FUNC3 == 0)) &&  ((rtc[1] == 0x27) || (rtc[1] == 0x57) || (BOTON_FUNC3 == 0))) { //despertara cada 30 minutos 
    if (BOTON_FUNC3 == 0){
//        temp0 = 0;
//        temp1 = 0;
//        if (estado_estanques == 0) {
//            DISABLE_EN1
//        } else ENABLE_EN1
//        ESTANQUE1.id = obtener_id_estanque(1);
//        ESTANQUE2.id = obtener_id_estanque(2);
        COMANDO = TOMAR_LECTURAS;                                                           //Fuerzo comando para tomar lecturas de ambos estanques.
    }
//    else {
//        temp0 = temp0 + 1;
////            if ((temp0 > 100) && (temp0 < 3000)) {                                              //Mantengo apagado led durante 990mS.
////               LED_OFF;
////            } else if (temp0 >= 3000) {                                                         //Numero de ciclos para completar 1 segundo.
////               temp0 = 0;
////               LED_AZUL;                                                                        //Enciendo led.
////            }     
//         }
// </editor-fold>
}

void calibracion(void){
// <editor-fold defaultstate="collapsed" desc="calibracion temperaturas">
    ESTANQUE1.id = obtener_id_estanque(1);
    config1 = obtener_config_sensores(ESTANQUE1.id);
    #ifndef ALIMENTADOR_CON_SONDA
    ESTANQUE2.id = obtener_id_estanque(2);
    config2 = obtener_config_sensores(ESTANQUE2.id);
    #endif
    estado_estanques = obtener_estado_estanques();
//    if(estado_estanques == 0) ENABLE_EN1;                                       //Si no hay ningun estanque lleno enciendo la alimentacion de los sensores
    if(((COMANDO == CALIBRAR_TEMP_L) || (COMANDO == CALIBRAR_TEMP_H)) && (ESTANQUE1.id == ID_EN_COMANDO)){
        calibrar_temperatura(COMANDO, DATO_SETPOINT, DATO_SETPOINT, 0x01, config1);
    }
    #ifndef ALIMENTADOR_CON_SONDA
    else if(((COMANDO == CALIBRAR_TEMP_L) || (COMANDO == CALIBRAR_TEMP_H)) && (ESTANQUE2.id == ID_EN_COMANDO) && (ESTANQUE2.id != 0X0000)){
        calibrar_temperatura(COMANDO, DATO_SETPOINT, DATO_SETPOINT, 0x03, config2);
    }
    #endif
    else if(((COMANDO == CALIBRAR_O2_L) || (COMANDO == CALIBRAR_O2_H)) && (ESTANQUE1.id == ID_EN_COMANDO)){
        desun_calibrar_o2(COMANDO, DATO_SETPOINT, DATO_SETPOINT, 0x01);
    }
    #ifndef ALIMENTADOR_CON_SONDA
    else if(((COMANDO == CALIBRAR_O2_L) || (COMANDO == CALIBRAR_O2_H)) && (ESTANQUE2.id == ID_EN_COMANDO) && (ESTANQUE2.id != 0x0000)){
        desun_calibrar_o2(COMANDO, DATO_SETPOINT, DATO_SETPOINT, 0x03);
    }
    #endif
    else if (((COMANDO == CALIBRAR_SAL_L) || (COMANDO == CALIBRAR_SAL_H) || (COMANDO == CALIBRAR_CON_L) || (COMANDO == CALIBRAR_CON_H)) && (ESTANQUE1.id == ID_EN_COMANDO)) {
        desun_calibrar_salinidad(COMANDO, DATO_SETPOINT, DATO_SETPOINT, presion, 0x02);
    }
    #ifndef ALIMENTADOR_CON_SONDA
    else if (((COMANDO == CALIBRAR_SAL_L) || (COMANDO == CALIBRAR_SAL_H) || (COMANDO == CALIBRAR_CON_L) || (COMANDO == CALIBRAR_CON_H)) && (ESTANQUE2.id == ID_EN_COMANDO) && (ESTANQUE2.id != 0x0000)) {
        desun_calibrar_salinidad(COMANDO, DATO_SETPOINT, DATO_SETPOINT, presion, 0x04);
    }
    #endif
//    if (estado_estanques == 0) DISABLE_EN1;                                      //Si no hay ningun estanque lleno apago la alimentacion de los sensores
    COMANDO = DORMIR_SONDA;
// </editor-fold>
}

void tomar_lecturas(void){
// <editor-fold defaultstate="collapsed" desc="Toma las mediciones de las lecturas">
    ESTANQUE1.id = obtener_id_estanque(1);
    config1 = obtener_config_sensores(ESTANQUE1.id);
    #ifndef ALIMENTADOR_CON_SONDA
    ESTANQUE2.id = obtener_id_estanque(2);
    config2 = obtener_config_sensores(ESTANQUE2.id);
    #endif
    estado_estanques = obtener_estado_estanques();
    if ((((config1 & SEN_S_C_DESUN_ACTIVO) != 0x0000) && (ESTANQUE1.conductividad <= 5.0)) || 
        (((config2 & SEN_S_C_DESUN_ACTIVO) != 0x0000) && (conductividad2 <= 5.0)) || (estado_estanques != 0)){  
        if (E_ESTANQUES == 1){
            desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x01);                                
            desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x02);
            desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x03);
            desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x04);
        }
        else if (estado_estanques == 1) {
            desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x01);                              
            desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x02);                                     
        }
        #ifndef ALIMENTADOR_CON_SONDA
        else if (estado_estanques == 2) {
            desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x03);
            desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x04);
        }
        #endif
        else if (estado_estanques == 3) {
            desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x01);                                
            desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x02);
            desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x03);
            desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x04);
        }
    }
         
    //Ejecuto si el sistema necesita tomar lecturas en ambos estanques o si el sistema necesita tomar lecturas solo en estanque 1 o si se le ordeno tomar lecturas de el estanque 1.
    if (((estado_estanques != 0) && (estado_estanques != 2)) || (ESTANQUE1.id == ID_EN_COMANDO)){
        if (((config1 & SEN_S_C_DESUN_ACTIVO) != 0x0000) && (ESTANQUE1.conductividad <= 5.0)) {  
            desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x01); 
            desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x02);
        }
        ESTANQUE1.amonio = 0.0;
        ESTANQUE1.orp = 0.0;
        ESTANQUE1.ph = 0.0;
        ESTANQUE1.conductividad = 0.0;
//        ESTANQUE1.temperatura = 0.0;
//        ESTANQUE1.saturacion = 0.0;
//        ESTANQUE1.o2 = 0.0;
//        ESTANQUE1.salinidad = 0.0;
//        if (config1 == SEN_T_ACTIVO) {                                                      //Si el estanque 1 solo tiene sensor de temperatura obtenemos temperatura con pt-1000
//////////    ESTANQUE1.temperatura = obtener_temperatura_PT_1000();
//            ESTANQUE1.temperatura = compensar_temperatura(ESTANQUE1.temperatura, 0x01);
//        }
        if ((config1 & SEN_T_O_SATO_DESUN_ACTIVO) != 0x0000) {                       //Si el estanque 1 tiene sensor de temperatura y O2 obtenemos temperatura, saturacion y O2 con sensor 1 de Desun
            desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x01);
//            ESTANQUE1.temperatura = desun_temperatura(0x01);
            desun_TemperaturaSaturacion(0x01);
            ESTANQUE1.temperatura = compensar_temperatura(ESTANQUE1.temperatura, 0x01);
//            ESTANQUE1.saturacion = desun_saturacion(0x01);
            ESTANQUE1.salinidad = obtener_parametro(ESTANQUE1.id, SEN_S_ACTIVO);
        }
        if ((config1 & SEN_S_C_DESUN_ACTIVO) != 0x0000) {                                                     //Si el estanque 1 tiene sensor de conductividad obtenemos salinidad con sensor 2 de Desun
            ESTANQUE1.salinidad = mili_Siemens = 0.0;
            ESTANQUE1.salinidad = desun_salinidad(0x02, presion);
            ESTANQUE1.conductividad = mili_Siemens;
        }
        ESTANQUE1.o2 = oxigeno(ESTANQUE1.saturacion, ESTANQUE1.temperatura, ESTANQUE1.salinidad);
    }
    
    #ifndef ALIMENTADOR_CON_SONDA
    //Ejecuto si el sistema necesita tomar lecturas en ambos estanques o si se le ordeno tomar lecturas de el estanque 2.
    if (((ESTANQUE2.id != 0x0000) && (estado_estanques != 0) && (estado_estanques != 1)) || 
        ((ESTANQUE2.id == ID_EN_COMANDO) && (ESTANQUE2.id != 0x0000))) {
        if (((config2 & SEN_S_C_DESUN_ACTIVO) != 0x0000) && (conductividad2 <= 5.0)) {  
            desun_start_measurements(SEN_T_O_SATO_DESUN_ACTIVO, 0x03);
            desun_start_measurements(SEN_S_C_DESUN_ACTIVO, 0x04);
        }
        amonio2 = orp2 = ph2 = conductividad2 = sal2 = saturacion2 = O2_mgl_2 = temperatura2 = 0.0;
        if (config2 == SEN_T_ACTIVO) {                                                      //Si el estanque 1 solo tiene sensor de temperatura obtenemos temperatura con pt-1000
////////    temperatura2 = obtener_temperatura_PT_1000();
            temperatura2 = compensar_temperatura(temperatura2, 0x03);
        }
        else if ((config2 & SEN_T_O_SATO_DESUN_ACTIVO) != 0x0000) {                       //Si el estanque 1 tiene sensor de temperatura y O2 obtenemos temperatura, saturacion y O2 con sensor 1 de Desun
            temperatura2 = desun_temperatura(0x03);
            temperatura2 = compensar_temperatura(temperatura2, 0x03);
            saturacion2 = desun_saturacion(0x03);
            sal2 = obtener_parametro(ESTANQUE2.id, SEN_S_ACTIVO);
        }
        if ((config2 & SEN_S_C_DESUN_ACTIVO) != 0x0000) {                                   //Si el estanque 1 tiene sensor de conductividad obtenemos salinidad con sensor 2 de Desun
            sal2 = 0.0, mili_Siemens = 0.0;
            sal2 = desun_salinidad(0x04, presion);
            conductividad2 = mili_Siemens;
        }
        O2_mgl_2 = oxigeno(saturacion2, temperatura2, sal2);
    }
    #endif
    
    med_falsas = med_falsas + 1;
    if ((((config1 & SEN_S_C_DESUN_ACTIVO) != 0x0000) && (ESTANQUE1.conductividad <= 5.0) && (med_falsas < 2) && (estado_estanques != 0)) || 
        (((config2 & SEN_S_C_DESUN_ACTIVO) != 0x0000) && (conductividad2 <= 5.0) && (med_falsas < 2) && (estado_estanques != 0))){ 
        DISABLE_EN1
        __delay_ms(1000);
        ENABLE_EN1
        COMANDO = TOMAR_LECTURAS;
    }
    else if (COMANDO == T_E_LECTURAS){
        med_falsas = 0;
        COMANDO = ENVIAR_LECTURA;
    }
    else {
        med_falsas = 0;
        COMANDO = ESPERAR_PETICION;
    }
    if ((estado_estanques == 0) || (estado_estanques == 2)){
        ESTANQUE1.potasio = 0.0;
        ESTANQUE1.ion_amonio = 0.0;
        ESTANQUE1.amonio = 0.0;
        ESTANQUE1.orp = 0.0;
        ESTANQUE1.ph = 0.0;
        ESTANQUE1.conductividad = 0.0;
        ESTANQUE1.temperatura = 0.0;
        ESTANQUE1.saturacion = 0.0;
        ESTANQUE1.o2 = 0.0;
        ESTANQUE1.salinidad = 0.0;
    }
//Ya no se ocupara guardar las lecturas en EEPROM
////    guardar_lecturas(ESTANQUE1.id, potasio1, amonio1, ion_amonio1, orp1, ph1, conductividad1, sal1, saturacion1, O2_mgl_1, temperatura1);
    if ((estado_estanques == 0) || (estado_estanques == 1)) {
        potasio2 = amonio2 = ion_amonio2 = orp2 = ph2 = conductividad2 = sal2 = saturacion2 = O2_mgl_2 = temperatura2 = 0.0;
    }
    
    saveHoraMediciones(&ESTANQUE1_HORA);    //Guarda la hora en que tomo las lecturas
    Sonda.tomandoLecturas = false;
//Ya no se ocupara guardar las lecturas en EEPROM
////    guardar_lecturas(ESTANQUE2.id, potasio2, amonio2, ion_amonio2, orp2, ph2, conductividad2, sal2, saturacion2, O2_mgl_2, temperatura2);
// </editor-fold>
}

uint16_t calculoNextMedicion(void){
    uint16_t horaActual = convertTime_minutes();
    uint16_t horaSiguienteMedicion = 0;
    
    do{
        horaSiguienteMedicion += intervaloMediciones;
    }while(horaSiguienteMedicion < horaActual);
    
    return horaSiguienteMedicion;
}

//void esperar_peticion(void){
//// <editor-fold defaultstate="collapsed" desc="Esperar Peticion">
//    temp0 = temp0 + 1;
////         if ((temp0 > 30000) && (temp0 < 60000)) {                                              //Mantengo apagado led durante 500mS
////            LED_OFF;
////         } else if (temp0 >= 60000) {                                                           //Mantengo encendido led durante 500mS
////            temp1 = temp1 + 1;
////            temp0 = 0;
////            LED_AZUL;
////         }
//    if ((temp1 >= 180) && (COMANDO == ESPERAR_PETICION)) {                                 //Espero 3 minutos para ejecutar comando de dormir sonda
//        COMANDO = DORMIR_SONDA;
//    } else if ((temp1 >= 2) && (COMANDO == PROG_T_L)) {                                   //Espero 3 segundos para ejecutar comando de tomar lecturas
//        COMANDO = TOMAR_LECTURAS;
//    }
//// </editor-fold>
//}

//void enviar_lecturas(void){
//// <editor-fold defaultstate="collapsed" desc="Enviar las lecturas de las mediciones">
//    rtc[0] = getSeconds_RTC();
//    rtc[1] = getMinutes_RTC();
//    rtc[2] = getHour_RTC();
//    rtc[3] = getDay_RTC();
//    rtc[4] = getDate_RTC();
//    rtc[5] = getMonth_RTC();
//    rtc[6] = getYear_RTC();                                                                        //Actualizo los datos necesarios de el rtc para contruir string
//    ESTANQUE1.id = obtener_id_estanque(1);
//    ESTANQUE2.id = obtener_id_estanque(2);
//    config1 = obtener_config_sensores(ESTANQUE1.id);
//    config2 = obtener_config_sensores(ESTANQUE2.id);
//    if (ID_EN_COMANDO == ESTANQUE1.id) {
//        obtener_lecturas(ESTANQUE1.id);
//        num1 = Construir_string_f(bandeja_salida, ESTANQUE1.id, 0.0, 0.0, amonio1, orp1, ph1, conductividad1, sal1, saturacion1, O2_mgl_1, temperatura1);
//        num = num1;
////      ack_recibido = enviarMensaje(2);
////      if(ack_recibido == 4) {
////         LED_VERDE;
////      } else LED_ROJO;
//        ID_EN_COMANDO = 0x0000;
//    } else if ((ID_EN_COMANDO == ESTANQUE2.id) && (ESTANQUE2.id != 0x0000)) {
//        obtener_lecturas(ESTANQUE2.id);
//        num2 = Construir_string_f(bandeja_salida, ESTANQUE2.id, 0.0, 0.0, amonio2, orp2, ph2, conductividad2, sal2, saturacion2, O2_mgl_2, temperatura2);
//        num = num2;
////      ack_recibido = enviarMensaje(2);
////      if(ack_recibido == 4) {
////          LED_VERDE;
////      } else LED_ROJO;
//        ID_EN_COMANDO = 0x0000;
//    }
//    if (ID_EN_COMANDO == ESTANQUE1.id) {                                                   //Si llego comando de enviar lecturas de estanque 1 construllo el string correspondiente con los datos obtenidos de el estanque 1
//        obtener_lecturas(ESTANQUE1.id);
//        num1 = Construir_string(bandeja_salida, rtc[4], rtc[5], rtc[6], rtc[2], rtc[1], ESTANQUE1.id, 0.0, 0.0, amonio1, orp1, ph1, conductividad1, sal1, saturacion1, O2_mgl_1, temperatura1);
//        num = num1;
////      ack_recibido = enviarMensaje(RECEPTOR);
////      if(ack_recibido == 4) {
////         LED_VERDE;
////      } else LED_ROJO;
//    } else if ((ID_EN_COMANDO == ESTANQUE2.id) && (ESTANQUE2.id != 0x0000)) {              //Si llego comando de enviar lecturas de estanque 2 construllo el string correspondiente con los datos obtenidos de el estanque 2
//        obtener_lecturas(ESTANQUE2.id);
//        num2 = Construir_string(bandeja_salida, rtc[4], rtc[5], rtc[6], rtc[2], rtc[1], ESTANQUE2.id, 0.0, 0.0, amonio2, orp2, ph2, conductividad2, sal2, saturacion2, O2_mgl_2, temperatura2);
//        num = num2;
////      ack_recibido = enviarMensaje(RECEPTOR);
////      if(ack_recibido == 4) {
////         LED_VERDE;
////      } else LED_ROJO;
//    }
//    COMANDO = ESPERAR_PETICION;                                                            //Hago comando igual a esperar peticion para que siga esperando
//    temp0 = 0;                                                                             //Actualizo contador para mentener encendido led en verde por 1 segundo
//    temp1 = 0;
//// </editor-fold>
//}

void captura_datos_RX_sensor(void){
// <editor-fold defaultstate="collapsed" desc="Captura los datos recibidos por el USART2">
   buffer1[contador] = UART2_Read();
   if(contador >= 49) {
      contador = 0;
   } else contador++;   
// </editor-fold>
}

void resetSonda(void){
    reset_xbee();
    RESET();
}

void configTimeMeasurements(void){
// <editor-fold defaultstate="collapsed" desc="Configurar tiempo intervalo entre mediciones">
    saveEEPROMTimeMeasurements(serial_cadena);
    intervaloMediciones = readTimeMeasurements();
    timeNextMedicion = calculoNextMedicion();
// </editor-fold>
}

void configHighLowPointCalibration(void){
// <editor-fold defaultstate="collapsed" desc="Configurar Punto alto o Bajo de calibracion">
    uint8_t bufferIEEE[4] = {0};
    
    acomodarBytesIEEE(bufferIEEE, serial_cadena, 22);
    if(revIDSonda(serial_cadena)){
        ID_EN_COMANDO = obtener_id_estanque(1);
    }
    COMANDO = revValorCalibrar(decodificarByteParametros(serial_cadena), serial_cadena);
    DATO_SETPOINT = IEEE754_A_Float(bufferIEEE);
// </editor-fold>
}

void controlTomarLecturas(void){
    if(RTC.hourChange){
        timeNextMedicion = calculoNextMedicion();
        diaHoySonda = getDay_RTC();
        RTC.hourChange = false;
    }
    
    if((timeNextMedicion - 1) <= hora_en_minutos){
        controlLedTomandoLecturas();
        tomar_lecturas();
        timeNextMedicion += intervaloMediciones;
    }
    else if(diaHoySonda != getDay_RTC()){
        timeNextMedicion -= 1440;
        diaHoySonda = getDay_RTC();
    }
    
    if((COMANDO == TOMAR_LECTURAS) || (COMANDO == T_E_LECTURAS)){
        controlLedTomandoLecturas();
        tomar_lecturas();
    }
}

void controlLedTomandoLecturas(void){
    LED_VERDE_APAGADO
    LED_ROJO_APAGADO
    timeBlinkLedTomandoLecturas = 0;
    Sonda.tomandoLecturas = true;
    TMR1_StartTimer();
}

void controlBlinkLEDInterrupcion(void){
    if(!Sonda.tomandoLecturas){
        TMR1_StopTimer();
        LED_VERDE_APAGADO
        LED_ROJO_APAGADO
    }
    else if(timeBlinkLedTomandoLecturas > 10){
        TOGGLE_LED_VERDE
        timeBlinkLedTomandoLecturas = 0;
    }
    else{
        timeBlinkLedTomandoLecturas++;
    }
}

uint16_t decodificarByteParametros(uint8_t *ptrBufferRX){
// <editor-fold defaultstate="collapsed" desc="Decodificar Byte de paratemtros a un valor hexadecimal">
    uint16_t parametrosHexadecimal = 0;
    
    parametrosHexadecimal = decodificar_numero_ASCII(ptrBufferRX[18 + i]);
    parametrosHexadecimal = parametrosHexadecimal << 8;
    parametrosHexadecimal |= decodificar_numero_ASCII(ptrBufferRX[19 + i]);
    parametrosHexadecimal |= decodificar_numero_ASCII(ptrBufferRX[20 + i]);
    
    return parametrosHexadecimal;
// </editor-fold>
}

uint16_t revValorCalibrar(uint16_t byteParametros, uint8_t *ptrBufferRX){
// <editor-fold defaultstate="collapsed" desc="Regresa el valor de comando segundo el byte de parametro y si es punto bajo o alto">
    if(ptrBufferRX[21] == 'L'){
        switch(byteParametros){
            case 0x0001:
                return CALIBRAR_TEMP_L;
            case 0x0002:
                return 0;
            case 0x0004:
                return CALIBRAR_O2_L;
            case 0x0007:
                return 0;
            case 0x0008:
                return 0;
            case 0x0010:
                return 0;
            case 0x0020:
                return 0;
            case 0x0040:
                return 0;
            case 0x0070:
                return 0;
            case 0x0080:
                return 0;
            case 0x01000:
                return 0;
            case 0x02000:
                return 0;
        }
        
    }
    else if(ptrBufferRX[21] == 'H'){
        switch(byteParametros){
            case 0x0001:
                return CALIBRAR_TEMP_H;
            case 0x0002:
                return 0;
            case 0x0004:
                return CALIBRAR_O2_H;
            case 0x0007:
                return 0;
            case 0x0008:
                return 0;
            case 0x0010:
                return 0;
            case 0x0020:
                return 0;
            case 0x0040:
                return 0;
            case 0x0070:
                return 0;
            case 0x0080:
                return 0;
            case 0x01000:
                return 0;
            case 0x02000:
                return 0;
        }
    }
    
    return 0xFFFF;
// </editor-fold>
}

bool revIDSonda(uint8_t *ptrBufferRX){
// <editor-fold defaultstate="collapsed" desc="Check ID Alimentador">
    if((ptrBufferRX[15] == ID_SONDA_ASCII1) && (ptrBufferRX[16] == ID_SONDA_ASCII2) && (ptrBufferRX[17] == ID_SONDA_ASCII3)){
        return  true;
    }
    
    return  false;
// </editor-fold>
}

bool revisarConfigSondaEnBlanco(uint16_t localidadEEPROM, uint8_t cantidadLocalidadesEEPROM){
    uint8_t cantidadValoresEnBlanco = 0;
            
    for(uint8_t i = 0; i < cantidadLocalidadesEEPROM; i++){
        if(DATAEE_ReadByte(localidadEEPROM + i) == 0xFF){
            cantidadValoresEnBlanco++;
        }
    }
    
    if(cantidadValoresEnBlanco == cantidadLocalidadesEEPROM){
        return true;
    }
    
    return false;
}