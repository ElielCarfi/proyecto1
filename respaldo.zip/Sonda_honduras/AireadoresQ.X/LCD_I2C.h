#include <stdio.h>
#include <xc.h> 
#include <stdbool.h>
#include <stdio.h>
#include "mcc_generated_files/mcc.h"
#include "i2c.h"
#include "i2c1_master_example.h"
#include <math.h>

/************************************************************************/
/* Comportamiento de RS                                                 */
/************************************************************************/
#define COMMAND      0
#define DATA        1

/************************************************************************/
/* DEFINIR EL PUERTO DONDE SE VA CONECTAR LA LCD                        */
/************************************************************************/
uint8_t RS;    
uint8_t EN;   
#define D4    3
#define D5    5
#define D6    6
#define D7    7

#define COL       16
#define ROW       2


/************************************************************************/
/*  MODO CELAR DISPLAY:  D7 D6 D5 D4 D3 D2 D1 D0                        */
/*                       0  0  0  0  0  0  0  1                         */
/************************************************************************/
#define _LCD_CLEARDISPLAY 1
//ESPERAR 1.5 ms

/************************************************************************/
/*  MODO CELAR RETURN HOME:  D7 D6 D5 D4 D3 D2 D1 D0                    */
/*                           0  0  0  0  0  0  1  0                     */
/************************************************************************/
#define _LCD_RETURNHOME     2
//ESPERAR 1.5 ms

/************************************************************************/
/*      ENTRAMOS EN MODE SET:  D7 D6 D5 D4 D3 D2 D1  D0                 */
/*      					   0  0  0  0  0  1  I/D  S                 */
/*----------------------------------------------------------------------*/
/*      I/D = 1: Inc                                                    */
/*		      0: Dec                                                    */
/*		S   = 1: SHIFT ON                                               */
/*            0: SHIFT OFF                                              */
/***********************************************************************/
#define _LCD_ENTRYMODESET   4
#define _LCD_INCREMENT      2
#define _LCD_DECREMENT      0
#define _LCD_SHIFT_ON       1
#define _LCD_SHIFT_OFF      0
//ESPERAR 31 us

/************************************************************************/
/*      ENTRAMOS EN DISPLAY CONTROL:  D7 D6 D5 D4  D3 D2 D1 D0          */
/*      						      0  0  0  0   1  D  U  B           */
/*----------------------------------------------------------------------*/
/*      D   = 1: DISPLAY ON                                             */
/*		      0: DISPLAY OFF                                            */
/*		U   = 1: CURSOR ON                                              */
/*		      0: CURSOR OFF                                             */
/*		B   = 1: BLINK                                                  */
/*		      0: NO BLINK                                               */
/************************************************************************/
#define _LCD_DISPLAYCONTROL 8
#define _LCD_DISPLAY_ON     4
#define _LCD_DISPLAY_OFF    0
#define _LCD_CURSOR_ON      2
#define _LCD_CURSOR_OFF     0
#define _LCD_BLINK_ON       1
#define _LCD_BLINK_OFF      0
//ESPERAR 31 us

/************************************************************************/
/* ENTRAMOS EN CURSOR OR DISPLAY SHIFT:  D7 D6 D5 D4  D3 D2  D1 D0      */
/*      						         0  0  0  1  S/C R/L  *  *      */
/*----------------------------------------------------------------------*/
/*      S/C = 1: display shift                                          */
/*		      0: cursor move                                            */
/*		R/L = 1: shift to the right                                     */
/*		      0: shift to the left                                      */
/************************************************************************/
#define _LCD_CURSORDISPLAYSHIFT 16
#define _LCD_DISPLAY_SHIFT      8
#define _LCD_CURSOR_SHIFT       0
#define _LCD_MOVERIGHT          4
#define _LCD_MOVELEFT           0

/************************************************************************/
/*      ENTRAMOS EN FUNTIONS SET:  D7 D6 D5 D4  D3 D2 D1 D0             */
/*      						   0  0  1  D/L  N  F  *  *             */
/*----------------------------------------------------------------------*/
/*      D/L = 1: modo 8 bits                                            */
/*		      0: modo 4 btis                                            */
/*		N   = 1: MODO 2 Lineas                                          */
/*		      0: MODO 1 Linea                                           */
/*		F   = 1: MATRIZ 5x10                                            */
/*		      0: MATRIZ 5x7/5x8                                         */
/************************************************************************/
#define _LCD_FUNTIONSET 40
#define _LCD_8BITMODE   16
#define _LCD_4BITMODE   0
#define _LCD_2LINE      8
#define _LCD_1LINE      0
#define _LCD_5x10DOTS   4
#define _LCD_5x7DOTS    0


/************************************************************************/
/*      SET CGRAM:  D7 D6  D5  D4   D3   D2   D1   D0                   */
/*      			0  1   ACG ACG  ACG  ACG  ACG  ACG                  */
/*----------------------------------------------------------------------*/
/*      ACG -> CGRAM ADDRESS                                            */
/************************************************************************/
#define _LCD_SET_CGRAM_ADDR  64

/************************************************************************/
/*      SET DDRAM:  D7 D6  D5  D4   D3   D2   D1   D0                   */
/*      			1  0   ADD ADD  ADD  ADD  ADD  ADD                  */
/*----------------------------------------------------------------------*/
/*      ADD -> DDRAM ADDRESS                                            */
/************************************************************************/
#define _LCD_SET_DDRAM_ADDR  128

/************************************************************************/
/* METODOS DE LIBRERIA                                                  */
/************************************************************************/

void lcd_i2cinit(void);
void lcd_load_command(uint8_t cmd);
void loadnibbles(uint8_t dato,uint8_t mode);
void lcd_load_data(uint8_t data);
void lcd_wryte(uint8_t data);
void lcd_move_cursor(uint8_t position);
void lcd_putc(char *a);
void lcd_clear(void);
void lcd_gotoxy(char a, char b);
void lcd_shift_left();
void lcd_create_char(uint8_t charnum, uint8_t * chardata);
void lcd_printf_variable(char *string, float variable, uint8_t enteros, uint8_t decimales);
void lcd_putc_limit(char *a, uint8_t caracteres);
void lcd_printf_char(char *texto, float variable, uint8_t enteros, uint8_t decimales, char *complemento);
void lcd_pantalla_flechas(float ph_variable, float temperatura, float distancia, bool estado);