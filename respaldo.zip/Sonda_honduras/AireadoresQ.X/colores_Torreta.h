/* 
 * File:   colores_Torreta.h
 * Author: acuic
 *
 * Created on 19 de marzo de 2022, 11:32 AM
 */

#ifndef COLORES_TORRETA_H
#define	COLORES_TORRETA_H

#include <xc.h>
    
//COLORES LED
#define LED_ROJO        LATCbits.LATC3 = 1;  //LED COLOR ROJO
#define LED_NARANJA     LATDbits.LATD0 = 1;  //LED COLOR NARANJA
#define LED_VERDE       LATDbits.LATD1 = 1;  //LED COLOR VERDE

#define LED_ROJO_APAGADO        LATCbits.LATC3 = 0;   //LED COLOR APAGADO
#define LED_NARANJA_APAGADO     LATDbits.LATD0 = 0;   //LED NARANJA APAGADO
#define LED_VERDE_APAGADO       LATDbits.LATD1 = 0;   //LED COLOR APAGADO

#define TOGGLE_LED_ROJO     LATCbits.LATC3 ^= 1;
#define TOGGLE_LED_VERDE    LATDbits.LATD1 ^= 1;

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* COLORES_TORRETA_H */

