/* 
 * File:   RTC_DS3232.h
 * Author: AlexisRamirez
 *
 * Created on February 2, 2022, 2:05 PM
 */

#ifndef RTC_DS3232_H
#define	RTC_DS3232_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <xc.h>
#include "i2c.h"

#define RTC_ADDRESS     0x68    //0b1101000
#define INT_SQW         PORTCbits.RC2
    
//Direccion donde se encuentran guardados los valores en el RTC    
#define RTC_YEAR        0x06
#define RTC_MONTH       0x05
#define RTC_DATE        0x04
#define RTC_DAY         0x03
#define RTC_HOUR        0x02
#define RTC_MINUTES     0x01
#define RTC_SECONDS     0x00

//Direccion donde se guarda el tiempo de las alarmas
#define RTC_SECONDS_ALARMA1     0x07
#define RTC_MINUTES_ALARMA1     0x08
#define RTC_HOUR_ALARMA1        0x09
#define RTC_DATE_DAY_ALARMA1    0x0A
#define RTC_MINUTES_ALARMA2     0x0B
#define RTC_HOUR_ALARMA2        0x0C
#define RTC_DATE_DAY_ALARMA2    0x0D

#define RTC_CONTROL_REGISTER    0x0E

//Valores de fallo RTC
#define FALLO_ESCRITURA_ANIO        0x01  
#define FALLO_ESCRITURA_MES         0x02 
#define FALLO_ESCRITURA_DIA_MES     0x03
#define FALLO_ESCRITURA_DIA_SEMANA  0x04 
#define FALLO_ESCRITURA_HORA        0x05 
#define FALLO_ESCRITURA_MINUTOS     0x06 
#define FALLO_ESCRITURA_SEGUNDOS    0x07 
   
struct rtc{
    uint8_t anio;
    uint8_t mes;
    uint8_t dia_del_mes;
    uint8_t dia_semana;
    uint8_t hora;
    uint8_t minutos;
    uint8_t segundos;
    uint8_t fallo_rtc;
    bool hourChange : 1;
}RTC;

void config_RTC(uint8_t year, uint8_t month, uint8_t date, uint8_t hour, uint8_t minutes);

void config_RTC_all(uint8_t year, uint8_t month, uint8_t date, uint8_t day_week, uint8_t hour, uint8_t minutes, uint8_t seconds);

void crear_alarma1(uint8_t hora, uint8_t minutos);
void activar_alarma1(void);
void activar_alarma2(void);
void desactivar_alarma1(void);
void desactivar_alarma2(void);
void check_alarma1(void);

uint8_t read_Control_Register(void);
//Entrega la hora en minutos
uint16_t convertTime_minutes(void);

void writeYear_RTC(uint8_t year);
void writeMonth_RTC(uint8_t month);
void writeDate_RTC(uint8_t date);
void writeDay_RTC(uint8_t day_week);
void writeHour_RTC(uint8_t hour);
void writeMinutes_RTC(uint8_t minutes);
void writeSeconds_RTC(uint8_t seconds);

uint8_t getYear_RTC(void);
uint8_t getMonth_RTC(void);
uint8_t getDate_RTC(void);
uint8_t getDay_RTC(void);
uint8_t getHour_RTC(void);
uint8_t getMinutes_RTC(void);
uint8_t getSeconds_RTC(void);

#ifdef	__cplusplus
}
#endif

#endif	/* RTC_DS3232_H */

