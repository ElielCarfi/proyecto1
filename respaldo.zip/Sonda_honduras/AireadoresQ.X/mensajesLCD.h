#include <xc.h>  
void LCDLCD(void);
void LCDLCD1(void);
void LCDLCD2(void);

