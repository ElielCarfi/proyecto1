/* 
 * File:   Float_IEEE754.h
 * Author: AlexisRamirez
 *
 * Created on February 9, 2022, 10:23 AM
 */

#ifndef FLOAT_IEEE754_H
#define	FLOAT_IEEE754_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
    
uint32_t float_a_IEEE754(float dato_flotante);
float IEEE754_A_Float(uint8_t *data8);

#ifdef	__cplusplus
}
#endif

#endif	/* FLOAT_IEEE754_H */

