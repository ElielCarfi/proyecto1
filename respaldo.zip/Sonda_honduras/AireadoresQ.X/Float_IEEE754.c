
#include "Float_IEEE754.h"

uint32_t float_a_IEEE754(float dato_flotante){
   float entero = 0, log_2 = 0, log_de_entero = 0, flotante_absoluto = 0, resta = 0, flotante_fraccion = 0, resto_fraccion = 0, respaldo_fraccion = 0;
   const float log_de_2 = 0.3010299956639812;
   int32_t log_2_redondeado = 0, exponente = 0, fracion = 0, IEEE_754;
   uint8_t float_bytes[4] = {0}, intentos = 0;
   
   if (dato_flotante == 0.0) {
      IEEE_754 = 0x00000000;
      return IEEE_754;
   }
   flotante_absoluto = fabs(dato_flotante);        
   entero = flotante_absoluto;               
   log_de_entero = log10(entero);                  
   log_2 = log_de_entero / log_de_2;                                       
   if(flotante_absoluto >= 2.0) {
      log_2_redondeado = (log_2) / 1.0;
   } else {
      log_2_redondeado = (log_2 - 1) / 1.0;
   } 
   entero = pow(2.0, log_2_redondeado);                       
   flotante_fraccion = flotante_absoluto / entero;
   respaldo_fraccion = flotante_fraccion;           
   exponente = log_2_redondeado + 127;
   resta = 2.0;

   for (intentos = 0; intentos < 23; intentos++) {
      resta = resta / 2.0;                                           
      resto_fraccion = respaldo_fraccion - resta;                    
      if (resto_fraccion >= 0.0) {                                    
         fracion = fracion + (0X01000000 >> intentos);         
         respaldo_fraccion = resto_fraccion;                         
      }
   }
   exponente = exponente << 23;
   fracion =  fracion >> 1;
   exponente = exponente ^ 0X800000;
   IEEE_754 = exponente ^ fracion;
   if(dato_flotante < 0) IEEE_754 = IEEE_754 | 0X80000000;
   float_bytes[0] = IEEE_754 >> 24;
   float_bytes[1] = IEEE_754 >> 16;
   float_bytes[2] = IEEE_754 >> 8;
   float_bytes[3] = IEEE_754;

   return IEEE_754;
}


float IEEE754_A_Float(uint8_t *data8){
//Funcion encargada de recibir un numero de 4 bytes en formato IEE754 para convertirlo a flotante
    float dato = 0, entero_f = 0, fracion_f = 0;
    uint32_t x = 0, entero = 0, fracion = 0;

    x = data8[0];                   
    x = (x << 8) + data8[1];                                                                                   
    x = (x << 8) + data8[2];
    x = (x << 8) + data8[3];
    fracion = x & 0x007FFFFF;
    entero = x & 0x7F800000;
    entero = entero >> 23;
    entero_f = entero / 1.0;                                          
    entero_f = pow(2, (entero_f - 127));
    fracion_f = fracion / 1.0;                         
    fracion_f = ((fracion_f / 8388608) + 1);
    dato = entero_f * fracion_f;

    if ((x >> 31) == 0) {
        dato = dato * (1.0);
    }
    else {
        dato = dato * (-1.0);
    }
    return dato;
}
