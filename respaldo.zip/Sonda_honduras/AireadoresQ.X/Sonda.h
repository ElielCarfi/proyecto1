/* 
 * File:   Sonda.h
 * Author: acuic
 *
 * Created on 26 de abril de 2022, 02:25 PM
 */

#ifndef SONDA_H
#define	SONDA_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "gswteos_10.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>         
#include <stdint.h>
#include <math.h>
#include <xc.h>
#include "Macros_Perifericos.h"
#include "Float_IEEE754.h"
#include "mcc_generated_files/memory.h"
#include "RTC_DS3232.h"
#include "THVD1429_RS485.h"
#include "Xbee.h"
#include "funciones.h" // Cambiar en un archivo aparte
#include "Sonda_funciones_EEPROM.h"
#include "funcionesCompartidasAlimentadorSonda.h"

#define ALIMENTADOR_CON_SONDA
#define SENSOR_NUEVA_VERSION

#define _XTAL_FREQ  16000000  

// <editor-fold defaultstate="collapsed" desc="Macros Acciones Sonda">
#define ID_GLOBAL_SONDA '1'
#define ID_SONDA_ASCII1 ID_ALIMENTADOR_ASCII1
#define ID_SONDA_ASCII2 ID_ALIMENTADOR_ASCII2
#define ID_SONDA_ASCII3 ID_ALIMENTADOR_ASCII3
    
#define SOLICITUD_MEDICIONES_ASCII1  '0'
#define SOLICITUD_MEDICIONES_ASCII2  'C'
#define ESTABLECER_SALINIDAD_ASCII1 '0'
#define ESTABLECER_SALINIDAD_ASCII2 '5'
#define RESET_SONDA_ASCII1  '1'
#define RESET_SONDA_ASCII2  '0'
#define SOLICITAR_LECTURA_SENSOR_DEBUG_ASCII1   'C'
#define SOLICITAR_LECTURA_SENSOR_DEBUG_ASCII2   '0'
#define ESPECIFICA_SENSORES_SONDA_ASCII1    'C'
#define ESPECIFICA_SENSORES_SONDA_ASCII2    '2'
#define ENTRAR_MODO_CONFIGURACION_ASCII1    'B'
#define ENTRAR_MODO_CONFIGURACION_ASCII2    '1'
#define SALIR_MODO_CONFIGURACION_ASCII1 'B'
#define SALIR_MODO_CONFIGURACION_ASCII2 '2'
#define ESTABLECER_SONDA_ESTANQUE_1_ASCII1  'B'
#define ESTABLECER_SONDA_ESTANQUE_1_ASCII2  '3'
#define ESTABLECER_SONDA_DOBLE_ASCII1   'B'
#define ESTABLECER_SONDA_DOBLE_ASCII2   '4'
#define PEDIR_MEDICIONES_DEBUG_ASCII1   'C'
#define PEDIR_MEDICIONES_DEBUG_ASCII2   '3'
#define SOLICITAR_MEDICIONES_SENSOR_ASCII1  'C'
#define SOLICITAR_MEDICIONES_SENSOR_ASCII2  '4'
#define DESHABILITAR_LECTURA_ASCII1 '1'
#define DESHABILITAR_LECTURA_ASCII2 '1'
#define ACTIVAR_LECTURA_ASCII1  '1'
#define ACTIVAR_LECTURA_ASCII2  '2'
#define PUNTO_BAJO_ALTO_CALIBRACION_SONDA_ASCII1    'B'
#define PUNTO_BAJO_ALTO_CALIBRACION_SONDA_ASCII2    '5'
#define CONFIG_FRECUENCIA_TOMA_MEDICIONES_ASCII1    'C'
#define CONFIG_FRECUENCIA_TOMA_MEDICIONES_ASCII2    '8'
#define PEDIR_STATUS_LECTURA_ASCII1
#define PEDIR_STATUS_LECTURA_ASCII2
#define EXTRAER_DATOS_CALIBRACION_TEMPERATURA_ASCII1
#define EXTRAER_DATOS_CALIBRACION_TEMPERATURA_ASCII2
#define ENVIAR_DATOS_CALIBRACION_TEMPERATURA_ASCII1
#define ENVIAR_DATOS_CALIBRACION_TEMPERATURA_ASCII2
#define RESPUESTA_INFO_CONFIGURACION_ASCII1     '0'
#define RESPUESTA_INFO_CONFIGURACION_ASCII2     '1'

//Envios Sonda a Modulo de control
#define MEDICIONES_ASCII1   '0'
#define MEDICIONES_ASCII2   'C'
#define VINCULACION_SONDA_ASCII1    'B'
#define VINCULACION_SONDA_ASCII2    '6'
    

// </editor-fold>

// <editor-fold defaultstate="collapsed" desc="Localidades EEPROM">
#define L_ID_ESTANQUE   0  //80
#define L_ID2_ESTANQUE  4  //82
#define L_CONFIGURACION_ESTANQUE_1  2  //84
#define L_CONFIGURACION_ESTANQUE_2  6  //86
//#define L_MAC_MONITOR   8
#define L_MAC_DISPOSITIVO_CONFIGURADOR  16  //88
#define L_VALOR_CALIBRACION_TEMPERATURA1 24
#define L_VALOR_CALIBRACION_TEMPERATURA1_OFFSET 28
#define L_VALOR_CALIBRACION_TEMPERATURA2 32
#define L_VALOR_CALIBRACION_TEMPERATURA2_OFFSET 36
#define L_VALOR_LECTURA_TEMPERATURA 120
#define L_VALOR_LECTURA_OXIGENO_DISUELTO 124
#define L_VALOR_LECTURA_SATURACION_OXIGENO 128
#define L_VALOR_LECTURA_SALINIDAD   132
#define L_VALOR_LECTURA_CONDUCTIVIDAD   136
#define L_VALOR_LECTURA_PH  140
#define L_VALOR_LECTURA_ORP 144
#define L_VALOR_LECTURA_ION_DE_AMONIO  148
#define L_VALOR_LECTURA_AMONIACO    152
#define L_VALOR_LECTURA_ION_DE_POTASIO  156
// </editor-fold>

//Definiciones de configuracion para cada sonda
#define    ID1H               0x00                                              //identificador superior de sonda para estanque 1           
#define    ID1L               0x06                                              //identificador inferior de sonda para estanque 1
#define    ID2H               0x00                                              //identificador superior de sonda para estanque 2          
#define    ID2L               0x00                                              //identificador inferior de sonda para estanque 2                    
#define    CONFIG1H_sensores  0x00
#define    CONFIG1L_sensores  0x07                                              //configuracion de sensores que porta la sonda para estanque 1 
#define    CONFIG2H_sensores  0x00
#define    CONFIG2L_sensores  0x00                                              //configuracion de sensores que porta la sonda para estanque 2
             
//Pines de pic usadas como entradas digitales y analogicas
//#define FUNC1              PORTEbits.RE0
//#define FUNC2              PORTEbits.RE1
//#define FUNC3              PORTEbits.RE2
//#define RESET_XBEE         PIN_B5
//#define DTR                PIN_B4
//#define RTS                PIN_B1
//#define ENABLE_2           PIN_C2
#define V_ALIMENTACION     0x03
////#define PT_1000            0X04

#define SEN_T_ACTIVO       0x0001                                                               //Lectura de temperatura activa
#define SEN_O_ACTIVO       0x0002                                                               //Lectura de oxigeno disuelto activa
#define SEN_SATO_ACTIVO    0X0004                                                               //Lectura de saturacion de oxigeno activa
#define SEN_T_O_SATO_DESUN_ACTIVO            (SEN_T_ACTIVO | SEN_O_ACTIVO | SEN_SATO_ACTIVO)    //Lecturas de sensor desun (temperatura, oxigeno disuelto y saturacion de oxigeno)
#define SEN_S_ACTIVO       0x0008                                                               //Lectura de salinidad activa
#define SEN_C_ACTIVO       0x0010                                                               //Lectura de conductividad activa
#define SEN_S_C_DESUN_ACTIVO                 (SEN_S_ACTIVO | SEN_C_ACTIVO)                      //Lecturas de sensor desun (salinidad y conductividad)
#define SEN_PH_ACTIVO      0x0020                                                               //Lectura de ph activa
#define SEN_ORP_ACTIVO     0x0040                                                               //Lectura de orp activa
#define SEN_PH_ORP_DESUN_ACTIVO              (SEN_PH_ACTIVO | SEN_ORP_ACTIVO)                   //Lecturas de sensor desun (ph y orp)
#define SEN_NH4_ACTIVO     0x0080                                                               //Lectura de ion de amonio activa
#define SEN_NH3N_ACTIVO    0x0100                                                               //Lactura de amoniaco activa
#define SEN_K_ACTIVO       0x0200                                                               //Lectura de ion de potasio activa 
#define SEN_PH_ORP_NH4_NH3N_K_DESUN_ACTIVO   (SEN_PH_ACTIVO | SEN_ORP_ACTIVO | SEN_NH4_ACTIVO | SEN_NH3N_ACTIVO | SEN_K_ACTIVO)  //Lecturas de sensor desun (ph, orp, ion de amonio, amoniaco, ion de potasio)

#define SENSOR_MULTI       0x07
#define MULTI_ORP          0x11
#define MULTI_PH           0x12
#define MULTI_NH3_N        0x13
#define MULTI_K            0x14
#define MULTI_NH4          0x15
#define MULTI_TEMP         0x16
#define SENSOR_PH_ORP      0x17
#define MEDIR_PH           0x18
#define MEDIR_ORP          0x19
//Definiciones de comandos de configuracion
#define ENVIAR_LECTURA     0x0100                                               // ?ims0010DE< ?ims0020DF<       Enviar lecturas de estanque asociado a id 001.
#define T_E_LECTURAS       0x0200                                               // >lec0010C8< >lec0020C9<       Tomar y enviar nuevas lecturas, de estanque con ID 001.
#define CONFIG_SENSORES    0x0300                                               // >byt0010070F3< >byt0020070F4< Estanque con ID 001, habilita datos de Saturacion de oxigeno, Oxigeno disuelto, temperatura.
#define VIM_CON_E          0x0400                                               // >vin00100741B54478ACK<        Comando de sonda-monitor, vincular monitor con estanque, ID 001, configuracion de sensores 007, mac de sonda 45b54478.
#define CONFIG_SONDA       0x0500                                               // >cfg41B4988510B<              Entrar en modo configuracion, MAC de dispositivo configurador.
#define VIS_CON_M          0x0600                                               // >mon41D5D90D126<              Vincular sonda con monitor, mac de monitor 45b54444.
#define SETEAR_HORA        0x0700                                               // >hra21020505142745ACK<        Configura (a�o, mes, dia de mes, dia de semana, hora, min, segundos) todos los datos con 2 digitos, siendo en total 14 caracteres.
#define CAMBIAR_ID_UNICO   0x0800                                               // >dob0010C9<
#define CAMBIAR_ID_DOBLE   0x0900                                               // >dob0010020D4< 
#define SETEAR_PARAMETRO   0x0A00                                               // >set001008420C0000ACK<        Establece a estanque con ID 001 el parametro de salinidad a 35 ppt.                                                            
#define ENVIAR_LECTURA_F   0x0B00                                               // ?imf0010D1< ?imf0020D2<       Enviar lecturas de estanque asociado a id 001 con datos en flotante incluidos.

#define CAMBIAR_ID1        0x0C00                                               //                               Cambiar ID a estanque 1
#define CAMBIAR_ID2        0x0D00                                               //                               Cambiar ID a estanque 2
#define CONFIG_SENSORES1   0x0E00                                               //                               Cambiar configuracion de sensores en estanque 1. 
#define CONFIG_SENSORES2   0x0F00                                               //                               Cambiar configuracion de sensores en estanque 2.
#define TOMAR_LECTURAS     0x1000                                               // >tol0D9<                      Tomar nuevas lecturas.
#define TOMAR_LECTURAS1    0x1100                                               //                               Tomar lecturas de estanque 1
#define TOMAR_LECTURAS2    0x1200                                               //                               Tomar lecturas de estanque 2
#define ESPERAR_PETICION   0x1300                                               //                               Esperar peticion de lacturas
#define ENVIAR_LECTURAS    0x1400                                               //                               Enviar lecturas de estanque 1
#define DORMIR_SONDA       0x1500                                               //                               Comando para dormir sonda
#define PROG_T_L           0x1600                                               //                               Comando para dormir sonda
#define VACIAR_ESTANQUE    0x1700                                               // >vac0010CE<                   Comando para vaciar estanque 
#define LLENAR_ESTANQUE    0x1800                                               // >aga001ACK<                   Comando para llenar estanque 

//Definiciones de comandos de calibraciones del sistema, los comandos comienzan con >cal
#define CALIBRAR_TEMP_L   0x0011                                                // >cal001001L41C80000125<  Calibra estanque asociado a id 001, temperatura, setpoint bajo de 24.0 grados.
#define CALIBRAR_TEMP_H   0x0012                                                // >cal001001H41C80000121<  Calibra estanque asociado a id 001, temperatura, setpoint alto de 24.0 grados.
#define CALIBRAR_O2_L     0x0041                                                // >cal001004L42C60000ACK<    Calibra estanque asociado a id 001, saturacion, setpoint bajo de 99.0.                                                        
#define CALIBRAR_O2_H     0x0042                                                // >cal001004H42C60000ACK<    Calibra estanque asociado a id 001, saturacion, setpoint alto de 99.0.
#define CALIBRAR_SAL_L    0x0081                                                // >cal001008L4130000041C8000014C<  Calibra estanque asociado a id 001, salinidad, setpoint bajo de 11ppt a 25�C.                                                        
#define CALIBRAR_SAL_H    0x0082                                                // >cal001008H420C000041C80000159<  Calibra estanque asociado a id 001, salinidad, setpoint alto de 35ppt a 25�C.  
#define CALIBRAR_CON_L    0x0101                                                // >cal001010L4130000041C8000014C<
#define CALIBRAR_CON_H    0x0102                                                // >cal001010H4130000041C8000014C<
#define CALIBRAR_PH_L     0x0201                                                // >cal001010L420C0000121<  Calibra estanque asociado a id 001, PH, setpoint bajo de 20.50.
#define CALIBRAR_PH_H     0x0202                                                // >cal001010H420C0000121<  Calibra estanque asociado a id 001, PH, setpoint alto de 59.99.
#define CALIBRAR_ORP_L    0x0401                                                // >cal001020L420C0000121<  Calibra estanque asociado a id 001, ORP, setpoint bajo de 20.50.                                                        
#define CALIBRAR_ORP_H    0x0402                                                // >cal001020H420C0000121<  Calibra estanque asociado a id 001, ORP, setpoint alto de 59.99.
#define CALIBRAR_AMONIO_L 0x0801                                                // >cal001040L420C0000121<  Calibra estanque asociado a id 001, amonio, setpoint bajo de 20.50.                                                        
#define CALIBRAR_AMONIO_H 0x0802                                                // >cal001040H420C0000121<  Calibra estanque asociado a id 001, amonio, setpoint alto de 59.99.

//Direccion mac predeterminada de monitor y configurador
#define DAL_INIT_00 '4'
#define DAL_INIT_01 '1'
#define DAL_INIT_02 'D'
#define DAL_INIT_03 '5'
#define DAL_INIT_04 'D'
#define DAL_INIT_05 '9'
#define DAL_INIT_06 'C'
#define DAL_INIT_07 '0'
#define DAL_INIT_10 '4'
#define DAL_INIT_11 '1'
#define DAL_INIT_12 'D'
#define DAL_INIT_13 '5'
#define DAL_INIT_14 'D'
#define DAL_INIT_15 '9'
#define DAL_INIT_16 'C'
#define DAL_INIT_17 '0'

//const char DAL_INIT[2][8] =   {{'4','1','D','5','D','9','C','0'}, 
//                               {'4','1','B','4','9','8','8','5'}};       
    
//// ***** MACs de monitor y configurador
//char DAL[2][8] = {{'4','1','D','5','D','9','C','0'}, 
//                  {'4','1','B','4','9','8','8','5'}};

// ***** Variables para recepción de mensajes por Xbee
//char buffer[100] = {0};
//uint8_t ptrBuffer = 0;
//uint8_t contador_timeout = 0;
//uint8_t  contador_seg = 0, mensajeNuevo = 0;
//uint8_t ptrBuffer_respaldo = 0;

// ***** Variables para envíos de mensajes por Xbee
//char bandeja_salida[107] = {0}; // D�"NDE SE GUARDA EL MENSAJE A ENVIAR

uint8_t BOTON_FUNC1 = 1, BOTON_FUNC2 = 1, BOTON_FUNC3 = 1, AE_ESTANQUES = 1, E_ESTANQUES = 0;
uint8_t a = 0, med_falsas = 0, c_serial1 = 0, i = 0, j = 0, num = 0, num1 = 0, num2 = 0, 
                ID_superior = 0, ID_inferior = 0, RECEPTOR = 0;                
char    carga_comando[14];
uint16_t valor_adc = 0, temp1 = 0, CRC = 0, datos[20], COMANDO = 0, config1 = 0, config2 = 0, ID_EN_COMANDO = 0, estado_estanques = 0;
uint32_t temp0 = 0;
float mili_Siemens = 0, temperatura = 0, presion = 10.1325;
//float potasio1 = 0, amonio1 = 0, ion_amonio1 = 0, orp1 = 0, ph1 = 0, conductividad1 = 0, sal1 = 0, saturacion1 = 0, O2_mgl_1 = 0,
//      temperatura1 = 0;
float potasio2 = 0, amonio2 = 0, ion_amonio2 = 0, orp2 = 0, ph2 = 0,  conductividad2 = 0, sal2 = 0, saturacion2 = 0, O2_mgl_2 = 0, 
      temperatura2 = 0, voltaje = 0, DATO_SETPOINT = 0, DATO_SETPOINT2 = 0;

struct medicionesEstanques{
    uint16_t id;
    float potasio;
    float amoniaco;
    float amonio;
    float ion_amonio;
    float orp;
    float ph;//
    float conductividad;//
    float salinidad;//
    float saturacion;//
    float o2;//
    float temperatura;//
}ESTANQUE1, ESTANQUE2;
    
struct horaMediciones{
    uint8_t mes;
    uint8_t dia_del_mes;
    uint8_t hora;
    uint8_t minutos;
    uint8_t segundos;
}ESTANQUE1_HORA, ESTANQUE2_HORA;

struct flagsSonda{
    bool activarSonda:1;
    bool desactivarSonda:1;
    bool modoConfiguration:1;
    bool configFrecuenciaMediciones:1;
    bool configPuntoBajoAlto:1;
}FLAGS_SONDA;

struct sonda{
    bool sensorTemperatura:1;
    bool sensorO2:1;
    bool sensorSaturacion:1;
    bool sensorSalinidad:1;
    bool sensorConductividad:1;
    bool sensorPh:1;
    bool sensorOrp:1;
    bool sensorAmonio:1;
    bool sensorAmoniaco:1;
    bool sensorPotasio:1;
    uint8_t versionHardwareEntero;
    uint8_t versionHardwareDecimal;
    uint8_t versionSoftwareEntero;
    uint8_t versionSoftwareDecimal;
    uint8_t k_Saturacion[4];
    uint8_t b_Saturacion[4];
    bool tomandoLecturas : 1;
}Sonda;

uint16_t intervaloMediciones = 0;   //Intervalo para tomar las mediciones
uint8_t diaHoySonda = 0;
uint16_t timeNextMedicion = 0;  //Cuenta el tiempo transcurrido para tomar las mediciones
uint16_t timeBlinkLedTomandoLecturas = 0;

void init_sonda(void);
void main_sonda(void);
void initStructEstanque1(void);
void resetMedicionesEstanque1(void);
void initStructEstanque2(void);
void resetMedicionesEstanque2(void);
void accionesSonda(uint8_t identificadorAccion1, uint8_t identificadorAccion2);
void createMensajeMediciones(void);
void sendMediciones(void);
void createInfoConfiguration(void);
void sendInfoConfiguration(void);
void saveHoraMediciones(struct horaMediciones *estanque);
void activarSolicitudMediciones(void);
//Buenas tardes, yo nomas voy pasando 
void guardar_id_estanques(uint16_t comandos, char *datos);
uint16_t obtener_id_estanque(uint8_t estanque);
//extern void read_string_i2c(uint8_t device_addres, uint8_t address, uint8_t *data4, uint8_t num_data);
//void write_string_i2c(uint8_t device_addres, uint8_t address, uint8_t *data5, uint8_t num_data);
//void guardar_mac_dispositivo_configurador(void);
//void obtener_mac(void);
void guardar_config_sensores(uint16_t comandos, uint16_t id_estanque, char *datos);
uint16_t obtener_config_sensores(uint16_t id_estanque);
//void guardar_lecturas(uint16_t id_estanque, float ion_potasio, float amoniaco, float ion_amonio, float orp, float ph, float conductividad, float salinidad, float saturacion, float oxigeno, float temperatura);
//////void obtener_lecturas(uint16_t id_estanque); //Descomentar 3 veces luego
void getLecturasSeteadasEEPROM(uint16_t id_estanque);
void guardar_parametro(uint16_t comandos, uint16_t id_estanque, char *datos);
float obtener_parametro(uint16_t id_estanque, uint16_t parametro);
void guardar_referencias(uint16_t comandos, uint16_t id_estanque, float referencia, float setpoint);
uint8_t* obtener_referencias(uint16_t comandos, uint16_t id_estanque);
uint16_t obtener_estado_estanques(void);
void setear_estado_estanques(uint16_t comandos, uint16_t id_estanque);
void calibrar_temperatura(uint16_t comandos, float setpoint_bajo, float setpoint_alto, uint8_t id_sensor, uint16_t config);
float compensar_temperatura(float temperatura, uint8_t id_sensor);
float oxigeno(float porcentaje, float temp, float salinidad);                                         
void desun_start_measurements(uint16_t tipo_sensor, uint8_t id_sensor);
void desun_cambiar_direccion(uint8_t id_actual, uint8_t id_nueva);
float desun_temperatura(uint8_t id_sensor);
float desun_saturacion(uint8_t id_sensor);
void desun_TemperaturaSaturacion(uint8_t id_sensor);
float desun_salinidad(uint8_t id_sensor, float presion);
void desun_calibrar_o2(uint16_t comandos, float setpoint_bajo, float setpoint_alto, uint8_t id_sensor);
void desun_calibrar_salinidad(uint16_t comandos, float setpoint_bajo, float setpoint_alto, float presion, uint8_t id_sensor);
void getKBSaturacion(uint8_t id_sensor);
void getSoftwareHardwareVersion(uint8_t id_sensor);
void configurarSensoresConectados(uint8_t idSensor);
void readSensoresConectadosEstanque1(void);
//uint16_t decodificar_comandos(char *data7);
//uint8_t Construir_string(char *data6, uint8_t dia_mes, uint8_t mes, uint8_t anio, uint8_t hora, uint8_t minuto, uint16_t id_estanque, float ion_potasio, float amoniaco, float ion_amonio, float orp, float ph, float conductividad, float salinidad, float saturacion, float oxigeno, float temperatura);
//uint8_t Construir_string_f(char *data6, uint16_t id_estanque, float ion_potasio, float amoniaco, float ion_amonio, float orp, float ph, float conductividad, float salinidad, float saturacion, float oxigeno, float temperatura);
uint16_t Config(uint16_t comandos, uint16_t id_estanque, char *data9);
//////float obtener_temperatura_PT_1000(void);
//extern uint8_t obtener_mac_propia(char *data);
///////////No encontre funcion
////////void Config_string(void); 


void saveEEPROM_ID1(uint16_t id);
void saveEEPROM_ID2(uint16_t id);
void saveEEPROM_configuration_estanque1(uint16_t configuracion);
void saveEEPROM_configuration_estanque2(uint16_t configuracion);
uint16_t readEEPROM_ID1_estanque(void);
uint16_t readEEPROM_ID2_estanque(void);
uint16_t readEEPROM_configuracion_estanque1(void);
uint16_t readEEPROM_configuracion_estanque2(void);
void sleep_sonda(void);
void calibracion(void);
void tomar_lecturas(void);  //Retorna la ultima hora que se realizo la medicion en minutos
uint16_t calculoNextMedicion(void);
//void esperar_peticion(void);
//void enviar_lecturas(void);
void captura_datos_RX_sensor(void);
void resetSonda(void);
void configTimeMeasurements(void);
void configHighLowPointCalibration(void);
void controlTomarLecturas(void); //Tiempo en Segundos
void controlLedTomandoLecturas(void);
void controlBlinkLEDInterrupcion(void);

uint16_t decodificarByteParametros(uint8_t *ptrBufferRX);
uint16_t revValorCalibrar(uint16_t byteParametros, uint8_t *ptrBufferRX);
bool revIDSonda(uint8_t *ptrBufferRX);
bool revisarConfigSondaEnBlanco(uint16_t localidadEEPROM, uint8_t cantidadLocalidadesEEPROM);
// ***** FUNCIONES TX/RX DE MENSAJE ****** \\
//uint8_t direccionar_xbee(unsigned uint16_t id);
//void calcularACK_RX();
//void calcularACK_TX();
//uint8_t compararACK();
//uint8_t enviarACK(unsigned uint8_t destino);
//uint8_t enviarMensaje(unsigned uint8_t destino);
//void respaldar_ptrBuffer();
//void limpiar_buffer_XBEE();
//void init_xbee();

#ifdef	__cplusplus
}
#endif

#endif	/* SONDA_H */

