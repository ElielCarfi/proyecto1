#include "funciones_secundarias.h"
#include "funciones.h"

void saveEEPROM_2Bytes(uint16_t localidadEEPROM, uint8_t numero_rutina, uint8_t posicionDato1HB, uint8_t *ptrBufferRX){
    uint16_t posicionEEPROM = localidadEEPROM + (0x0010 * numero_rutina);
    uint8_t datoPosicion = (posicionDato1HB + (8 * numero_rutina));
    
    DATAEE_WriteByte(posicionEEPROM, ptrBufferRX[datoPosicion]);
    DATAEE_WriteByte((posicionEEPROM + 1), ptrBufferRX[datoPosicion + 1]);
}

uint16_t compesancionTiempoNuevaRutina(uint16_t horaNextAlimentacion, uint16_t horaNow){
    if(RUTINA.numeroRutinas == 1){
        if((flags.nueva_rutina_programada) && (horaNextAlimentacion != 3000) && (RUTINA.inicio_horario < horaNow)){
            if((horaNow + RUTINA.intervalo_minutos) <= RUTINA.final_horario){
                horaNextAlimentacion = horaNow + RUTINA.intervalo_minutos;
            }
        }
        else{
            flags.nueva_rutina_programada = false;
        }
    }
    
    return horaNextAlimentacion;
}