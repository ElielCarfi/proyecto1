#include "funcionesCompartidasAlimentadorSonda.h"

void acomodarBytesIEEE(uint8_t *ptrValorIEEE, uint8_t *ptrBufferRX, uint8_t posicionIEEE){
    for(uint8_t i = 0; i < 3; i++){
        ptrValorIEEE[i] = ptrBufferRX[posicionIEEE + i];
    }
}