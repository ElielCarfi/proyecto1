/* 
 * File:   funciones.h
 * Author: AlexisRamirez
 *
 * Created on February 7, 2022, 10:03 AM
 */

#ifndef FUNCIONES_H
#define	FUNCIONES_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "mcc_generated_files/mcc.h"
#include "Xbee.h"
#include "RTC_DS3232.h"
#include "colores_Torreta.h"
#include "Float_IEEE754.h"
#include "identificador_fallos.h"
#include "funciones_secundarias.h"
    #include "uart3.h"

    
#define DEBUG     //Descomentar en caso de estar revisando fallos

#define SWITCH_1        PORTEbits.RE0
#define SWITCH_2        PORTEbits.RE1
#define SWITCH_3        PORTEbits.RE2
    
#define ENABLE_DRIVER_MOTOR     LATBbits.LATB3 = 1;
#define DISABLE_DRIVER_MOTOR    LATBbits.LATB3 = 0;

#define ENABLE_EN1     LATAbits.LATA5 = 0;
#define DISABLE_EN1    LATAbits.LATA5 = 1;

#define VERSION_FIRMWARE_1  01
#define VERSION_FIRMWARE_2  0x08
#define VERSION_FIRMWARE_3  01
    
#define INVERVALO_PORCENTAJE_BATERIA 28.25 //28.25 100% es 69% 2825.55
#define INTERVALO_PORCENTAJE_MOTOR1 .5   //57.08 100% .57
#define INTERVALO_PORCENTAJE_MOTOR2 21.2 //1427.04 100% 14.27
#define INTERVALO_PORCENTAJE_PANEL  40.95 //40.95 por 4095/100
#define INTERVALO_PORCENTAJE_RSSI   40.95
#define ALIMENTO_GRAMOS 40      //Gramos por segundo

// <editor-fold defaultstate="collapsed" desc="Localidades Memoria EEPROM, guardado de datos RUTINA simple">    
#define L_DIA_ALIMENTACION      0x0016
#define L_HORA_INICIO           0x0017
#define L_HORA_FIN              0x0021
#define L_INTERVALO_MIN         0x0025
#define L_DURACION_SEGUNDOS     0x0029
#define L_VELOCIDAD_MINIMA      0x0033
#define L_VELOCIDAD_MAXIMA      0x0037
#define DISTRIBUCION_UNIFORME   0x0041
// </editor-fold> 

#define L_ID_ALIMENTADOR        0x0202
#define L_MAC_CRA       0x0210
#define L_MAC_MONITOR   0x0218
    
// <editor-fold defaultstate="collapsed" desc="Localidades Memoria EEPROM, guardado de datos RUTINA multiples">  
#define L_CANTIDAD_RUTINAS          0x020E
#define L_DIA_ALIMENTACION_M        0x020F    //Localidad dias de alimentacion multiples
#define L_HORA_INICIO_M             0x0220
#define L_HORA_FIN_M                0x0222
#define L_INTERVALO_MIN_M           0x0224
#define L_DURACION_SEGUNDOS_M       0x0226
#define L_VELOCIDAD_MINIMA_M        0x0228
#define L_VELOCIDAD_MAXIMA_M        0x0229
#define L_VELOCIDAD_DOSIFICADOR     0x022A
#define L_DISTRIBUCION_UNIFORME_M   0x022B
// </editor-fold> 
    
// <editor-fold defaultstate="collapsed" desc="MACROS IDENTIFICADORES">     
#define ID_ALIMENTADOR_GLOBAL    '3'

//ID Alimentador
#define ID_ALIMENTADOR_ASCII1    ID_Alimentador[0]
#define ID_ALIMENTADOR_ASCII2    ID_Alimentador[1]
#define ID_ALIMENTADOR_ASCII3    ID_Alimentador[2]

//Macros Monitor/CRA -> Alimentador
  
#define RUTINA_ASCCI1                   '0'
#define RUTINA_ASCCI2                   '8'
#define ALIMENTAR_AHORA_ASCII1          '0'    
#define ALIMENTAR_AHORA_ASCII2          'A'
#define RESET_ASCII1                    '0'
#define RESET_ASCII2                    '1'
#define DETENER_ALIMENTACION_ASCII1     '0'
#define DETENER_ALIMENTACION_ASCII2     'B'
#define SOLICITUD_STATUS_ASCII1         '2'
#define SOLICITUD_STATUS_ASCII2         '0'
#define SOLICITUD_STATUS_ASCII1_1MIN    '0'
#define SOLICITUD_STATUS_ASCII2_1MIN    '2'
#define VINCULAR_MONITOR_ASCII1         '0'
#define VINCULAR_MONITOR_ASCII2         'F'
#define VINCULAR_SISTEMA_ASCII1         'F'
#define VINCULAR_SISTEMA_ASCII2         '0'
#define HORA_ASCII1     '0'
#define HORA_ASCII2     '4'
#define OMITIR_ASCII1   '1'
#define OMITIR_ASCII2   '1'
#define SOLICITAR_INFO_RUTINA_ASCII1    '8'
#define SOLICITAR_INFO_RUTINA_ASCII2    '0'
#define RESPUESTA_INFO_RUTINA_ASCII1    '4'
#define RESPUESTA_INFO_RUTINA_ASCII2    '0' 
#define ELIMINAR_RUTINA_ASCII1      '8'
#define ELIMINAR_RUTINA_ASCII2      '8'
#define ASIGNAR_ID_ALIMENTADOR_ASCII1   'A'
#define ASIGNAR_ID_ALIMENTADOR_ASCII2   'A'
#define RUTINA_MULTIPLE_ASCII1      '8'
#define RUTINA_MULTIPLE_ASCII2      'B'
#define SOLICITAR_RUTINA_DIARIA_ASCII1  '2'
#define SOLICITAR_RUTINA_DIARIA_ASCII2  '4'
// </editor-fold> 

// <editor-fold defaultstate="collapsed" desc="Variable para probar memorias EEPROM **Solo pruebas">
#ifdef DEBUG 
//*****Pruebas
uint8_t data_eeprom = 0;
#endif
// </editor-fold>

//Banderas de estado    
volatile bool MAC_Monitor_flag = false;
volatile bool MAC_CRA_flag = false;
volatile bool rutina_programada = false; //Bandera de estado para saber si existe una rutina programa
volatile bool dia_hoy_alimentacion_flag = false; //Bandera para revisar si hoy se realizaran alimentaciones
volatile bool alimentar_ahora_flag = false; //Baandera de realizar una alimentacion ahora
volatile bool alimentando_flag = false;   //Bandera de estado para saber si esta realizando la alimentacion
volatile bool checkar_hora_flag = false;  
volatile bool mensaje_status_enviado_flag = false;

struct FLAGS{
    volatile bool deshabilitar_motores:1;
    volatile bool nueva_rutina_programada:1;
    volatile bool horario_corrido:1;
    volatile bool rutinaProgramada:1;
}flags;

//Banderas revision estados, envio y recepcion de mensajes
//volatile bool mensaje_enviado = false;
volatile bool mensaje_en_curso = false;
volatile bool mensaje_recibido = false;
volatile bool mensaje_completo = false;

static uint16_t tamanio_mensajeTX_completo = 0;

volatile uint8_t fallo = 0x00;  //Variable para identificar fallos, en tiempo de ejecucion del programa

volatile uint8_t ID_Alimentador[3] = {0};
volatile uint8_t MAC_InfoRutina[8] = {0};
volatile uint8_t MAC_Monitor[8] = {0};
volatile uint8_t MAC_CRA[8] = {0};
volatile uint8_t IEEE_retornar[4] = {0};

volatile uint8_t tiempo_transcurrido_segundos = 0;
uint16_t variable_pwm2 = 2700;
uint16_t hora_en_minutos = 0;
volatile uint8_t dia_next_alimentacion = 0;
volatile uint16_t hora_next_alimentacion_minutos = 3000;
uint16_t tiempo_next_alimentacion_minutos = 0;  //
uint16_t tiempo_segundos_alimentando = 0;       //Variable que controla con el timer 0 la cantidad de segundos alimentando
uint16_t tiempo_limite_alimentado  = 0;         //Variable que guarda la cantidad de segundos que tiene la rutina programada para alimentar
uint16_t cantidad_rociado_alimento = 0;
uint16_t rociado_alimento_realizado = 0;
uint8_t dia_hoy = 0;
uint16_t tiempo_transcurrido_parpadeo = 0;
uint16_t tiempo_transcurrido_medicion_ADC = 0;

struct ADC{
    volatile uint16_t MT1;
    volatile uint16_t MT2;
    volatile uint8_t Pbateria;
    volatile uint8_t Divbateria;
    volatile uint8_t Panel;
    volatile uint8_t RSSI;
}Porcentaje_ADC;

struct rutina{
    volatile uint8_t numeroRutinas;
    volatile uint8_t numeroRutinaActual;
    volatile uint8_t dias_alimentacion;
    volatile uint16_t inicio_horario;
    volatile uint16_t final_horario;
    volatile uint16_t intervalo_minutos;
    volatile uint16_t duracion_segundos;
    volatile uint8_t velocidad_minima;
    volatile uint8_t velocidad_maxima;
    volatile uint8_t velocidadDosificador;
    volatile bool distribucion_uniforme;
}RUTINA, RUTINA_ACTIVA;

struct alimentar_ahora{
    volatile uint16_t duracionSegundos;
    volatile uint8_t velocidadMinima;
    volatile uint8_t velocidadMaxima;
    volatile uint8_t velocidadDosificador;
    volatile bool distribucionUniforme:1;
}AlimentarAhora;

unsigned char mensaje_TX_completo[269] = {0};

volatile uint8_t tamanio_mensaje_data = 0;
unsigned char mensaje_TX_data[256] = {0};
unsigned char mensaje_TX[24] = {0}; //Mensaje para mandar respuesta para monitorear el estado de los equipos **Para pruebas
volatile uint8_t serial_cadena[260] = {0};   //Buffer de mensajes RX que se guardan para realizar las acciones

void init_alimentador(void);
void init_struct_rutina(void);
void init_struct_rutina_activa(uint8_t numero_rutina);
void actualizar_struct_rutina_con_rutina_activa(void);
//Funcion para reconocer si el ID global que corresponde al alimentador que se esta recibiendo el mensaje
bool rev_ID_alimetador_GB(uint8_t identificador);

//Funcion para reconocer si el ID del alimentador corresponde al alimentador que esta recibiendo el mensaje
bool rev_ID_alimentador(uint8_t indentificador_1, uint8_t indentificador_2, uint8_t indentificador_3);

void get_ADC_all(void);
void get_ADC_Panel(void);
void get_ADC_Bateria(void);
void get_ADC_Motores(void);
uint16_t MT1_ADC_porcentaje(void);
uint16_t MT2_ADC_porcentaje(void);
uint8_t PBateria_ADC_porcentaje(void);
uint8_t DivBateria_ADC_porcentaje(void);
uint8_t Panel_ADC_porcentaje(void);
uint8_t RSSI_ADC_porcentaje(void);
uint16_t getADC_promediado(uint8_t canal_analogico);

void reset_all(void);
void save_rutina(void);
void save_rutina_multiple(void);
void info_rutina(void);
void infoRutinaDiaria(void);
void send_status(void);
void do_rutina(void);
void alimentar_ahora(void);
void detener_alimentacion(void);
void omitir_alimentacion(void);
void borrar_rutinas(uint8_t numero_rutinas);

void enviar_mensaje_TX_InfoRutina(void);
void enviar_mensaje_TX_Status(void);
void enviar_mensaje_TX_Status_CRA(void);
void enviar_mensaje_TX_Status_Monitor(void);
void enviar_mensaje_TX_OK_CRA(void);
void enviar_mensaje_TX_OK(void);

void control_mediciones_bateria(uint16_t intervalo_tiempo);
void control_papardeo_LED(uint16_t intervalo_tiempo);
void control_luces_torreta(void);
void control_EN1(void);
//void control_aumento_tiempo_next_alimentacion(void);
uint16_t control_aumento_tiempo_next_alimentacion(uint16_t horaNextAlimentacion, uint16_t horaInicial, uint16_t horaFinal, uint16_t intervaloMinutos);
void control_dias_alimentacion(void);
void control_tiempo_alimentacion_interrupcion(void);
void control_tiempo_alimentacion(uint16_t duracion_segundos);
void control_motores_fase2(uint8_t velocidad_minima, uint8_t velocidad_maxima);
void control_motores_fase1(uint8_t velocidad_minima, uint16_t duracion_segundos, uint8_t velocidadDosificador);
void control_motores_fijo(uint8_t velocidad_maxima, uint16_t duracion_segundos, uint8_t velocidadDosificador);
void control_mensaje_respuesta_OK(uint8_t posicion_IEEE);
void mensaje_respuesta_OK(uint8_t posicion_IEEE);

void control_pwm1(uint16_t duty_cycle);
void control_pwm2(uint16_t duty_cycle);

void create_mensaje_RAlimentador(void);
void createMensajeRutinasAlimentador(void);
void create_mensaje_StatusAlimentador(void);
void create_mensaje_StatusAlimentador_1minuto(void);
void create_mensaje_RespuestaOK(void);

//Configura la hora que llega en el mensaje del Xbee
void config_hora(void);

void save_ID_alimentador(void);
void save_MAC_InfoRutina(void);
void save_MAC_monitor(void);
void save_MAC_CRA(void);
void read_ID_alimentador(void);
void read_MAC_monitor(void);
void read_MAC_CRA(void);

bool check_horario_corrido(uint8_t numeroRutinas);
bool checkRutinaHorarioCorrido(uint16_t horaInicio, uint16_t horaFin);
//void check_rutina_programada(void);
bool check_rutina_programada(void);
bool check_MAC_mensaje_entrante(void);

void save_IEEE_regresar(uint8_t posicion_IEEE);
void saveEEPROM_DayAlimentacion(void);
void saveEEPROM_HoraInicio(void);
void saveEEPROM_HoraFin(void);
void saveEEPROM_IntervaloMinutos(void);
void saveEEPROM_DuracionSegundos(void);
uint16_t readEEPROM_DuracionSegundos(void);
void saveEEPROM_VelocidadMinima(void);
uint8_t readEEPROM_VelocidadMinima(void);
void saveEEPROM_VelocidadMaxima(void);
uint8_t readEEPROM_VelocidadMaxima(void);
void saveEEPROM_VelocidadDosificador(void);
uint8_t readEEPROM_VelocidadDosificador(void);
void saveEEPROM_DistribucionUniforme(void);

void saveEEPROM_NumeroRutinas_RutinaSimple(void);   //Funcion temporal hasta que se elimine por completo la forma antigua
void saveEEPROM_NumeroRutinas(void);
uint8_t readEEPROM_NumeroRutinas(void);
void saveEEPROM_DayAlimentacion_Multiples(void);
uint8_t readEEPROM_DayAlimentacion_Multiples(void);
void saveEEPROM_InicioFinIntervaloDuracionTiempoRutina(uint8_t numeros_rutinas);
uint16_t readEEPROM_HoraInicioRutina(uint8_t numero_rutina);
uint16_t readEEPROM_HoraFinalRutina(uint8_t numero_rutina);
uint16_t readEEPROM_IntervaloMinutosRutina(uint8_t numero_rutina);
uint16_t readEEPROM_DuracionSegundosRutina(uint8_t numero_rutina);
void saveEEPROM_VelocidadMinMaxDistribucionUniformeGlobal(volatile uint8_t *ptrBufferRX, uint8_t numero_rutinas);
uint8_t readEEPROM_VelocidadMinimaRutina(uint8_t numero_rutina);
uint8_t readEEPROM_VelocidadMaximaRutina(uint8_t numero_rutina);
uint8_t readEEPROM_VelocidadDosificadorRutina(uint8_t numero_rutina);
bool readEEPROM_DistribucionUniformeRutina(uint8_t numero_rutina);

void selector_rutina(void);
uint8_t buscar_rutina_adecuada(uint16_t horaNow, uint8_t numeroRutinas);
void create_horario(void);
void create_horario_corrido(void);
uint16_t getTimeNextAlimentacion(uint16_t horaNow, uint16_t horaInicio, uint16_t horaFin, uint16_t intervaloMinutos);
bool revisar_dia_rutina(void);

uint16_t read_2AddressEEPROM(uint16_t localidad_eeprom);
//****************///
void crear_mensaje(uint8_t *ptrMAC, uint8_t *ptrMensaje, uint8_t tamanio_mensaje);

//Funciones decodificar hora que esta en ASCII
uint8_t convertYear_hex(void);
uint8_t convertMonth_hex(void);
uint8_t convertDate_hex(void);
uint8_t convertDayWeek_hex(void);
uint8_t convertHour_hex(void);
uint8_t convertMinutes_hex(void);
uint8_t convertSeconds_hex(void);
uint8_t convertASCIItoDecimal(volatile uint8_t *ptrBufferRX, uint8_t lugar_cadena_decimal, uint8_t lugar_cadena_unidad);
uint8_t convertASCII_hex(uint8_t lugar_cadena_decimal, uint8_t lugar_cadena_unidad);
uint8_t convertHex_ASCII(uint8_t hex);
uint8_t decodificar_numero_ASCII(uint8_t ASCII);

//Funciones Debug
void create_mensaje_hora(void);
void create_mensaje_version_firmware(void);
void send_hora_alimentador(void);
void send_version_firmware(void);
void enviar_mensaje_TX_xbee(void);
//funciones sensor de distancia
float get_distance(void);
void control_bomba_llenado (void);
void control_bomba_drenaje (void);

#ifdef	__cplusplus
}
#endif

#endif	/* FUNCIONES_H */

