#include "I2CC.h"
#include "mcc_generated_files/mcc.h"
void I2C2_Initialize()
{
    I2C1CON0 = 0x04;                                                            // CSTR Enable clocking; S Cleared by hardware after Start; MODE 7-bit address;
    I2C1CON1 = 0x80;                                                            // CSD Clock Stretching enabled; ACKDT ACK; ACKCNT NACK; 
    I2C1CON2 = 0x00;                                                            // ABD enabled; SDAHT 300 ns; BFRET 8 I2C Clocks; FME disabled; 
    I2C1CLK = 0x03;                                                             // CLK MFINTOSC; 
    I2C1PIR = 0;                                                                // Clear all the error flags
    I2C1ERR = 0;
    I2C1CON0bits.EN = 1;
}

void I2C2_Init(void){
    TRIS_SCL = 1;
    TRIS_SDA = 1;
    
    SSPSTATbits.SMP = 1; // 100Kbps
    SSPSTATbits.CKE = 0;
    
    
    SSPCON1bits.SSPEN = 1; // SDA Y SCL
    SSPCON1bits.SSPM = 0b1000;// Modo Maestro
    
    SSPCON2 = 0x00;
    
    SSPADD = 49; // 100Kbps 

}

void I2C2_Start(void){
    SSPCON2bits.SEN = 1;
    while(SSPCON2bits.SEN == 1);
}

void I2C2_Stop(void){
    SSPCON2bits.PEN = 1;
    while(SSPCON2bits.PEN == 1);
}

void I2C2_Restart(void){
    SSPCON2bits.RSEN = 1;
    while(SSPCON2bits.RSEN == 1);
}

void I2C2_Ack(void){
    PIR1bits.SSPIF = 0;
    SSPCON2bits.ACKDT = 0;//ACK
    SSPCON2bits.ACKEN = 1;//HABILITAR
    while(PIR1bits.SSPIF == 0);
}

void I2C2_Nack(void){
    PIR1bits.SSPIF = 0;
    SSPCON2bits.ACKDT = 1;//NACK
    SSPCON2bits.ACKEN = 1;//HABILITAR
    while(PIR1bits.SSPIF == 0);
}

void I2C2_Tx(char data){
    PIR1bits.SSPIF = 0;
    SSPBUF = data;
    while(PIR1bits.SSPIF == 0);
}

char I2C2_Rx(void){
    PIR1bits.SSPIF = 0;
    SSPCON2bits.RCEN = 1;
    while(PIR1bits.SSPIF == 0);
    return SSPBUF;
}
void I2C2_WRITE(char data,char adress){
     I2C2_Start();
     I2C2_Tx(adress);
     I2C2_Tx(data);
     I2C2_Stop();
     __delay_ms(5);
}

