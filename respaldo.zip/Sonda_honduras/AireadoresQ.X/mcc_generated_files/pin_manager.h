/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC18F47Q43
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.31 and above
        MPLAB 	          :  MPLAB X 5.45	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set A_MT1 aliases
#define A_MT1_TRIS                 TRISAbits.TRISA0
#define A_MT1_LAT                  LATAbits.LATA0
#define A_MT1_PORT                 PORTAbits.RA0
#define A_MT1_WPU                  WPUAbits.WPUA0
#define A_MT1_OD                   ODCONAbits.ODCA0
#define A_MT1_ANS                  ANSELAbits.ANSELA0
#define A_MT1_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define A_MT1_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define A_MT1_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define A_MT1_GetValue()           PORTAbits.RA0
#define A_MT1_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define A_MT1_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define A_MT1_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define A_MT1_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define A_MT1_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define A_MT1_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define A_MT1_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define A_MT1_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set A_MT2 aliases
#define A_MT2_TRIS                 TRISAbits.TRISA1
#define A_MT2_LAT                  LATAbits.LATA1
#define A_MT2_PORT                 PORTAbits.RA1
#define A_MT2_WPU                  WPUAbits.WPUA1
#define A_MT2_OD                   ODCONAbits.ODCA1
#define A_MT2_ANS                  ANSELAbits.ANSELA1
#define A_MT2_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define A_MT2_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define A_MT2_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define A_MT2_GetValue()           PORTAbits.RA1
#define A_MT2_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define A_MT2_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define A_MT2_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define A_MT2_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define A_MT2_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define A_MT2_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define A_MT2_SetAnalogMode()      do { ANSELAbits.ANSELA1 = 1; } while(0)
#define A_MT2_SetDigitalMode()     do { ANSELAbits.ANSELA1 = 0; } while(0)

// get/set P_BATERIA aliases
#define P_BATERIA_TRIS                 TRISAbits.TRISA2
#define P_BATERIA_LAT                  LATAbits.LATA2
#define P_BATERIA_PORT                 PORTAbits.RA2
#define P_BATERIA_WPU                  WPUAbits.WPUA2
#define P_BATERIA_OD                   ODCONAbits.ODCA2
#define P_BATERIA_ANS                  ANSELAbits.ANSELA2
#define P_BATERIA_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define P_BATERIA_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define P_BATERIA_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define P_BATERIA_GetValue()           PORTAbits.RA2
#define P_BATERIA_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define P_BATERIA_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define P_BATERIA_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define P_BATERIA_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define P_BATERIA_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define P_BATERIA_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define P_BATERIA_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define P_BATERIA_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set BATERIA aliases
#define BATERIA_TRIS                 TRISAbits.TRISA3
#define BATERIA_LAT                  LATAbits.LATA3
#define BATERIA_PORT                 PORTAbits.RA3
#define BATERIA_WPU                  WPUAbits.WPUA3
#define BATERIA_OD                   ODCONAbits.ODCA3
#define BATERIA_ANS                  ANSELAbits.ANSELA3
#define BATERIA_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define BATERIA_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define BATERIA_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define BATERIA_GetValue()           PORTAbits.RA3
#define BATERIA_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define BATERIA_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define BATERIA_SetPullup()          do { WPUAbits.WPUA3 = 1; } while(0)
#define BATERIA_ResetPullup()        do { WPUAbits.WPUA3 = 0; } while(0)
#define BATERIA_SetPushPull()        do { ODCONAbits.ODCA3 = 0; } while(0)
#define BATERIA_SetOpenDrain()       do { ODCONAbits.ODCA3 = 1; } while(0)
#define BATERIA_SetAnalogMode()      do { ANSELAbits.ANSELA3 = 1; } while(0)
#define BATERIA_SetDigitalMode()     do { ANSELAbits.ANSELA3 = 0; } while(0)

// get/set PANEL aliases
#define PANEL_TRIS                 TRISAbits.TRISA4
#define PANEL_LAT                  LATAbits.LATA4
#define PANEL_PORT                 PORTAbits.RA4
#define PANEL_WPU                  WPUAbits.WPUA4
#define PANEL_OD                   ODCONAbits.ODCA4
#define PANEL_ANS                  ANSELAbits.ANSELA4
#define PANEL_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define PANEL_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define PANEL_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define PANEL_GetValue()           PORTAbits.RA4
#define PANEL_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define PANEL_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define PANEL_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define PANEL_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define PANEL_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define PANEL_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define PANEL_SetAnalogMode()      do { ANSELAbits.ANSELA4 = 1; } while(0)
#define PANEL_SetDigitalMode()     do { ANSELAbits.ANSELA4 = 0; } while(0)

// get/set EN1 aliases
#define EN1_TRIS                 TRISAbits.TRISA5
#define EN1_LAT                  LATAbits.LATA5
#define EN1_PORT                 PORTAbits.RA5
#define EN1_WPU                  WPUAbits.WPUA5
#define EN1_OD                   ODCONAbits.ODCA5
#define EN1_ANS                  ANSELAbits.ANSELA5
#define EN1_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define EN1_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define EN1_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define EN1_GetValue()           PORTAbits.RA5
#define EN1_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define EN1_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define EN1_SetPullup()          do { WPUAbits.WPUA5 = 1; } while(0)
#define EN1_ResetPullup()        do { WPUAbits.WPUA5 = 0; } while(0)
#define EN1_SetPushPull()        do { ODCONAbits.ODCA5 = 0; } while(0)
#define EN1_SetOpenDrain()       do { ODCONAbits.ODCA5 = 1; } while(0)
#define EN1_SetAnalogMode()      do { ANSELAbits.ANSELA5 = 1; } while(0)
#define EN1_SetDigitalMode()     do { ANSELAbits.ANSELA5 = 0; } while(0)

// get/set RA6 procedures
#define RA6_SetHigh()            do { LATAbits.LATA6 = 1; } while(0)
#define RA6_SetLow()             do { LATAbits.LATA6 = 0; } while(0)
#define RA6_Toggle()             do { LATAbits.LATA6 = ~LATAbits.LATA6; } while(0)
#define RA6_GetValue()              PORTAbits.RA6
#define RA6_SetDigitalInput()    do { TRISAbits.TRISA6 = 1; } while(0)
#define RA6_SetDigitalOutput()   do { TRISAbits.TRISA6 = 0; } while(0)
#define RA6_SetPullup()             do { WPUAbits.WPUA6 = 1; } while(0)
#define RA6_ResetPullup()           do { WPUAbits.WPUA6 = 0; } while(0)
#define RA6_SetAnalogMode()         do { ANSELAbits.ANSELA6 = 1; } while(0)
#define RA6_SetDigitalMode()        do { ANSELAbits.ANSELA6 = 0; } while(0)

// get/set RA7 procedures
#define RA7_SetHigh()            do { LATAbits.LATA7 = 1; } while(0)
#define RA7_SetLow()             do { LATAbits.LATA7 = 0; } while(0)
#define RA7_Toggle()             do { LATAbits.LATA7 = ~LATAbits.LATA7; } while(0)
#define RA7_GetValue()              PORTAbits.RA7
#define RA7_SetDigitalInput()    do { TRISAbits.TRISA7 = 1; } while(0)
#define RA7_SetDigitalOutput()   do { TRISAbits.TRISA7 = 0; } while(0)
#define RA7_SetPullup()             do { WPUAbits.WPUA7 = 1; } while(0)
#define RA7_ResetPullup()           do { WPUAbits.WPUA7 = 0; } while(0)
#define RA7_SetAnalogMode()         do { ANSELAbits.ANSELA7 = 1; } while(0)
#define RA7_SetDigitalMode()        do { ANSELAbits.ANSELA7 = 0; } while(0)

// get/set Sdistancia aliases
#define Sdistancia_TRIS                 TRISBbits.TRISB1
#define Sdistancia_LAT                  LATBbits.LATB1
#define Sdistancia_PORT                 PORTBbits.RB1
#define Sdistancia_WPU                  WPUBbits.WPUB1
#define Sdistancia_OD                   ODCONBbits.ODCB1
#define Sdistancia_ANS                  ANSELBbits.ANSELB1
#define Sdistancia_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define Sdistancia_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define Sdistancia_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define Sdistancia_GetValue()           PORTBbits.RB1
#define Sdistancia_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define Sdistancia_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define Sdistancia_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define Sdistancia_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define Sdistancia_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define Sdistancia_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define Sdistancia_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define Sdistancia_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RB2 procedures
#define RB2_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define RB2_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define RB2_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define RB2_GetValue()              PORTBbits.RB2
#define RB2_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define RB2_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define RB2_SetPullup()             do { WPUBbits.WPUB2 = 1; } while(0)
#define RB2_ResetPullup()           do { WPUBbits.WPUB2 = 0; } while(0)
#define RB2_SetAnalogMode()         do { ANSELBbits.ANSELB2 = 1; } while(0)
#define RB2_SetDigitalMode()        do { ANSELBbits.ANSELB2 = 0; } while(0)

// get/set IO_RB3 aliases
#define IO_RB3_TRIS                 TRISBbits.TRISB3
#define IO_RB3_LAT                  LATBbits.LATB3
#define IO_RB3_PORT                 PORTBbits.RB3
#define IO_RB3_WPU                  WPUBbits.WPUB3
#define IO_RB3_OD                   ODCONBbits.ODCB3
#define IO_RB3_ANS                  ANSELBbits.ANSELB3
#define IO_RB3_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define IO_RB3_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define IO_RB3_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define IO_RB3_GetValue()           PORTBbits.RB3
#define IO_RB3_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define IO_RB3_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define IO_RB3_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define IO_RB3_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define IO_RB3_SetPushPull()        do { ODCONBbits.ODCB3 = 0; } while(0)
#define IO_RB3_SetOpenDrain()       do { ODCONBbits.ODCB3 = 1; } while(0)
#define IO_RB3_SetAnalogMode()      do { ANSELBbits.ANSELB3 = 1; } while(0)
#define IO_RB3_SetDigitalMode()     do { ANSELBbits.ANSELB3 = 0; } while(0)

// get/set RB4 procedures
#define RB4_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define RB4_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define RB4_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define RB4_GetValue()              PORTBbits.RB4
#define RB4_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define RB4_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define RB4_SetPullup()             do { WPUBbits.WPUB4 = 1; } while(0)
#define RB4_ResetPullup()           do { WPUBbits.WPUB4 = 0; } while(0)
#define RB4_SetAnalogMode()         do { ANSELBbits.ANSELB4 = 1; } while(0)
#define RB4_SetDigitalMode()        do { ANSELBbits.ANSELB4 = 0; } while(0)

// get/set RB5 procedures
#define RB5_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define RB5_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define RB5_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define RB5_GetValue()              PORTBbits.RB5
#define RB5_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define RB5_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define RB5_SetPullup()             do { WPUBbits.WPUB5 = 1; } while(0)
#define RB5_ResetPullup()           do { WPUBbits.WPUB5 = 0; } while(0)
#define RB5_SetAnalogMode()         do { ANSELBbits.ANSELB5 = 1; } while(0)
#define RB5_SetDigitalMode()        do { ANSELBbits.ANSELB5 = 0; } while(0)

// get/set RC0 procedures
#define RC0_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define RC0_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define RC0_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define RC0_GetValue()              PORTCbits.RC0
#define RC0_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define RC0_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define RC0_SetPullup()             do { WPUCbits.WPUC0 = 1; } while(0)
#define RC0_ResetPullup()           do { WPUCbits.WPUC0 = 0; } while(0)
#define RC0_SetAnalogMode()         do { ANSELCbits.ANSELC0 = 1; } while(0)
#define RC0_SetDigitalMode()        do { ANSELCbits.ANSELC0 = 0; } while(0)

// get/set RC1 procedures
#define RC1_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define RC1_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define RC1_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define RC1_GetValue()              PORTCbits.RC1
#define RC1_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define RC1_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define RC1_SetPullup()             do { WPUCbits.WPUC1 = 1; } while(0)
#define RC1_ResetPullup()           do { WPUCbits.WPUC1 = 0; } while(0)
#define RC1_SetAnalogMode()         do { ANSELCbits.ANSELC1 = 1; } while(0)
#define RC1_SetDigitalMode()        do { ANSELCbits.ANSELC1 = 0; } while(0)

// get/set INT_SQW aliases
#define INT_SQW_TRIS                 TRISCbits.TRISC2
#define INT_SQW_LAT                  LATCbits.LATC2
#define INT_SQW_PORT                 PORTCbits.RC2
#define INT_SQW_WPU                  WPUCbits.WPUC2
#define INT_SQW_OD                   ODCONCbits.ODCC2
#define INT_SQW_ANS                  ANSELCbits.ANSELC2
#define INT_SQW_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define INT_SQW_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define INT_SQW_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define INT_SQW_GetValue()           PORTCbits.RC2
#define INT_SQW_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define INT_SQW_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define INT_SQW_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define INT_SQW_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define INT_SQW_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define INT_SQW_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define INT_SQW_SetAnalogMode()      do { ANSELCbits.ANSELC2 = 1; } while(0)
#define INT_SQW_SetDigitalMode()     do { ANSELCbits.ANSELC2 = 0; } while(0)

// get/set LED_R aliases
#define LED_R_TRIS                 TRISCbits.TRISC3
#define LED_R_LAT                  LATCbits.LATC3
#define LED_R_PORT                 PORTCbits.RC3
#define LED_R_WPU                  WPUCbits.WPUC3
#define LED_R_OD                   ODCONCbits.ODCC3
#define LED_R_ANS                  ANSELCbits.ANSELC3
#define LED_R_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define LED_R_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define LED_R_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define LED_R_GetValue()           PORTCbits.RC3
#define LED_R_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define LED_R_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define LED_R_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define LED_R_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define LED_R_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define LED_R_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define LED_R_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define LED_R_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RSSI aliases
#define RSSI_TRIS                 TRISCbits.TRISC4
#define RSSI_LAT                  LATCbits.LATC4
#define RSSI_PORT                 PORTCbits.RC4
#define RSSI_WPU                  WPUCbits.WPUC4
#define RSSI_OD                   ODCONCbits.ODCC4
#define RSSI_ANS                  ANSELCbits.ANSELC4
#define RSSI_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define RSSI_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define RSSI_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define RSSI_GetValue()           PORTCbits.RC4
#define RSSI_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define RSSI_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define RSSI_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define RSSI_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define RSSI_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define RSSI_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define RSSI_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define RSSI_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RESET_XBEE aliases
#define RESET_XBEE_TRIS                 TRISCbits.TRISC5
#define RESET_XBEE_LAT                  LATCbits.LATC5
#define RESET_XBEE_PORT                 PORTCbits.RC5
#define RESET_XBEE_WPU                  WPUCbits.WPUC5
#define RESET_XBEE_OD                   ODCONCbits.ODCC5
#define RESET_XBEE_ANS                  ANSELCbits.ANSELC5
#define RESET_XBEE_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define RESET_XBEE_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define RESET_XBEE_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define RESET_XBEE_GetValue()           PORTCbits.RC5
#define RESET_XBEE_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define RESET_XBEE_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define RESET_XBEE_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define RESET_XBEE_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define RESET_XBEE_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define RESET_XBEE_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define RESET_XBEE_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define RESET_XBEE_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

// get/set RC6 procedures
#define RC6_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define RC6_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define RC6_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define RC6_GetValue()              PORTCbits.RC6
#define RC6_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define RC6_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define RC6_SetPullup()             do { WPUCbits.WPUC6 = 1; } while(0)
#define RC6_ResetPullup()           do { WPUCbits.WPUC6 = 0; } while(0)
#define RC6_SetAnalogMode()         do { ANSELCbits.ANSELC6 = 1; } while(0)
#define RC6_SetDigitalMode()        do { ANSELCbits.ANSELC6 = 0; } while(0)

// get/set RC7 procedures
#define RC7_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define RC7_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define RC7_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define RC7_GetValue()              PORTCbits.RC7
#define RC7_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define RC7_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define RC7_SetPullup()             do { WPUCbits.WPUC7 = 1; } while(0)
#define RC7_ResetPullup()           do { WPUCbits.WPUC7 = 0; } while(0)
#define RC7_SetAnalogMode()         do { ANSELCbits.ANSELC7 = 1; } while(0)
#define RC7_SetDigitalMode()        do { ANSELCbits.ANSELC7 = 0; } while(0)

// get/set LED_B aliases
#define LED_B_TRIS                 TRISDbits.TRISD0
#define LED_B_LAT                  LATDbits.LATD0
#define LED_B_PORT                 PORTDbits.RD0
#define LED_B_WPU                  WPUDbits.WPUD0
#define LED_B_OD                   ODCONDbits.ODCD0
#define LED_B_ANS                  ANSELDbits.ANSELD0
#define LED_B_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define LED_B_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define LED_B_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define LED_B_GetValue()           PORTDbits.RD0
#define LED_B_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define LED_B_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define LED_B_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define LED_B_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define LED_B_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define LED_B_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define LED_B_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define LED_B_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set LED_G aliases
#define LED_G_TRIS                 TRISDbits.TRISD1
#define LED_G_LAT                  LATDbits.LATD1
#define LED_G_PORT                 PORTDbits.RD1
#define LED_G_WPU                  WPUDbits.WPUD1
#define LED_G_OD                   ODCONDbits.ODCD1
#define LED_G_ANS                  ANSELDbits.ANSELD1
#define LED_G_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define LED_G_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define LED_G_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define LED_G_GetValue()           PORTDbits.RD1
#define LED_G_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define LED_G_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define LED_G_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define LED_G_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define LED_G_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define LED_G_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define LED_G_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define LED_G_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RTS_ aliases
#define RTS__TRIS                 TRISDbits.TRISD2
#define RTS__LAT                  LATDbits.LATD2
#define RTS__PORT                 PORTDbits.RD2
#define RTS__WPU                  WPUDbits.WPUD2
#define RTS__OD                   ODCONDbits.ODCD2
#define RTS__ANS                  ANSELDbits.ANSELD2
#define RTS__SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define RTS__SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define RTS__Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define RTS__GetValue()           PORTDbits.RD2
#define RTS__SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define RTS__SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define RTS__SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define RTS__ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define RTS__SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define RTS__SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define RTS__SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define RTS__SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

// get/set DTR_ aliases
#define DTR__TRIS                 TRISDbits.TRISD3
#define DTR__LAT                  LATDbits.LATD3
#define DTR__PORT                 PORTDbits.RD3
#define DTR__WPU                  WPUDbits.WPUD3
#define DTR__OD                   ODCONDbits.ODCD3
#define DTR__ANS                  ANSELDbits.ANSELD3
#define DTR__SetHigh()            do { LATDbits.LATD3 = 1; } while(0)
#define DTR__SetLow()             do { LATDbits.LATD3 = 0; } while(0)
#define DTR__Toggle()             do { LATDbits.LATD3 = ~LATDbits.LATD3; } while(0)
#define DTR__GetValue()           PORTDbits.RD3
#define DTR__SetDigitalInput()    do { TRISDbits.TRISD3 = 1; } while(0)
#define DTR__SetDigitalOutput()   do { TRISDbits.TRISD3 = 0; } while(0)
#define DTR__SetPullup()          do { WPUDbits.WPUD3 = 1; } while(0)
#define DTR__ResetPullup()        do { WPUDbits.WPUD3 = 0; } while(0)
#define DTR__SetPushPull()        do { ODCONDbits.ODCD3 = 0; } while(0)
#define DTR__SetOpenDrain()       do { ODCONDbits.ODCD3 = 1; } while(0)
#define DTR__SetAnalogMode()      do { ANSELDbits.ANSELD3 = 1; } while(0)
#define DTR__SetDigitalMode()     do { ANSELDbits.ANSELD3 = 0; } while(0)

// get/set RD4 procedures
#define RD4_SetHigh()            do { LATDbits.LATD4 = 1; } while(0)
#define RD4_SetLow()             do { LATDbits.LATD4 = 0; } while(0)
#define RD4_Toggle()             do { LATDbits.LATD4 = ~LATDbits.LATD4; } while(0)
#define RD4_GetValue()              PORTDbits.RD4
#define RD4_SetDigitalInput()    do { TRISDbits.TRISD4 = 1; } while(0)
#define RD4_SetDigitalOutput()   do { TRISDbits.TRISD4 = 0; } while(0)
#define RD4_SetPullup()             do { WPUDbits.WPUD4 = 1; } while(0)
#define RD4_ResetPullup()           do { WPUDbits.WPUD4 = 0; } while(0)
#define RD4_SetAnalogMode()         do { ANSELDbits.ANSELD4 = 1; } while(0)
#define RD4_SetDigitalMode()        do { ANSELDbits.ANSELD4 = 0; } while(0)

// get/set DE aliases
#define DE_TRIS                 TRISDbits.TRISD5
#define DE_LAT                  LATDbits.LATD5
#define DE_PORT                 PORTDbits.RD5
#define DE_WPU                  WPUDbits.WPUD5
#define DE_OD                   ODCONDbits.ODCD5
#define DE_ANS                  ANSELDbits.ANSELD5
#define DE_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define DE_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define DE_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define DE_GetValue()           PORTDbits.RD5
#define DE_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define DE_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define DE_SetPullup()          do { WPUDbits.WPUD5 = 1; } while(0)
#define DE_ResetPullup()        do { WPUDbits.WPUD5 = 0; } while(0)
#define DE_SetPushPull()        do { ODCONDbits.ODCD5 = 0; } while(0)
#define DE_SetOpenDrain()       do { ODCONDbits.ODCD5 = 1; } while(0)
#define DE_SetAnalogMode()      do { ANSELDbits.ANSELD5 = 1; } while(0)
#define DE_SetDigitalMode()     do { ANSELDbits.ANSELD5 = 0; } while(0)

// get/set RE aliases
#define RE_TRIS                 TRISDbits.TRISD6
#define RE_LAT                  LATDbits.LATD6
#define RE_PORT                 PORTDbits.RD6
#define RE_WPU                  WPUDbits.WPUD6
#define RE_OD                   ODCONDbits.ODCD6
#define RE_ANS                  ANSELDbits.ANSELD6
#define RE_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define RE_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define RE_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define RE_GetValue()           PORTDbits.RD6
#define RE_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define RE_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define RE_SetPullup()          do { WPUDbits.WPUD6 = 1; } while(0)
#define RE_ResetPullup()        do { WPUDbits.WPUD6 = 0; } while(0)
#define RE_SetPushPull()        do { ODCONDbits.ODCD6 = 0; } while(0)
#define RE_SetOpenDrain()       do { ODCONDbits.ODCD6 = 1; } while(0)
#define RE_SetAnalogMode()      do { ANSELDbits.ANSELD6 = 1; } while(0)
#define RE_SetDigitalMode()     do { ANSELDbits.ANSELD6 = 0; } while(0)

// get/set RD7 procedures
#define RD7_SetHigh()            do { LATDbits.LATD7 = 1; } while(0)
#define RD7_SetLow()             do { LATDbits.LATD7 = 0; } while(0)
#define RD7_Toggle()             do { LATDbits.LATD7 = ~LATDbits.LATD7; } while(0)
#define RD7_GetValue()              PORTDbits.RD7
#define RD7_SetDigitalInput()    do { TRISDbits.TRISD7 = 1; } while(0)
#define RD7_SetDigitalOutput()   do { TRISDbits.TRISD7 = 0; } while(0)
#define RD7_SetPullup()             do { WPUDbits.WPUD7 = 1; } while(0)
#define RD7_ResetPullup()           do { WPUDbits.WPUD7 = 0; } while(0)
#define RD7_SetAnalogMode()         do { ANSELDbits.ANSELD7 = 1; } while(0)
#define RD7_SetDigitalMode()        do { ANSELDbits.ANSELD7 = 0; } while(0)

// get/set BOTON_1 aliases
#define BOTON_1_TRIS                 TRISEbits.TRISE0
#define BOTON_1_LAT                  LATEbits.LATE0
#define BOTON_1_PORT                 PORTEbits.RE0
#define BOTON_1_WPU                  WPUEbits.WPUE0
#define BOTON_1_OD                   ODCONEbits.ODCE0
#define BOTON_1_ANS                  ANSELEbits.ANSELE0
#define BOTON_1_SetHigh()            do { LATEbits.LATE0 = 1; } while(0)
#define BOTON_1_SetLow()             do { LATEbits.LATE0 = 0; } while(0)
#define BOTON_1_Toggle()             do { LATEbits.LATE0 = ~LATEbits.LATE0; } while(0)
#define BOTON_1_GetValue()           PORTEbits.RE0
#define BOTON_1_SetDigitalInput()    do { TRISEbits.TRISE0 = 1; } while(0)
#define BOTON_1_SetDigitalOutput()   do { TRISEbits.TRISE0 = 0; } while(0)
#define BOTON_1_SetPullup()          do { WPUEbits.WPUE0 = 1; } while(0)
#define BOTON_1_ResetPullup()        do { WPUEbits.WPUE0 = 0; } while(0)
#define BOTON_1_SetPushPull()        do { ODCONEbits.ODCE0 = 0; } while(0)
#define BOTON_1_SetOpenDrain()       do { ODCONEbits.ODCE0 = 1; } while(0)
#define BOTON_1_SetAnalogMode()      do { ANSELEbits.ANSELE0 = 1; } while(0)
#define BOTON_1_SetDigitalMode()     do { ANSELEbits.ANSELE0 = 0; } while(0)

// get/set BOTON_2 aliases
#define BOTON_2_TRIS                 TRISEbits.TRISE1
#define BOTON_2_LAT                  LATEbits.LATE1
#define BOTON_2_PORT                 PORTEbits.RE1
#define BOTON_2_WPU                  WPUEbits.WPUE1
#define BOTON_2_OD                   ODCONEbits.ODCE1
#define BOTON_2_ANS                  ANSELEbits.ANSELE1
#define BOTON_2_SetHigh()            do { LATEbits.LATE1 = 1; } while(0)
#define BOTON_2_SetLow()             do { LATEbits.LATE1 = 0; } while(0)
#define BOTON_2_Toggle()             do { LATEbits.LATE1 = ~LATEbits.LATE1; } while(0)
#define BOTON_2_GetValue()           PORTEbits.RE1
#define BOTON_2_SetDigitalInput()    do { TRISEbits.TRISE1 = 1; } while(0)
#define BOTON_2_SetDigitalOutput()   do { TRISEbits.TRISE1 = 0; } while(0)
#define BOTON_2_SetPullup()          do { WPUEbits.WPUE1 = 1; } while(0)
#define BOTON_2_ResetPullup()        do { WPUEbits.WPUE1 = 0; } while(0)
#define BOTON_2_SetPushPull()        do { ODCONEbits.ODCE1 = 0; } while(0)
#define BOTON_2_SetOpenDrain()       do { ODCONEbits.ODCE1 = 1; } while(0)
#define BOTON_2_SetAnalogMode()      do { ANSELEbits.ANSELE1 = 1; } while(0)
#define BOTON_2_SetDigitalMode()     do { ANSELEbits.ANSELE1 = 0; } while(0)

// get/set BOTON_3 aliases
#define BOTON_3_TRIS                 TRISEbits.TRISE2
#define BOTON_3_LAT                  LATEbits.LATE2
#define BOTON_3_PORT                 PORTEbits.RE2
#define BOTON_3_WPU                  WPUEbits.WPUE2
#define BOTON_3_OD                   ODCONEbits.ODCE2
#define BOTON_3_ANS                  ANSELEbits.ANSELE2
#define BOTON_3_SetHigh()            do { LATEbits.LATE2 = 1; } while(0)
#define BOTON_3_SetLow()             do { LATEbits.LATE2 = 0; } while(0)
#define BOTON_3_Toggle()             do { LATEbits.LATE2 = ~LATEbits.LATE2; } while(0)
#define BOTON_3_GetValue()           PORTEbits.RE2
#define BOTON_3_SetDigitalInput()    do { TRISEbits.TRISE2 = 1; } while(0)
#define BOTON_3_SetDigitalOutput()   do { TRISEbits.TRISE2 = 0; } while(0)
#define BOTON_3_SetPullup()          do { WPUEbits.WPUE2 = 1; } while(0)
#define BOTON_3_ResetPullup()        do { WPUEbits.WPUE2 = 0; } while(0)
#define BOTON_3_SetPushPull()        do { ODCONEbits.ODCE2 = 0; } while(0)
#define BOTON_3_SetOpenDrain()       do { ODCONEbits.ODCE2 = 1; } while(0)
#define BOTON_3_SetAnalogMode()      do { ANSELEbits.ANSELE2 = 1; } while(0)
#define BOTON_3_SetDigitalMode()     do { ANSELEbits.ANSELE2 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/