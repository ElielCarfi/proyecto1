#include <stdint.h>
#include <stdbool.h>
#include "math.h"
#include "colores_Torreta.h"
#include "funciones.h"
#include "Float_IEEE754.h"
#include "identificador_fallos.h"
#include "Xbee.h"
#include "Sonda.h"
#include "LCD_I2C.h"
#include "uart3.h"
#include "LCD_I2.h"
//#include "I2CC.h"
#include "mensajesLCD.h"
#include "RTC_DS3232.h"
#include "i2c.h"
#include "i2c1_master_example.h"
//#include "i2c1_master_example.h"
//#include "i2c1_master.h"
#include "mcc_generated_files/mcc.h"


//#define DEBUG     //Descomentar en caso de estar revisando fallos

void enviar_mensaje_TX_xbee();
void procesar_mensaje_RX_xbee(void);
void revisarStatus_TX_xbee(void);
void control_mensaje_RX_xbee(void);
void delay_ms(uint16_t tiempo_ms);
void revisar_accion_modulo(unsigned char identificador_accion_HB, unsigned char identificador_accion_LB);
void agregar_elementos_cadena(uint16_t posicion, uint8_t dato);
int distancia;
static char nivel[]="NIVEL 000.00";

volatile uint8_t lectura_usart1 = 0; //Resultado que lo que lea RX de UART1

uint8_t auxDato = 0;    //Variable solo para pruebas
static char buffer[]; 
uint8_t dato_read_usart2;
int distance;
//float distance;

volatile uint16_t posicion_cadena_mensaje = 0;
volatile uint16_t largo_mensaje = 0;

void __interrupt() INTERRUPT_InterruptManagerHigh (void)
{
    // interrupt handler
    if(PIE4bits.U1RXIE == 1 && PIR4bits.U1RXIF == 1)
    {
        UART1_RxInterruptHandler();
        lectura_usart1 = UART1_Read();
        control_mensaje_RX_xbee();
        procesar_mensaje_RX_xbee();
    }
    else if(PIE8bits.U2RXIE == 1 && PIR8bits.U2RXIF == 1)
    {
        UART2_RxInterruptHandler();
        captura_datos_RX_sensor();
    }
    else
    {
        //Unhandled Interrupt
    }
}

void __interrupt(low_priority) INTERRUPT_InterruptManagerLow (void)
{
     //interrupt handler
    if(PIE3bits.TMR0IE == 1 && PIR3bits.TMR0IF == 1)
    {
        TMR0_ISR();
        if(alimentando_flag || alimentar_ahora_flag){
            control_tiempo_alimentacion_interrupcion();
        }
        else if(!alimentando_flag && !alimentar_ahora_flag){
            tiempo_transcurrido_segundos++;
        }
        
    }
    else if(PIE3bits.TMR1IE == 1 && PIR3bits.TMR1IF == 1)
    {
        TMR1_ISR();
        controlBlinkLEDInterrupcion();
    }
    else
    {
        //Unhandled Interrupt
    }
}

/*
                         Main application
 */
void main(void){
    // Initialize the device
    SYSTEM_Initialize();
//    
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global Interrupts
    // Use the following macros to:

    // Enable high priority global interrupts
//    INTERRUPT_GlobalInterruptHighEnable();

    // Enable low priority global interrupts.
//    INTERRUPT_GlobalInterruptLowEnable();
    // Disable high priority global interrupts
    INTERRUPT_GlobalInterruptHighDisable();
    // Disable low priority global interrupts.
    INTERRUPT_GlobalInterruptLowDisable();
    
    LED_ROJO
    lcd_i2cinit();
    lcd_i2cinit();
    lcd_clear();
float distancia_prueba=0;
    float ph=5.5;
    float temperatura = 28.6;
    float m = 2.5;
    
    while (1){
        distancia_prueba = get_distance();
        if(SWITCH_1==0){
        ph += 1.2;
        temperatura += 2.1;
        m += 0.5;
        }
        LED_ROJO_APAGADO
        lcd_pantalla_flechas(ph, temperatura,distancia_prueba, true); 
        __delay_ms(2000);
        lcd_pantalla_flechas(ph, temperatura,distancia_prueba, false); 
        __delay_ms(2000);
    }
}

void control_mensaje_RX_xbee(void){
// // <editor-fold defaultstate="collapsed" desc="controla la entrada del mensaje entrante del xbee, separando las primeras partes del mensaje">
//    if(!mensaje_enviado){
//        if((lectura_usart1 == START_DELIMITER) && (mensaje_recibido == false) && (mensaje_en_curso == false) && (posicion_cadena_mensaje == 0)){
//            mensaje_recibido = true;
//            posicion_cadena_mensaje++;
//        }
//        else if((posicion_cadena_mensaje == 1)  && (mensaje_recibido == true) && (mensaje_en_curso == false)){
//            largo_mensaje = lectura_usart1;
//            largo_mensaje = largo_mensaje << 8;
//            posicion_cadena_mensaje++;
//        }
//        else if((posicion_cadena_mensaje == 2) && (mensaje_recibido == true) && (mensaje_en_curso == false )){
//            largo_mensaje = lectura_usart1;
//            posicion_cadena_mensaje = 0;
//            mensaje_en_curso = true;
//        }
//        else if((mensaje_recibido == true) && (mensaje_en_curso == true) && (mensaje_completo == false) && (posicion_cadena_mensaje < largo_mensaje)){
//            agregar_elementos_cadena(posicion_cadena_mensaje, lectura_usart1);
//            posicion_cadena_mensaje++;
//        }
//        else if((posicion_cadena_mensaje >= largo_mensaje) && (mensaje_recibido == true) && (mensaje_en_curso == true) && (mensaje_completo == false)){
//            //Revisa que el checksum del mensaje que se guardo sea correcto
//            mensaje_completo = true;
//            /*
//            if(lectura_usart1 == calculate_checksum(serial_cadena, largo_mensaje+1)){
//                mensaje_completo = true;
//            }
//            else{
//                //serial_cadena[260] = 0;
//                fallo = FALLO_CHECKSUM_XBEE;
//            }*/
//            mensaje_recibido = false;
//            mensaje_en_curso = false;
//            posicion_cadena_mensaje = 0;            
//        }
//        else{
//            fallo = SIN_RECIBIR_MENSAJE_COMPLETO;
//        }
//    }
//// </editor-fold>  
}

void delay_ms(uint16_t tiempo_ms){
// <editor-fold defaultstate="collapsed" desc="Tiempo en ms condicion de alimentar_ahora">    
    for(uint16_t i = 0; ((i < tiempo_ms) && (!alimentar_ahora_flag) && (SWITCH_3 == 1) && 
                        (!FLAGS_SONDA.modoConfiguration) && (COMANDO != TOMAR_LECTURAS)); i++){
        __delay_ms(1);
    }
// </editor-fold> 
}

//Revisa si el
void procesar_mensaje_RX_xbee(void){
//// <editor-fold defaultstate="collapsed" desc="Procesa el mensaje que entro por el Xbee">
//    if((mensaje_completo == true) && (mensaje_enviado == false)){
//        uint8_t *ptrMensaje = serial_cadena;
////        uint8_t posicion_mensaje = 12; //Es el 13, es -1 porque se cuenta el 0
//        
//        mensaje_completo = false;        
//        
//        if(rev_ID_alimetador_GB(ptrMensaje[12]) == true){
//            if(rev_ID_alimentador(ptrMensaje[15], ptrMensaje[16], ptrMensaje[17]) == true){
//                revisar_accion_modulo(ptrMensaje[13], ptrMensaje[14]);
//            }
//            else if((ptrMensaje[13] == ASIGNAR_ID_ALIMENTADOR_ASCII1) && (ptrMensaje[14] == ASIGNAR_ID_ALIMENTADOR_ASCII2)){
//                save_ID_alimentador();
//                mensaje_respuesta_OK(18);
//                //Borramos el comando que habia llegado del mensaje
//                serial_cadena[13] = 0;
//                serial_cadena[14] = 0;
//            }
//            else{
//                fallo = ID_MODULO_NO_RECONOCIDO;
//            }
//        }
//        else if(ptrMensaje[12] == ID_GLOBAL_SONDA){
//            if(rev_ID_alimentador(ptrMensaje[15], ptrMensaje[16], ptrMensaje[17]) == true){
//                accionesSonda(ptrMensaje[13], ptrMensaje[14]);
//            }
//        }
//    }
//    else if(mensaje_enviado){
//        mensaje_enviado = false;
//    }
//// </editor-fold>
//}

//Falta revisar funcionalidad, rececpcion despues de la transmision
//void revisarStatus_TX_xbee(void){
//    if((mensaje_completo == true) && (mensaje_enviado == true)){
//        uint8_t *ptrMensaje = serial_cadena;
//        uint8_t posicion_mensaje = 0;
//        
//        posicion_mensaje = 3;
//        
//        if(ptrMensaje[posicion_mensaje] == TRANSMIT_STATUS){
//            posicion_mensaje = 6;
//            if(ptrMensaje[posicion_mensaje] == 0x00){
//                mensaje_completo = false;
//                mensaje_enviado = false;
//            }
//        }
//    }
}

//void revisar_accion_modulo(unsigned char identificador_accion_HB, unsigned char identificador_accion_LB){
//// <editor-fold defaultstate="collapsed" desc="Revisa la accion a realizar en del mensaje del Xbee">
//    if((identificador_accion_HB == RUTINA_ASCCI1) && (identificador_accion_LB == RUTINA_ASCCI2)){
//        save_rutina();
//    }
//    else if((identificador_accion_HB == ALIMENTAR_AHORA_ASCII1) && (identificador_accion_LB == ALIMENTAR_AHORA_ASCII2)){
//        alimentar_ahora();
//    }
//    else if((identificador_accion_HB == RESET_ASCII1) && (identificador_accion_LB == RESET_ASCII2)){
//        reset_all();
//    }
//    else if((identificador_accion_HB == DETENER_ALIMENTACION_ASCII1) && (identificador_accion_LB == DETENER_ALIMENTACION_ASCII2)){
//        detener_alimentacion();
//    }
//    else if((identificador_accion_HB == SOLICITUD_STATUS_ASCII1) && (identificador_accion_LB == SOLICITUD_STATUS_ASCII2)){
//        send_status();
//    }
//    else if((identificador_accion_HB == VINCULAR_MONITOR_ASCII1) && (identificador_accion_LB == VINCULAR_MONITOR_ASCII2)){
//        save_MAC_monitor();
//    }
//    else if((identificador_accion_HB == VINCULAR_SISTEMA_ASCII1) && (identificador_accion_LB == VINCULAR_SISTEMA_ASCII2)){
//        save_MAC_CRA();
//        mensaje_respuesta_OK(18);
//    }
//    else if((identificador_accion_HB == HORA_ASCII1) && (identificador_accion_LB == HORA_ASCII2)){
//        config_hora();
//    }
//    else if((identificador_accion_HB == OMITIR_ASCII1) && (identificador_accion_LB == OMITIR_ASCII2)){
//        omitir_alimentacion();
//    }
//    else if((identificador_accion_HB == SOLICITAR_INFO_RUTINA_ASCII1) && (identificador_accion_LB == SOLICITAR_INFO_RUTINA_ASCII2)){
//        info_rutina();
//    }
//    else if((identificador_accion_HB == ELIMINAR_RUTINA_ASCII1) && (identificador_accion_LB == ELIMINAR_RUTINA_ASCII2)){
//        borrar_rutinas(RUTINA.numeroRutinas);
//    }
//    else if((identificador_accion_HB == RUTINA_MULTIPLE_ASCII1) && (identificador_accion_LB == RUTINA_MULTIPLE_ASCII2)){
//        save_rutina_multiple();
//    }
//    else if((identificador_accion_HB == ASIGNAR_ID_ALIMENTADOR_ASCII1) && (identificador_accion_LB == ASIGNAR_ID_ALIMENTADOR_ASCII2)){
//        mensaje_respuesta_OK(18);
//    }
//    else if((identificador_accion_HB == SOLICITAR_RUTINA_DIARIA_ASCII1) && (identificador_accion_LB == SOLICITAR_RUTINA_DIARIA_ASCII2)){
//        infoRutinaDiaria();
//    }
////    else if((identificador_accion_HB == 'D') && (identificador_accion_LB == 'G')){
////        enviar_mensaje_TX_xbee();
////    }
//    else if((identificador_accion_HB == 'H') && (identificador_accion_LB == 'R')){
//        send_hora_alimentador();
//    }
//    else if((identificador_accion_HB == 'F') && (identificador_accion_LB == 'W')){
//        send_version_firmware();
//    }
//    else{
//        fallo = FALLO_ACCIONES;
//    }
//    
//    //Borramos el comando que habia llegado del mensaje
//    serial_cadena[13] = 0;
//    serial_cadena[14] = 0;
//// </editor-fold>
//}
//
void agregar_elementos_cadena(uint16_t posicion, uint8_t dato){
//// <editor-fold defaultstate="collapsed" desc="Agrega elementos que llegan de la recepcion del Xbee a la cadena serial">    
//    serial_cadena[posicion] = dato;
//// </editor-fold>
}

/**
 End of File
*/
