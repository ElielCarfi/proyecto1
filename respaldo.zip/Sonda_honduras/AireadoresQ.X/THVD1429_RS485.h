/* 
 * File:   THVD1429_RS485.h
 * Author: acuic
 *
 * Created on 11 de mayo de 2022, 03:11 PM
 */

#ifndef THVD1429_RS485_H
#define	THVD1429_RS485_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include "mcc_generated_files/uart2.h"
#include <xc.h>

#define _XTAL_FREQ  16000000  
    
//Pines y difiniciones para uso de protocolo RS-485
#define DE                 LATDbits.LATD5
#define RE                 LATDbits.LATD6
#define RS485_TRANSMITIR   RE = 1, DE = 1;
#define RS485_RECIBIR      RE = 0, DE = 0;
#define RS485_IDLE         RE = 1, DE = 0;
#define RS485_ESCRIBIR     0x10
#define RS485_LEER         0x03

struct FLAG_RS485{
    bool crc_tab16_init;
}flagRS485;

//uint8_t crc_tab16_init = 0;
uint8_t contador = 0;
//uint16_t CRC_RECIBIDO = 0;
uint16_t crc_tab16[256] = {0};
char buffer1[50];

void init_crc16_tab(void);
uint16_t crc_modbus(uint8_t *input_str, uint8_t num_bytes);
extern uint16_t comunicacion_RS485(uint8_t id, uint8_t funcion, uint16_t start_address, uint16_t n_registers, uint16_t *data6);

#ifdef	__cplusplus
}
#endif

#endif	/* THVD1429_RS485_H */

