/* 
 * File:   funcionesCompartidasAlimentadorSonda.h
 * Author: acuic
 *
 * Created on 26 de septiembre de 2022, 10:21 AM
 */

#ifndef FUNCIONESCOMPARTIDASALIMENTADORSONDA_H
#define	FUNCIONESCOMPARTIDASALIMENTADORSONDA_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <stdint.h>
//uint8_t decodificar_numero_ASCII(uint8_t ASCII);
void acomodarBytesIEEE(uint8_t *ptrValorIEEE, uint8_t *ptrBufferRX, uint8_t posicionIEEE);

#ifdef	__cplusplus
}
#endif

#endif	/* FUNCIONESCOMPARTIDASALIMENTADORSONDA_H */

