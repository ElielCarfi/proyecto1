/* 
 * File:   identificador_fallos.h
 * Author: Alexis Ramirez
 *
 * Created on 20 de enero de 2022, 02:27 PM
 */

#ifndef IDENTIFICADOR_FALLOS_H
#define	IDENTIFICADOR_FALLOS_H

#ifdef	__cplusplus
extern "C" {
#endif

#define FALLO_ACCIONES                  0x11
#define ID_AIREADOR_NO_RECONOCIDO       0x12
#define ID_MODULO_NO_RECONOCIDO         0x13
#define SIN_RECIBIR_MENSAJE_COMPLETO    0x14
#define SIN_REALIZAR_ALIMENTACION_DU    0x15       //Fallo al leer la distribucion uniforme
#define FALLO_CHECKSUM_XBEE             0xFF


#ifdef	__cplusplus
}
#endif

#endif	/* IDENTIFICADOR_FALLOS_H */

