#include "Sonda_funciones_EEPROM.h"

void saveEEPROMTimeMeasurements(uint8_t *ptrMensaje){
    uint8_t timeIEEE[4] = {0};
    uint16_t timeMeasurements = 0;
    
    for(uint8_t i = 0; i < 4; i++){
        timeIEEE[i] = ptrMensaje[18 + i];
    }
    
    timeMeasurements = (uint16_t)(IEEE754_A_Float(timeIEEE));
    
    DATAEE_WriteByte(L_TIME_MEASUREMENTS, (uint8_t)(timeMeasurements >> 8));
    DATAEE_WriteByte((L_TIME_MEASUREMENTS + 1), (uint8_t)(timeMeasurements));
}

uint16_t readTimeMeasurements(void){    //Regresa el tiempo de frecuencia de mediciones en segundos
    uint16_t timeMeasuerements = 0;
    
    timeMeasuerements = DATAEE_ReadByte(L_TIME_MEASUREMENTS);
    timeMeasuerements = timeMeasuerements << 8;
    timeMeasuerements |= DATAEE_ReadByte(L_TIME_MEASUREMENTS + 1);
    
    if(timeMeasuerements > 720){
        timeMeasuerements = 720;
    }
    
    return timeMeasuerements;
}