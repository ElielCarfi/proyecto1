/* 
 * File:   Macros_Perifericos.h
 * Author: acuic
 *
 * Created on 28 de abril de 2022, 02:06 PM
 */

#ifndef MACROS_PERIFERICOS_H
#define	MACROS_PERIFERICOS_H

#ifdef	__cplusplus
extern "C" {
#endif

#define FUNC1              PORTEbits.RE0
#define FUNC2              PORTEbits.RE1
#define FUNC3              PORTEbits.RE2

#define ENABLE_EN1     LATAbits.LATA5 = 0;
#define DISABLE_EN1    LATAbits.LATA5 = 1;


#ifdef	__cplusplus
}
#endif

#endif	/* MACROS_PERIFERICOS_H */

