#include "THVD1429_RS485.h"

void init_crc16_tab(void) {
// <editor-fold defaultstate="collapsed" desc="init_crc16_tab">
    uint16_t i, j, crc, c;
    
    for (i = 0; i < 256; i++) {
        crc = 0;
        c = i;
        for (j = 0; j < 8; j++) {
            if ((crc ^ c) & 0x0001) crc = (crc >> 1) ^ 0xA001;
            else crc = crc >> 1;
            c = c >> 1;
        }
        crc_tab16[i] = crc;
    }
    flagRS485.crc_tab16_init = true;
//    crc_tab16_init = 1;
// </editor-fold>
}

uint16_t crc_modbus(uint8_t *input_str, uint8_t num_bytes) {
// <editor-fold defaultstate="collapsed" desc="crc_modbus">
    uint16_t crc, a;
    uint8_t *ptr;

    if (!flagRS485.crc_tab16_init){ 
      init_crc16_tab();
    }
    crc = 0xFFFF;
    ptr = input_str;
    if (ptr != NULL) for (a = 0; a < num_bytes; a++) {
            crc = (crc >> 8) ^ crc_tab16[ (crc ^ (uint16_t) * ptr++) & 0x00FF ];
    }
    return crc;
// </editor-fold>
}

extern uint16_t comunicacion_RS485(uint8_t id, uint8_t funcion, uint16_t start_address, uint16_t n_registers, uint16_t *data6){
// <editor-fold defaultstate="collapsed" desc="comunicacion_RS485">
/*
Cada registro leido o escribido sera de 16 bits. Para comunicarte con el dispositivo rs485 se envia un string que sigue el siguiente orden:

Metodo de transmision lectura (comando 0x03)
1.- id que inicialmente sera 0x01 (formato de 8 bits).
2.- funcion que le indica al dispositivo que hacer (formato de 8 bits).
3.- direcion de inicio que espesifica desde que direcion del dispositivo rs485 se comenzara a leer(formato de 16bits).
4.- numero de registros que espesifica el numero de registros de longitud de 16 bits se leeran (formato de 16bits).
5.- crc, es el valor de confirmacion redundante (formato de 16bits).
6.- despues de mandar el string completo debe ejecutarse un delay de al menos 3.3mS

Metodo de recepcion lectura (comando 0x03)
1.- id que inicialmente sera 0x01 (formato de 8 bits).
2.- funcion que le indica al dispositivo que hacer (formato de 8 bits).
3.- direcion de inicio que espesifica desde que direcion del dispositivo rs485 se comenzara a leer(formato de 16bits).
4.- numero de bytes, espesifica el numero de bytes que se enviaran como respuesta, que seran igual al numero de registros solicitados * 2 ya que cada registro es de 16 bytes.
5.- string de datos que se enviaran como respuesta (formato de 16bits).
6.- crc, es el valor de confirmacion redundante (formato de 16bits).
7.- despues de mandar el string completo debe ejecutarse un delay de al menos 3.3mS

Metodo de transmision escritura (comando 0x10)
1.- id que inicialmente sera 0x01 (formato de 8 bits).
2.- funcion que le indica al dispositivo que hacer (formato de 8 bits).
3.- direcion de inicio que espesifica desde que direcion del dispositivo rs485 se comenzara escribir (formato de 16bits).
4.- numero de registros que espesifica el numero de registros de longitud de 16 bits se leeran o escribiran en el dispositivo (formato de 16bits).
5.- numero de bytes, espesifica el numero bytes que se enviaran registros * 2 ya que cada registro es de 16 bytes.
6.- string de datos que se enviaran al dispositivo (formato de 16bits).
7.- crc, es el valor de confirmacion redundante (formato de 16bits).
8.- despues de mandar el string completo debe ejecutarse un delay de al menos 3.3mS

Metodo de recepcion escritura (comando 0x10)
1.- id que inicialmente sera 0x01 (formato de 8 bits).
2.- funcion que le indica al dispositivo que hacer (formato de 8 bits).
3.- direcion de inicio que espesifica desde que direcion del dispositivo rs485 se comenzara escribir (formato de 16bits).
4.- numero de registros que espesifica el numero de registros de longitud de 16 bits se leeran o escribiran en el dispositivo (formato de 16bits).
5.- crc, es el valor de confirmacion redundante (formato de 16bits).
6.- despues de mandar el string completo debe ejecutarse un delay de al menos 3.3mS
*/
    uint8_t dato[50];
    uint8_t bytes = 0, i = 0, j = 0;
    uint16_t crc = 0, crc_recibido = 0;

    if (funcion == RS485_LEER) {                                                                //seccion para enviar peticion de lectura
        dato[0] = id;                                                                           //cargo id del dispositivo rs485
        dato[1] = funcion;                                                                      //cargo comando de escritura
        dato[2] = (uint8_t)(start_address >> 8);                                                           //cargo parte alta de la direcion de inicio de lectura
        dato[3] = (uint8_t)(start_address);                                                                //cargo parte baja de la direcion de inicio de lectura
        dato[4] = (uint8_t)(n_registers >> 8);                                                             //cargo parte alta de numero de registros a leer
        dato[5] = (uint8_t)(n_registers);                                                                  //cargo parte baja de numero de registros a leer
        crc = crc_modbus(dato, 6);                                                              //genero crc equivalente de los 6 registros anteriores
        dato[6] = (uint8_t)(crc);                                                                          //cargo parte baja de crc
        dato[7] = (uint8_t)(crc >> 8);                                                                     //cargo parte alta de crc

        RS485_TRANSMITIR;                                                                       //envio peticion de lectura
        __delay_us(3000);                                                                         //ejecuto retardo de 3.5char
        for (i = 0; i <= 7; i++) {
            UART2_Write(dato[i]);
//            fputc(dato[i], PORT1);
        }
        __delay_us(3000);                                                                         //ejecuto retardo de 3.5char
        RS485_RECIBIR;                                                                          //recibir respuesta a lectura
        contador = 0;
        //enable_interrupts(int_rda);
        __delay_ms(500);
        __delay_us(3000);                                                                         //ejecuto retardo de 3.5char
        //disable_interrupts(int_rda);
 
        RS485_IDLE;                                                                             //entro a modo idle para no interferir con otras comunicaciones
        crc_recibido = buffer1[4 + (n_registers * 2)];                                          //rescato crc_recibido de la respuesta
        crc_recibido = (crc_recibido << 8) + buffer1[3 + (n_registers * 2)];
    } else if (funcion == RS485_ESCRIBIR) {                                                     //seccion para enviar peticion de escritura
        dato[0] = id;                                                                           //cargo id del dispositivo rs485
        dato[1] = funcion;                                                                      //cargo comando de escritura
        dato[2] = (uint8_t)(start_address >> 8);                                                           //cargo parte alta de la direcion de inicio de escritura
        dato[3] = (uint8_t)(start_address);                                                                //cargo parte baja de la direcion de inicio de escritura
        dato[4] = (uint8_t)(n_registers >> 8);                                                             //cargo parte alta de numero de registros a escribir
        dato[5] = (uint8_t)(n_registers);                                                                  //cargo parte baja de numero de registros a escribir
        dato[6] = (uint8_t)(n_registers * 2);                                                              //cargo numero de bytes a escribir 
        bytes = dato[6];
        j = 7;
        for (i = 0; i <= bytes; i++) {                                                          //cargo el numero bytes a escribir en el string a partir del dato 7
            dato[j] = data6[i] >> 8;
            j = j + 1;
            dato[j] = data6[i];
            j = j + 1;
        }
        crc = crc_modbus(dato, (7 + bytes));                                                    //genero crc equivalente de los registros anteriores
        dato[(7 + bytes)] = (uint8_t)(crc);                                                                //cargo parte mas baja de crc
        dato[(8 + bytes)] = (uint8_t)(crc >> 8);                                                           //cargo parte mas alta de crc

        RS485_TRANSMITIR;                                                                       //envio peticion de escritura
        __delay_us(3000);                                                                         //ejecuto retardo de 3.5char
        for (i = 0; i <= (8 + bytes); i++) {
            UART2_Write(dato[i]);
//            fputc(dato[i], PORT1);
        }
        __delay_us(3000);                                                                         //ejecuto retardo de 3.5char
        RS485_RECIBIR;                                                                          //recibir respuesta a escritura
        contador = 0;
        //enable_interrupts(int_rda);
        __delay_ms(500);
        __delay_us(3000);                                                                         //ejecuto retardo de 3.5char
        //disable_interrupts(int_rda);

        RS485_IDLE;                                                                             //entro a modo idle para no interferir con otras comunicaciones
        crc_recibido = buffer1[7];                                                              //rescato crc_recibido de la respuesta
        crc_recibido = (crc_recibido << 8) + buffer1[6];
    }
    return crc_recibido;                                                                        //regreso el crc_recibido equivalente de la respuesta del dispositivo rs485
// </editor-fold>
}
