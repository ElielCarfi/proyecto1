
#include "RTC_DS3232.h"

void config_RTC(uint8_t year, uint8_t month, uint8_t date, uint8_t hour, uint8_t minutes){
    uint8_t mensajeYear_RTC[2] = {RTC_YEAR, year};
    uint8_t mensajeMonth_RTC[2] = {RTC_MONTH, month};
    uint8_t mensajeDate_RTC[2] = {RTC_DATE, date};
    uint8_t mensajeHour_RTC[2] = {RTC_HOUR, hour};
    uint8_t mensajeMinutes_RTC[2] = {RTC_MINUTES, minutes};
    
    i2c2_WriteData(RTC_ADDRESS, mensajeYear_RTC, 2);
    i2c2_WriteData(RTC_ADDRESS, mensajeMonth_RTC, 2);
    i2c2_WriteData(RTC_ADDRESS, mensajeDate_RTC, 2);
    i2c2_WriteData(RTC_ADDRESS, mensajeHour_RTC, 2);
    i2c2_WriteData(RTC_ADDRESS, mensajeMinutes_RTC, 2);
}

void config_RTC_all(uint8_t year, uint8_t month, uint8_t date, uint8_t day_week, uint8_t hour, uint8_t minutes, uint8_t seconds){
    writeYear_RTC(year);
    writeMonth_RTC(month);
    writeDate_RTC(date);
    writeDay_RTC(day_week);
    writeHour_RTC(hour);
    writeMinutes_RTC(minutes);
    writeSeconds_RTC(seconds);
    
    RTC.hourChange = true;
}

void crear_alarma1(uint8_t hora, uint8_t minutos){
    uint8_t date_day_alarma[2] = {RTC_DATE_DAY_ALARMA1, 0xFF};
    uint8_t hora_alarma[2] = {RTC_HOUR_ALARMA1, hora};
    uint8_t minutos_alarma[2] = {RTC_MINUTES_ALARMA1, minutos};
    uint8_t segundos_alarma[2] = {RTC_SECONDS_ALARMA1, 0x10};
    
    i2c2_WriteData(RTC_ADDRESS, date_day_alarma, 2);
    i2c2_WriteData(RTC_ADDRESS, hora_alarma, 2);
    i2c2_WriteData(RTC_ADDRESS, minutos_alarma, 2);
    i2c2_WriteData(RTC_ADDRESS, segundos_alarma, 2);
}

void activar_alarma1(void){
    uint8_t control_register = 0;
    uint8_t activar_alarma[2] = {RTC_CONTROL_REGISTER, 0x00};
    
    control_register = read_Control_Register();
    activar_alarma[1] = control_register | 0x01;
    
    i2c2_WriteData(RTC_ADDRESS, activar_alarma, 2);
}

void activar_alarma2(void){
    uint8_t control_register = 0;
    uint8_t activar_alarma[2] = {RTC_CONTROL_REGISTER, 0x00};
    
    control_register = read_Control_Register();
    activar_alarma[1] = control_register | 0b00000010;
    
    i2c2_WriteData(RTC_ADDRESS, activar_alarma, 2);
}

void desactivar_alarma1(void){
    uint8_t control_register = 0;
    uint8_t desactivar_alarma[2] = {RTC_CONTROL_REGISTER, 0x00};
    
    control_register = read_Control_Register();
    desactivar_alarma[1] = control_register & 0b11111110;
    
    i2c2_WriteData(RTC_ADDRESS, desactivar_alarma, 2);
}

void desactivar_alarma2(void){
    uint8_t control_register = 0;
    uint8_t desactivar_alarma[2] = {RTC_CONTROL_REGISTER, 0x00};
    
    control_register = read_Control_Register();
    desactivar_alarma[1] = control_register & 0b11111101;
    
    i2c2_WriteData(RTC_ADDRESS, desactivar_alarma, 2);
}

void check_alarma1(void){
    uint8_t day_date = 0;
    uint8_t hour = 0;
    uint8_t minutes = 0;
    uint8_t seconds = 0;
    
    day_date = i2c2_ReadData(RTC_ADDRESS, RTC_DATE_DAY_ALARMA1);
    hour = i2c2_ReadData(RTC_ADDRESS, RTC_HOUR_ALARMA1);
    minutes = i2c2_ReadData(RTC_ADDRESS, RTC_MINUTES_ALARMA1);
    seconds = i2c2_ReadData(RTC_ADDRESS, RTC_SECONDS_ALARMA1);
    
    NOP();
}

uint8_t read_Control_Register(void){
    
    return i2c2_ReadData(RTC_ADDRESS, RTC_CONTROL_REGISTER);
    
}

uint16_t convertTime_minutes(void){
    uint8_t hora = 0;
    uint8_t minutos = 0;
    uint16_t tiempo_minutos = 0;
            
    hora = (getHour_RTC() >> 4) * 10;
    hora = hora + (getHour_RTC() & 0x0F);
    
    minutos = (getMinutes_RTC() >> 4) * 10;
    minutos = minutos + (getMinutes_RTC() & 0x0F);
    
    tiempo_minutos = hora * 60;
    tiempo_minutos = tiempo_minutos + minutos;
    
    return tiempo_minutos;    
}

void writeYear_RTC(uint8_t year){
    uint8_t mensajeYear_RTC[2] = {RTC_YEAR, year};
    uint8_t intentos = 0;
    uint8_t lecturas = 0;
    
    for(; lecturas < 3; lecturas++){
        RTC.anio = getYear_RTC();
    }
    for(; ((intentos < 10) && (RTC.anio != year)); intentos++){
        i2c2_WriteData(RTC_ADDRESS, mensajeYear_RTC, 2);
        for(; lecturas < 3; lecturas++){
            RTC.anio = getYear_RTC();
        }
    }
    
    if(intentos >= 10){
        RTC.fallo_rtc = FALLO_ESCRITURA_ANIO;
    }
}

void writeMonth_RTC(uint8_t month){
    uint8_t mensajeMonth_RTC[2] = {RTC_MONTH, month};
    uint8_t intentos = 0;
    uint8_t lecturas = 0;
    
    for(; lecturas < 3; lecturas++){
        RTC.mes = getMonth_RTC();
    }
    for(; ((intentos < 10) && (RTC.mes != month)); intentos++){
        i2c2_WriteData(RTC_ADDRESS, mensajeMonth_RTC, 2);
        for(; lecturas < 3; lecturas++){
            RTC.mes = getMonth_RTC();
        }
    }
    
    if(intentos >= 10){
        RTC.fallo_rtc = FALLO_ESCRITURA_MES;
    }
}

void writeDate_RTC(uint8_t date){
    uint8_t mensajeDate_RTC[2] = {RTC_DATE, date};
    uint8_t intentos = 0;
    uint8_t lecturas = 0;
    
    for(; lecturas < 3; lecturas++){
        RTC.dia_del_mes = getDate_RTC();
    }
    for(; ((intentos < 10) && (RTC.dia_del_mes != date)); intentos++){
        i2c2_WriteData(RTC_ADDRESS, mensajeDate_RTC, 2);
        for(; lecturas < 3; lecturas++){
            RTC.dia_del_mes = getDate_RTC();
        }
    }
    
    if(intentos >= 10){
        RTC.fallo_rtc = FALLO_ESCRITURA_DIA_MES;
    }
}

void writeDay_RTC(uint8_t day_week){
    uint8_t mensajeDay_RTC[2] = {RTC_DAY, day_week};
    uint8_t intentos = 0;
    uint8_t lecturas = 0;
    
    for(; lecturas < 3; lecturas++){
        RTC.dia_semana = getDay_RTC();
    }
    for(; ((intentos < 10) && (RTC.dia_semana != day_week)); intentos++){
        i2c2_WriteData(RTC_ADDRESS, mensajeDay_RTC, 2);
        for(; lecturas < 3; lecturas++){
            RTC.dia_semana = getDay_RTC();
        }
    }
    
    if(intentos >= 10){
        RTC.fallo_rtc = FALLO_ESCRITURA_DIA_SEMANA;
    }
}

void writeHour_RTC(uint8_t hour){
    uint8_t mensajeHour_RTC[2] = {RTC_HOUR, hour};
    uint8_t intentos = 0;
    uint8_t lecturas = 0;
    
    for(; lecturas < 3; lecturas++){
        RTC.hora = getHour_RTC();
    }
    for(; ((intentos < 10) && (RTC.hora != hour)); intentos++){
        i2c2_WriteData(RTC_ADDRESS, mensajeHour_RTC, 2);
        for(; lecturas < 3; lecturas++){
            RTC.hora = getHour_RTC();
        }
    }
    
    if(intentos >= 10){
        RTC.fallo_rtc = FALLO_ESCRITURA_HORA;
    }
}

void writeMinutes_RTC(uint8_t minutes){
    uint8_t mensajeMinutes_RTC[2] = {RTC_MINUTES, minutes};
    uint8_t intentos = 0;
    uint8_t lecturas = 0;
    
    for(; lecturas < 3; lecturas++){
        RTC.minutos = getMinutes_RTC();
    }
    for(; ((intentos < 10) && (RTC.minutos != minutes)); intentos++){
        i2c2_WriteData(RTC_ADDRESS, mensajeMinutes_RTC, 2);
        for(; lecturas < 3; lecturas++){
            RTC.minutos = getMinutes_RTC();
        }
    }
    
    if(intentos >= 10){
        RTC.fallo_rtc = FALLO_ESCRITURA_MINUTOS;
    }
}

void writeSeconds_RTC(uint8_t seconds){
    uint8_t mensajeSeconds_RTC[2] = {RTC_SECONDS, seconds};
    uint8_t intentos = 0;
    
    i2c2_WriteData(RTC_ADDRESS, mensajeSeconds_RTC, 2); 
}

uint8_t getYear_RTC(void){
    __delay_us(10);
    return i2c2_ReadData(RTC_ADDRESS, RTC_YEAR);
}

uint8_t getMonth_RTC(void){
    __delay_us(10);
    return i2c2_ReadData(RTC_ADDRESS, RTC_MONTH);
}

uint8_t getDate_RTC(void){
    __delay_us(10);
    return i2c2_ReadData(RTC_ADDRESS, RTC_DATE);
}

uint8_t getDay_RTC(void){
    __delay_us(10);
    return i2c2_ReadData(RTC_ADDRESS, RTC_DAY);
}

uint8_t getHour_RTC(void){
    __delay_us(10);
    return i2c2_ReadData(RTC_ADDRESS, RTC_HOUR);
}

uint8_t getMinutes_RTC(void){
    __delay_us(10);
    return i2c2_ReadData(RTC_ADDRESS, RTC_MINUTES);
}

uint8_t getSeconds_RTC(void){
    __delay_us(10);
    return i2c2_ReadData(RTC_ADDRESS, RTC_SECONDS);
}