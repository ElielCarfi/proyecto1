#include "funciones.h"

void get_distance(void){
uint16_t ValorADC;
float Distancia;
float exp5;
float exp4;
float exp3;
float exp2;
float exp1;
ValorADC = getADC_promediado(Sdistancia);
exp5=((-9*exp(-15))*(ValorADC*exp(5)));
exp4=((1*exp(-10))*(ValorADC*exp(4)));
exp3=((4*exp(-7))*(ValorADC*exp(3)));
exp2=(0.0009*(ValorADC*exp(2)));
exp1=(0.9663*ValorADC);
Distancia=(-exp5)+(exp4)-(exp3)+(exp2)-(exp1)+479.18;
}


