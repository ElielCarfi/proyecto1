
#include "Xbee.h"

void init_xbee(){
   reset_xbee();     //Reset de xbee con 1
   sleep_xbee(false);
   stop_usart_xbee(false);
   __delay_ms(2000);    //2 segundos para esperar que el xbee este completamente inicializado
}

void enviar_cadena_USART1(const uint8_t *prtDatos_TX, uint8_t tamanio)
{
    uint8_t i = 0;
    
    for (i = 0; i < tamanio; i++)
    {
        UART1_Write(prtDatos_TX[i]);
    }
}

uint8_t calculate_checksum(const uint8_t *ptrMensaje, const uint16_t tamanio){
    uint16_t suma_mensaje = 0;
    uint8_t i, checksum;
    
    for(i = 0; i < tamanio; i++){
        suma_mensaje = suma_mensaje + ptrMensaje[i];
    }
   
    checksum = (uint8_t)suma_mensaje;
    checksum = 0xFF - checksum;
    
    return checksum;
}

// true Enable
// false Disable
void reset_xbee(void){
    RESET_PIN = 1;    //Resetear Xbee
    __delay_ms(100);  //Tiempo de espera para que el xbee deje de estar en reset
    RESET_PIN = 0;
}

void sleep_xbee(bool enable_disable){
    if(enable_disable == true){
        DTR_PIN = 0;    //Dormir Xbee
    }
    else if(enable_disable == false){
        DTR_PIN = 1;    //Modo normal Xbee
    }
}

void stop_usart_xbee(bool enable_disable){
    if(enable_disable == true){
        RTS_PIN = 1;    // Stop uart con 1
    }
    else if(enable_disable == false){
        RTS_PIN = 0;    //don't stop uart
    }
}

void completarMensajeEnviar(uint8_t *ptrMAC, uint8_t tamanioMensaje){
// <editor-fold defaultstate="collapsed" desc="Completa el mensaje para enviar por xbee">
//    tamanio_mensajeTX_completo = 0;   ////********
//     i = 0;
    
    dataTX[0] = 0x00;  //Frame Type
    dataTX[1] = 0x01;  //Frame ID
    //Incluyendo MAC 8 Bytes
    for(uint8_t i = 0; i < 8; i++){
        dataTX[i + 2] = ptrMAC[i];
    }
    dataTX[10] = 0x00; //Options
//    //Incluyendo Mensaje
//    for(i = 0; i < tamanio_mensaje; i++){
//        mensaje_TX_completo[i + 11] = ptrMensaje[i];
//    }
    
    tamanioDataTx = tamanioMensaje + 11;
// </editor-fold>                 
}

void enviarMensajeTX_Xbee(void){
// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con la info de la rutina programada">// <editor-fold defaultstate="collapsed" desc="Envia el mensaje con la info de la rutina programada">  
    //Byte que delimita el principio el mensaje
    UART1_Write(0x7E);
    
    //Cantidad de bytes enviados
    UART1_Write((uint8_t) (tamanioDataTx >> 8));
    UART1_Write((uint8_t) (tamanioDataTx));
    
    //Envio de mensaje
    enviar_cadena_USART1(dataTX, tamanioDataTx);
    
    //Calcula y envia el checksum
    UART1_Write(calculate_checksum(dataTX, tamanioDataTx));
    
    mensaje_enviado = true;
    
// </editor-fold>   
}