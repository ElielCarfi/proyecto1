/*
 * File:   mensajesLCD.c
 * Author: hecto
 *
 * Created on October 30, 2022, 10:22 AM
 */


#include "mcc_generated_files/mcc.h"
#include "LCD_I2C.h"
#include "I2CC.h"
#include "mensajesLCD.h"
#include "i2c.h"

void LCDLCD(void){
lcd_move_cursor(0x01);
lcd_load_data('2');
lcd_load_data('.');
lcd_load_data('5');
lcd_load_data('M');
lcd_move_cursor(0x06);
lcd_load_data('2');
lcd_load_data('0');
lcd_load_data('0');
lcd_load_data('0');
lcd_load_data('0');
lcd_load_data('L');
lcd_move_cursor(0x0E);
lcd_load_data('-');
lcd_load_data('-');
lcd_move_cursor(0x40);
lcd_load_data('H');
lcd_load_data('O');
lcd_load_data('L');
lcd_load_data('A');
lcd_load_data(' ');
lcd_load_data('M');
lcd_load_data('U');
lcd_load_data('N');
lcd_load_data('D');
lcd_load_data('O');
lcd_move_cursor(0x49);
lcd_load_data('S');
lcd_load_data(':');
lcd_load_data('1');
lcd_load_data('0');
lcd_load_data('0');
lcd_load_data('%');
}
void LCDLCD1(void){
  lcd_move_cursor(0x01);
lcd_load_data('2');
lcd_load_data('.');
lcd_load_data('5');
lcd_load_data('M');
lcd_move_cursor(0x06);
lcd_load_data('2');
lcd_load_data('0');
lcd_load_data('0');
lcd_load_data('0');
lcd_load_data('0');
lcd_load_data('L');
lcd_move_cursor(0x0E);
lcd_load_data(0X5E);//FLECHAS HACIA ARRIBA REVISAR 
lcd_load_data(0X5E);//FLECHAS HACIA ARRIBA REVISAR 
lcd_move_cursor(0x40);
lcd_load_data('T');
lcd_load_data(':');
lcd_load_data('2');
lcd_load_data('8');
lcd_load_data('.');
lcd_load_data('2');
lcd_load_data(0XDF);//SIGNO DE GRADOS
lcd_load_data('C');
lcd_move_cursor(0x49);
lcd_load_data('P');
lcd_load_data('H');
lcd_load_data(':');
lcd_load_data('9');
lcd_load_data('.');
lcd_load_data('5');  
}

void LCDLCD2(void){
  lcd_move_cursor(0x01);
lcd_load_data('2');
lcd_load_data('.');
lcd_load_data('5');
lcd_load_data('M');
lcd_move_cursor(0x06);
lcd_load_data('2');
lcd_load_data('0');
lcd_load_data('0');
lcd_load_data('0');
lcd_load_data('0');
lcd_load_data('L');
lcd_move_cursor(0x0E);
lcd_load_data(0XB7);//FLECHAS HACIA ABAJO REVISAR 
lcd_load_data(0XB7);//FLECHAS HACIA ABAJO REVISAR
lcd_move_cursor(0x40);
lcd_load_data('T');
lcd_load_data(':');
lcd_load_data('2');
//lcd_load_data('8');
//lcd_load_data('.');
//lcd_load_data('2');
//lcd_load_data(0XDF); //SIGNO DE GRADOS
//lcd_load_data('C');
//lcd_move_cursor(0x49);
//lcd_load_data('P');
//lcd_load_data('H');
//lcd_load_data(':');
//lcd_load_data('9');
//lcd_load_data('.');
//lcd_load_data('5');  
}