/* 
 * File:   colores_LED.h
 * Author: AlexisRamirez
 *
 * Created on February 8, 2022, 1:54 PM
 */

#ifndef COLORES_LED_H
#define	COLORES_LED_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <xc.h>
    
//COLORES LED
#define LED_ROJO        LATCbits.LATC3 = 1;    LATDbits.LATD0 = 1;   LATDbits.LATD1 = 0;    //LED COLOR ROJO
#define LED_VERDE       LATCbits.LATC3 = 1;    LATDbits.LATD0 = 0;   LATDbits.LATD1 = 1;    //LED COLOR VERDE
#define LED_AZUL        LATCbits.LATC3 = 0;    LATDbits.LATD0 = 1;   LATDbits.LATD1 = 1;    //LED COLOR AZUL
#define LED_CIAN        LATCbits.LATC3 = 0;    LATDbits.LATD0 = 0;   LATDbits.LATD1 = 1;    //LED COLOR CIAN
#define LED_ROSA        LATCbits.LATC3 = 0;    LATDbits.LATD0 = 1;   LATDbits.LATD1 = 0;    //LED COLOR ROSA
#define LED_AMARILLO    LATCbits.LATC3 = 1;    LATDbits.LATD0 = 0;   LATDbits.LATD1 = 0;    //LED COLOR AMARILLO
#define LED_BLANCO      LATCbits.LATC3 = 0;    LATDbits.LATD0 = 0;   LATDbits.LATD1 = 0;    //LED COLOR BLANCO
#define LED_APAGADO     LATCbits.LATC3 = 1;    LATDbits.LATD0 = 1;   LATDbits.LATD1 = 1;    //LED COLOR APAGADO


#ifdef	__cplusplus
}
#endif

#endif	/* COLORES_LED_H */

