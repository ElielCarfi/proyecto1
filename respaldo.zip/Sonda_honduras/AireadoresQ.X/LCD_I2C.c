#include "LCD_I2C.h"

void lcd_i2cinit(void){
     __delay_ms(50);
     lcd_wryte(0b00110000);
     __delay_us(40);
     lcd_wryte(0b00100000);
     lcd_wryte(0b10000000);
     __delay_us(40);
     lcd_wryte(0b00100000);
     lcd_wryte(0b10000000);
     __delay_us(40);
     lcd_wryte(0b00000000);
     lcd_wryte(0b11100000);   // on/off blink 
     __delay_us(40);
     lcd_wryte(0b00000000);
     lcd_wryte(0b00100000);
     __delay_ms(2);
     lcd_wryte(0b00000000);
     lcd_wryte(0b01100000);
     
    ////////////////////////////////////////////
//    uint8_t interfaz;
//    uint8_t displaycontrol;
//    uint8_t modeset;
//    lcd_wryte(0b00110000);
//    __delay_us(100);
//    lcd_wryte(0b00100000);
//    __delay_us(100);
//    lcd_wryte(0b00110000);
//    lcd_wryte(0b00100000);
//    lcd_wryte(0b00100000);  
//    __delay_ms(100);
    
//	interfaz= _LCD_FUNTIONSET  | _LCD_2LINE | _LCD_5x7DOTS ;
//    lcd_load_command(interfaz);                                // 40 + 8 + 0 ---> 0011 0000
//    lcd_load_command(_LCD_CLEARDISPLAY);
//    __delay_ms(1.5);
//    modeset = _LCD_ENTRYMODESET |  _LCD_INCREMENT | _LCD_SHIFT_OFF;
//    lcd_load_command(modeset);                                 // 4 + 2 + 0 ----> 0000 0110
//    __delay_us(40);
//    displaycontrol=_LCD_DISPLAYCONTROL | _LCD_DISPLAY_ON | _LCD_CURSOR_ON | _LCD_BLINK_OFF;
//    lcd_load_command(displaycontrol);                          // 8 + 4 + 2 + 0-> 0000 1110  
//    __delay_us(40);
//    lcd_load_command(_LCD_SET_DDRAM_ADDR);                     //              -> 1000 0000 
//    __delay_us(40);
    }

void lcd_load_command(uint8_t cmd){
     uint8_t HN;
     uint8_t LN;
    HN=(cmd & 0XF0);
    LN= (cmd & 0X0F)<<(4);
    loadnibbles(HN,COMMAND);
    __delay_us(20);  // Retardo recomendado despues de cada operaci�n 
     loadnibbles(LN,COMMAND);
     __delay_us(20); // Retardo recomendado despues de cada operaci�n 
    }



void lcd_load_data(uint8_t dato){
     uint8_t HN;
     uint8_t LN;
    HN= (dato & 0XF0);  
    LN= (dato & 0X0F)<<(4);
    loadnibbles(HN,DATA);
    __delay_us(20); 
     loadnibbles(LN,DATA);
     __delay_us(20); 
   }

    void loadnibbles(uint8_t data,uint8_t mode){
    switch (mode){
        case 0:data= data | 0x00;break;
        case 1:data= data | 0x01;break;  
    }
  //  data = data | 0x08;
        lcd_wryte(data);
    }

void lcd_wryte( uint8_t data){
    I2C1_Write1ByteRegister(0x27, 1 , data | 0x08); // 0000 1000 
        __delay_us(100);
        data=data|0x04;    
          I2C1_Write1ByteRegister(0x27, 1 , data | 0x08);
        __delay_us(100);
          NOP();
         data=data&0xF1  ;
        I2C1_Write1ByteRegister(0x27, 1 , data | 0x08);
  __delay_us(100);
}
void lcd_move_cursor(uint8_t position){
    position=position|_LCD_SET_DDRAM_ADDR;
    lcd_load_command(position);
}
void lcd_putc(char *a)
{
   int i;
   for(i=0;a[i]!='\0';i++)
      lcd_load_data(a[i]);
} 
void lcd_putc_limit(char *a, uint8_t caracteres)
{
   int i;
   for(i=0;a[i]==caracteres;i++)
      lcd_load_data(a[i]);
}

void lcd_clear(void){
     lcd_load_command(0);
     lcd_load_command(1);
     __delay_ms(3);
}

void lcd_gotoxy(char a, char b){
   char temp,z,y;
   if(a == 1)
   {
     temp = 0x80 + b - 1;
      z = temp>>4;
      y = temp & 0x0F;
      lcd_load_command(z);
      lcd_load_command(y);
   }
   else if(a == 2)
   {
      temp = 0xC0 + b - 1;
      z = temp>>4;
      y = temp & 0x0F;
      lcd_load_command(z);
      lcd_load_command(y);
   }
}

void lcd_shift_left()
{
   lcd_load_command(0x01);
   lcd_load_command(0x08);
}

void lcd_create_char(uint8_t charnum, uint8_t * chardata){
    charnum &= 0x07;   // 0000 0000 & 0000 0111 = 0000 0000 | 0100 0000 = 0100 0000 
                       // 0000 0001 & 0000 0111 = 0000 0001 | 0100 0000 = 0100 0001 
    uint8_t i; 
    lcd_load_command(0x40 | (charnum<<3)); // 0000 0000 & 0000 0111 = 0000 0000 
                                           // 0000 0001 & 0100 1000 = 
    for(i=0; i<8; i++){
        lcd_load_data(chardata[i]);
    }
}
void lcd_printf_variable(char *string, float variable, uint8_t enteros, uint8_t decimales){  // lcd_printf_variable(distancia, 3, 2)  
        char buffer[10]; 
        uint16_t parte_entera;
        float valor_decimal;
        uint16_t parte_decimal;
        uint8_t numero;
        char texto[]="000.0";
        for(int j=0; string[j]!='\0';j++){
            lcd_load_data(string[j]);
        }
        numero = pow(10,decimales);
        parte_entera = (uint16_t) (variable/1);            // salva la parte entera
        valor_decimal = variable - parte_entera;           // se almacena la parte flotante 
        parte_decimal = valor_decimal * numero;            // Se multiplica por numero para volverlo entero
 
       switch(enteros){
           case 0:
               break;
           case 1:
               texto[0] = (parte_entera % 10) + '0';
               break;
           case 2:
               texto[0] = ((parte_entera % 100) / 10) + '0';
               texto[1] = (parte_entera % 10) + '0';
               break;
           case 3:
               texto[0] = (parte_entera / 100) + ' ';
               texto[1] = ((parte_entera % 100) / 10) + '0';
               texto[2] = (parte_entera % 10) + '0';
               break;
       }
         texto[enteros]='.';                                            // Colocaci�n del punto 
       switch(decimales){
           case 0:
               break;
           case 1:
               texto[enteros+1] = (parte_decimal % 10) + '0';
               break;
           case 2:
               texto[enteros+1] = ((parte_decimal % 100) / 10) + '0';
               texto[enteros+2] = (parte_decimal % 10) + '0';
       }
       sprintf(buffer,"PH %d. %d", parte_entera, parte_decimal);
       
}
void lcd_printf_char(char *texto, float variable, uint8_t enteros, uint8_t decimales, char *complemento){        
    uint16_t parte_entera,parte_decimal;
    float valor_decimal;
    char buffer[16];
    int numero = pow(10, decimales);
    
    parte_entera = (uint16_t) (variable/1);            // salva la parte entera
    valor_decimal = variable - parte_entera;           // se almacena la parte flotante 
    parte_decimal = valor_decimal * numero;            // Se multiplica por numero para volverlo entero
    
           for(int j=0; texto[j]!='\0';j++)
            lcd_load_data(texto[j]);
    switch(enteros){
        case 0: break;
        case 1: 
            if(decimales==1){
                sprintf(buffer,"% 1d.%01d ", parte_entera, parte_decimal);
            }
            else if(decimales==2){
                sprintf(buffer,"% 1d.%02d",parte_entera, parte_decimal);
            }
            break;
        case 2:
            if(decimales==1){
               sprintf(buffer,"% 2d.%01d", parte_entera, parte_decimal);
            }
            else if(decimales==2){
                sprintf(buffer,"% 2d.%02d",parte_entera, parte_decimal);
            }
            break;
        case 3:
            if(decimales==0){
                sprintf(buffer,"% 3d", parte_entera);
            }
            else if(decimales==1){
                sprintf(buffer,"% 3d.%01d", parte_entera, parte_decimal);
            }
            else if(decimales==2){
              sprintf(buffer, "% 3d.%02d", parte_entera, parte_decimal);
            }
            break;
    }
    lcd_putc(buffer);
    
    for(int j=0; complemento[j]!='\0';j++)
            lcd_load_data(complemento[j]);
}

void lcd_pantalla_flechas(float ph_variable, float temperatura, float distancia, bool estado){
    float nivel = 1.5 - (distancia / 100);
    float litros = (2000/1.4) * nivel;
    const char flecha_arriba[8]={
      0b00000100,
      0b00001110,
      0b00011111,
      0b00000100,
      0b00000100,
      0b00000100,
      0b00000100,
      0b00000000,
    };
    const char flecha_abajo[8]={
      0b00000100,
      0b00000100,
      0b00000100,
      0b00000100,
      0b00011111,
      0b00001110,
      0b00000100,
      0b00000000,
    };
        lcd_move_cursor(0x00);
            lcd_printf_char("",nivel, 2,1,"m");
            lcd_printf_char(" ", litros, 3,0, "L ");
            lcd_move_cursor(0x40);
            lcd_printf_char("T:", temperatura, 2,1,"C");
            lcd_printf_char(" PH:", ph_variable, 2,1," ");
        if(estado){
            lcd_create_char(0,flecha_arriba);
            lcd_move_cursor(0x0E);
            lcd_load_data(0);
            lcd_load_data(0);
        }
        else{ 
            lcd_create_char(1,flecha_abajo);
            lcd_move_cursor(0x0E);
            lcd_load_data(1);
            lcd_load_data(1);
        }
}