/* 
 * File:   Sonda_funciones_EEPROM.h
 * Author: acuic
 *
 * Created on 12 de septiembre de 2022, 04:47 PM
 */

#ifndef SONDA_FUNCIONES_EEPROM_H
#define	SONDA_FUNCIONES_EEPROM_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <stdint.h>
#include "Float_IEEE754.h"
#include "mcc_generated_files/memory.h"
    
#define L_TIME_MEASUREMENTS 0x0200

void saveEEPROMTimeMeasurements(uint8_t *ptrMensaje);
uint16_t readTimeMeasurements(void);

#ifdef	__cplusplus
}
#endif

#endif	/* SONDA_FUNCIONES_EEPROM_H */

