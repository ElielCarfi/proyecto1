/* 
 * File:   Xbee.h
 * Author: AlexisRamirez
 *
 * Created on January 25, 2022, 3:26 PM
 */

#ifndef XBEE_H
#define	XBEE_H

#include <xc.h>
#include <stdbool.h>
#include <stdint.h>
#include "mcc_generated_files/mcc.h"

#ifdef	__cplusplus
extern "C" {
#endif

#define _XTAL_FREQ  16000000
//    pin      xbee   config. pic        accion
//    rb0-----reset -----salida------1 para resetear por 100nS
//    rb1-----DTR   -----salida------0 para dormir xbee
//    rb2-----RTS   -----entrada-----Solicitud de uart 
#define RESET_PIN       LATCbits.LATC5
#define DTR_PIN         LATDbits.LATD3
#define RTS_PIN         LATDbits.LATD2

#define AT_COMMAND_MODE '+','+','+'             //Entrar a modo comandos AT
#define AT_TO           'A','T','T','O'         //Transmit Options
#define AT_DH           'A','T','D','H'
#define AT_DL           'A','T','D','L'
#define MAC_DESTINO_HB  '0','0','1','3','A','2','0','0'
#define MAC_DESTINO_LB  '4','1','B','3','3','1','C','2'

    
#define MAC_DESTINO_1       0x00
#define MAC_DESTINO_2       0x13
#define MAC_DESTINO_3       0xA2
#define MAC_DESTINO_4       0x00
#define MAC_DESTINO_5       0x41
#define MAC_DESTINO_6       0xB3
#define MAC_DESTINO_7       0x31
#define MAC_DESTINO_8       0xC2
    
#define TRANSMIT_STATUS 0x89
#define RECEIVE_PACKET  0x90
    
#define START_DELIMITER 0x7E

volatile bool mensaje_enviado = false;

uint8_t dataTX[269] = {0};
static uint8_t tamanioDataTx = 0;

void init_xbee();

void enviar_cadena_USART1(const uint8_t *prtDatos_TX, uint8_t tamanio);

uint8_t calculate_checksum(const uint8_t *ptrMensaje, const uint16_t tamanio);

void reset_xbee(void);

void sleep_xbee(bool enable_disable);

void stop_usart_xbee(bool enable_disable);


void completarMensajeEnviar(uint8_t *ptrMAC, uint8_t tamanioMensaje);
void enviarMensajeTX_Xbee(void);
#ifdef	__cplusplus
}
#endif

#endif	/* XBEE_H */

