/* 
 * File:   i2c.h
 * Author: AlexisRamirez
 *
 * Created on January 31, 2022, 3:49 PM
 */

#ifndef I2C_H
#define	I2C_H

#ifdef	__cplusplus
extern "C" {
#endif

//Cabeceras    
#include "mcc_generated_files/mcc.h"

/**
 Section: Data Type Definitions
*/

/**
  @Summary
    Initializes the I2C1

  @Description
    This routine initializes the I2C1.
    This routine must be called before any other i2c1 routine is called.
    This routine should only be called once during system initialization.

  @Preconditions
    None

  @Param
    None

  @Returns
    None

  @Comment

  
  @Example
    <code>
    I2C1_Initialize();
    </code>
*/
void I2C2_Initialize_M(void);

 /**
  @Summary
    Read n bytes of data block from a register/address of an I2C slave having 7 bit Address.

  @Description
    This routine reads n bytes of data from a register/address of an I2C slave.

  @Preconditions
  None

  @Param
    address - The address of the i2c slave to be accessed
 
  @Param
    *data - A pointer to the memory location where received data will be stored 

  @Param
    len - The length of the data block to be read
  
  @Returns
    None
*/
uint8_t i2c2_ReadData(uint8_t address, uint8_t reg);
void i2c2_WriteData(uint8_t address, uint8_t *data, uint8_t len);
//void i2c2_WriteData(uint8_t address, uint8_t reg, uint8_t *data, uint8_t len);
static inline void wait4Stop(void);

#ifdef	__cplusplus
}
#endif

#endif	/* I2C_H */

